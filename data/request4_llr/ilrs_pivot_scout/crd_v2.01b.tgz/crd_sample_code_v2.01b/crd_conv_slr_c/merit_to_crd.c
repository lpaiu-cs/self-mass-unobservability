#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>

#define FNLEN   256
#define FMT_VERSION 2

#include "crd.h"
#include "merit.h"

FILE *str_in, *str_out_fr;
fpos_t startpos;
struct merit_fr fr, fr0;
struct rh1 h1;
struct rh2 h2;
struct rh3 h3;
struct rh4 h4;
struct rc0 c0;
struct rc1 c1;
struct rc2 c2;
struct rc3 c3;
struct rc4 c4;
struct rd10 d10;
struct rd11 d11;
struct rd12 d12;
struct rd20 d20;
struct rd21 d21;
struct rd30 d30;
struct rd40 d40;
struct rd50 d50;
struct rd60 d60;
struct rd00 d00;

void get_sat_ids ();
void get_station_id ();
void move_merit_to_crd_hdr ();
void move_merit_to_crd_data ();
void setup_files ( /*int, char * */ );
void sodtohms ();
void write_headers ();
void write_data ();
void write_end_of_data_block ();
void write_end_of_file ();
void doytogr (int, int, int *, int *, char *);
void read_merit_fr (char *, struct merit_fr *);

/*-------------------------------------------------------------------------
 * Program: merit_to_crd
 *
 * Purpose:
 * Converts old ILRS (MERIT) fullrate files to the ILRS CRD format
 *
 * Calling sequence:
 *   merit_to_crd -i merit_frd_filename -o crd_frd_filename
 *
 * Author: Randall Ricklefs / Univ of Texas / Center for Space Research
 *
 * History:
 *   Oct 25, 2007 - Initial version
 *   Feb 2, 2010 - Because of round-off problems, change 1.e7 to
 *                 (long double)1.e7 in second of days calulations.
 *                 1.01b. rlr.
 *   Aug 23, 2019- V2.00 NA. rlr.
 *
**-----------------------------------------------------------------------*/

int
main (argc, argv)
     int argc;
     char *argv[];
{
  int data_type = 0;
  int data_release = 0;
  int delta;
  int idummy;
  int first_pass= 1;
  int first_record = 0;
  int n_fr = 0;
  int new_pad;
  int new_target;
  int next_new_pad= 1;
  int next_new_target= 1;
  int reset_def = 1;
  long filpos;
  long lclock;
  char *status;
  char istrdum[11];
  char str[256];
  double dttm, dttm0;
  double ddelta;
  double esec_of_day;
  double ssec_of_day;
  struct tm gmt;

/*  Greetings */
  printf("Convert Merit Fullrate to CRD Format: version 2.01 10/16/2019\n");

/*  get file names and open files  */
  setup_files (argc, argv);
  fr.ilrs_id = NA_VALUE;	// 082319 - NA
  fr.cdp_pad_id = NA_VALUE;	// 082319 - NA

/* get processing time */
  time (&lclock);
  gmt = *gmtime (&lclock);

/* read and process the file... */
  while ((status = fgets (str, 256, str_in)) != NULL)
    {
      if (strlen (str) <= 1)
	continue;		/* Blank lines... */
      /*printf ("Merit recd: [%s]\n", str); */
      read_merit_fr (str, &fr0);
      dttm0 = fr0.doy + (double) fr0.sec_of_day / 86400.e0;
      first_record = 1;

      /* Get start and end times of pass, and break points */
      filpos = ftell (str_in);
      while ((status = fgets (str, 256, str_in)) != NULL)
	{

	  if (strlen (str) <= 1)
	    continue;		/* Blank lines... */

	  /* decode the record */
	  read_merit_fr (str, &fr);

	  if (first_record)
	    {
              first_record = 0;
	      get_sat_ids (0, &fr0.ilrs_id, &idummy, &idummy, &istrdum,
			   &delta);
	      ddelta = delta / 86400e0;
	      ssec_of_day = fr0.sec_of_day;
	      /**printf ("delta %d ddelta %f\n", delta, ddelta);**/
	    }

	  /* Is this a new pass? */
	  dttm = fr.doy + (double) fr.sec_of_day / 86400.e0;
	  /**printf("dttm %f idttm0 %f new pass %d\n",
		dttm,dttm0,fabs (dttm - dttm0) > ddelta);**/
	  if (fr.cdp_pad_id != fr0.cdp_pad_id || fr.ilrs_id != fr0.ilrs_id
	      || (fabs (dttm - dttm0) > ddelta))
	    break;

	  esec_of_day = fr.sec_of_day;
	}
      /*printf ("s sec %f e sec %f\n", ssec_of_day,
         esec_of_day); */

      /* Create and Write the header(s) */
      new_pad= next_new_pad;
      new_target= next_new_target;
      next_new_pad= fr0.cdp_pad_id!=fr.cdp_pad_id;
      next_new_target= fr0.ilrs_id!=fr.ilrs_id;
      fr = fr0;
      move_merit_to_crd_hdr (gmt, &data_type, ssec_of_day, esec_of_day);
      write_headers (str_out_fr,first_pass,new_pad, new_target);
      first_pass= 0;

      /* Process the merit records */
      reset_def = 1;
      fseek (str_in, filpos - 131, SEEK_SET);
      while ((status = fgets (str, 256, str_in)) != NULL)
	{
	  if (strlen (str) <= 1)
	    continue;		/* Blank lines... */
	  read_merit_fr (str, &fr);

	  /* Is this a new pass? */
	  dttm = fr.doy + (double) fr.sec_of_day / 86400.e0;
	  if (fr.cdp_pad_id != fr0.cdp_pad_id || fr.ilrs_id != fr0.ilrs_id
	      || (fabs (dttm - dttm0) > ddelta))
	    {
	      /* Pretend we didn't read this record... */
	      fseek (str_in, (long) -131, SEEK_CUR);
	      break;
	    }

	  /* Create and write data records */
	  move_merit_to_crd_data ();
	  write_data (str_out_fr, reset_def);
	  reset_def = 0;
	}

      /* end the session... */
      write_end_of_data_block (str_out_fr, data_type);
      n_fr++;
    }

  /* clean up and go home... */
  if (n_fr > 0)
    write_end_of_file (str_out_fr);
  fclose (str_in);
  fclose (str_out_fr);
}

/*-------------------------------------------------------------------------
**
**      move_np_to_crd - Copy info from the input normalpoint records 
**                       and elsewhere to the CRD data records.
**
**-----------------------------------------------------------------------*/
void
move_merit_to_crd_hdr (struct tm gmt, int *data_type, double ssec_of_day,
		       double esec_of_day)
{
  char mon_name[4];
  int mon, day;
  int idummy, i;

/* Format header */
  strcpy (h1.crd_literal,"CRD");
  h1.format_version = FMT_VERSION;
  h1.prod_year = gmt.tm_year + 1900;
  h1.prod_mon = gmt.tm_mon + 1;
  h1.prod_day = gmt.tm_mday;
  h1.prod_hour = gmt.tm_hour;

/* Station header */
  get_station_id (fr.cdp_pad_id, &h2.stn_name);
  h2.cdp_pad_id = fr.cdp_pad_id;
  h2.cdp_sys_num = fr.cdp_sys_num;
  h2.cdp_occ_num = fr.cdp_occ_num;
  h2.stn_timescale = fr.stn_timescale;

/* Target header */
  h3.ilrs_id = fr.ilrs_id;
  get_sat_ids (0, &h3.ilrs_id, &h3.norad, &h3.sic, &h3.target_name, &idummy);
  h3.SC_timescale = 0;
  if (fr.time_of_flight > 0.9999)	/* 2.5 seconds for moon. Not enough digits. */
    {
      h3.target_type = 2;
      h3.target_class = 1;
      h3.target_loc = 3;
    }
  else
    {
      h3.target_type = 1;
      h3.target_class = 1;
      h3.target_loc = 1;
    }
  if (fr.np_window_ind > 0)
    h4.data_type = *data_type = 1;
  else
    h4.data_type = *data_type = 0;
  doytogr (fr.year - 1900, fr.doy, &mon, &day, mon_name);
  h4.start_year = h4.end_year = fr.year;
  h4.start_mon = h4.end_mon = mon;
  h4.start_day = h4.end_day = day;
  sodtohms ((long) ssec_of_day, &h4.start_hour, &h4.start_min, &h4.start_sec);
  sodtohms ((long) esec_of_day, &h4.end_hour, &h4.end_min, &h4.end_sec);
  h4.data_release = fr.data_release;	/* from np detail recds; none for sed */

  if (fr.refraction_app_ind == 0)
    h4.refraction_app_ind = 1;
  else
    h4.refraction_app_ind = 0;

  if (fr.CofM_app_ind == 0)
    h4.CofM_app_ind = 1;
  else
    h4.CofM_app_ind = 0;

  if (fr.xcv_amp_app_ind == 0)
    h4.xcv_amp_app_ind = 1;
  else
    h4.xcv_amp_app_ind = 0;

  h4.stn_sysdelay_app_ind = 1;

  h4.SC_sysdelay_app_ind = 0;
  h4.range_type_ind = 2;
  h4.data_qual_alert_ind= 0;

/* Config header */
  c0.detail_type = 0;
  c0.xmit_wavelength = fr.xmit_wavelength;
  strcpy (c0.config_ids[0], "std");
  for (i = 1; i < 10; i++)
    {
      c0.config_ids[i][0] = '\0';
    }

/* Normalpoint recd */
  if (fr.np_window_ind == 1)
    d11.np_window_length = 5;
  else if (fr.np_window_ind == 2)	/* llr */
    {			   /** is doc correct? Is it really 10? **/
      d11.np_window_length = NA_VALUEF;	// 082319 - NA
    }
  else if (fr.np_window_ind == 3)
    d11.np_window_length = 15;
  else if (fr.np_window_ind == 4)
    d11.np_window_length = 20;
  else if (fr.np_window_ind == 5)
    d11.np_window_length = 30;
  else if (fr.np_window_ind == 6)
    d11.np_window_length = 60;
  else if (fr.np_window_ind == 7)
    d11.np_window_length = 120;
  else if (fr.np_window_ind == 8)
    d11.np_window_length = 180;
  else if (fr.np_window_ind == 9)
    d11.np_window_length = 300;

/* Calibratin Record */
  d40.type_of_data = 0;
  strcpy (d40.sysconfig_id, c0.config_ids[0]);
  d40.num_points_recorded = NA_VALUE;	// 082319 - NA
  d40.num_points_used = NA_VALUE;	// 082319 - NA
  d40.one_way_target_dist = NA_VALUEF;	// 082319 - NA
  d40.cal_sys_delay = fr.cal_sys_delay;	/*hdr.cal_sys_delay; */
  d40.cal_delay_shift = fr.cal_delay_shift;	/*hdr.cal_delay_shift; */
  d40.cal_rms = fr.cal_rms;
  d40.cal_skew = NA_VALUEF;	// 082319 - NA
  d40.cal_kurtosis = NA_VALUEF;	// 082319 - NA
  d40.cal_PmM = NA_VALUEF;	// 082319 - NA
  d40.cal_shift_type_ind = fr.cal_type_ind > 4 ? 3 : 2;
  d40.cal_type_ind = fr.cal_type_ind;
  if (d40.cal_type_ind > 4)
    d40.cal_type_ind -= 5;
  d40.cal_type_ind += 2;
  if (d40.cal_type_ind == 6)
    d40.cal_type_ind = 0;
  d40.detector_channel = 0;

/* Session (pass) statistical Record */
  strcpy (d50.sysconfig_id, c0.config_ids[0]);
  d50.sess_rms = fr.sess_rms;
  d50.sess_skew = NA_VALUEF;	// 082319 - NA
  d50.sess_kurtosis = NA_VALUEF;	// 082319 - NA
  d50.sess_PmM = NA_VALUEF;	// 082319 - NA
  d50.data_qual_ind = NA_VALUE;	// 082319 - NA	/*hdr.data_qual_ind; */

/* Compatibility record */
  strcpy (d60.sysconfig_id, c0.config_ids[0]);
  d60.sys_change_ind = fr.sys_change_ind;
  d60.sys_config_ind = fr.sys_config_ind;
}

/*-------------------------------------------------------------------------
**
**      move_merit_to_crd_data -  Copy info from the input normalpoint
**                                records and elsewhere to the CRD data records.
**
**-----------------------------------------------------------------------*/
void
move_merit_to_crd_data ()
{
/* Normalpoint Record */
  if (fr.np_window_ind /*width */  > 0)
    {
      d11.sec_of_day = fr.sec_of_day;
      d11.time_of_flight = fr.time_of_flight;
      strcpy (d11.sysconfig_id, c0.config_ids[0]);
      d11.epoch_event = fr.epoch_event;
      d11.num_ranges = fr.num_ranges;
      if (fr.np_window_ind == 2)	/* llr */
	d11.time_of_flight += 2.e0;	/* np.scale_or_tof_sec; */
      /*else if (np.scale_or_tof_sec != 0)
         d11.num_ranges*= exp10((double)np.scale_or_tof_sec); */
      d11.bin_rms = fr.sess_rms;	/* np.bin_rms; */
      d11.bin_skew = NA_VALUEF;	// 082319 - NA
      d11.bin_kurtosis = NA_VALUEF;	// 082319 - NA
      d11.bin_PmM = NA_VALUEF;	// 082319 - NA
      d11.return_rate = NA_VALUEF;	// 082319 - NA	/* np.snr; */
      d11.signal_to_noise = NA_VALUEF;	// 082319 - NA	/* np.snr; */
    }
  else
    {
/* Range Record */
      d10.sec_of_day = fr.sec_of_day;
      d10.time_of_flight = fr.time_of_flight;
      strcpy (d10.sysconfig_id, c0.config_ids[0]);
      d10.epoch_event = fr.epoch_event;
      d11.num_ranges = fr.num_ranges;
      if (fr.np_window_ind == 2)	/* llr */
	d11.time_of_flight += 2.e0;	/* np.scale_or_tof_sec; */
      d10.filter_flag = 0;
      d10.detector_channel = 0;
      d10.stop_number = 0;
      d10.xcv_amp = fr.xcv_amp;
    }

/* Range Supplement Record */
  d12.sec_of_day = fr.sec_of_day;
  strcpy (d12.sysconfig_id, c0.config_ids[0]);
  d12.refraction_corr = fr.refraction_corr;
  d12.target_CofM_corr = fr.target_CofM_corr;
  d12.nd_value = NA_VALUEF;	// 082319 - NA
  d12.time_bias = NA_VALUEF;	// 082319 - NA
  d12.range_rate = NA_VALUEF;	// 082319 - NA

/* Meteorology Record */
  d20.sec_of_day = fr.sec_of_day;
  d20.pressure = fr.pressure;
  d20.temperature = fr.temperature;
  d20.humidity = fr.humidity;
  d20.value_origin= 1;

/* Pointing Angle Record */
  d30.sec_of_day = fr.sec_of_day;
  d30.azimuth = fr.azimuth;
  d30.elevation = fr.elevation;
  d30.direction_ind = 0;
  d30.angle_origin_ind = fr.angle_origin_ind;
  d30.refraction_corr_ind = 1;	/* Assumption! */
  d30.azimuth_rate = NA_VALUEF;	// 10/15/19
  d30.elevation_rate = NA_VALUEF;	// 10/15/19

/* Calibration Record */
  d40.sec_of_day = fr.sec_of_day;
}

/*-------------------------------------------------------------------------
**
**      sodtohms - Convert seconds of day to hour/minute/second 
**
**-----------------------------------------------------------------------*/
void
sodtohms (long sod, int *h, int *m, int *s)
{
  *h = sod / 3600;
  *m = (sod - *h * 3600) / 60;
  *s = sod - *h * 3600 - *m * 60;
}

/*-------------------------------------------------------------------------
**
**      write_headers - Write CRD header records
**
**-----------------------------------------------------------------------*/
void
write_headers (FILE * str_out_crd, int first_pass, int new_pad, 
	int new_target)
{
  if (first_pass) write_h1 (str_out_crd, h1);
  if (first_pass || new_pad) write_h2 (str_out_crd, h2);
  if (first_pass || new_pad || new_target) write_h3 (str_out_crd, h3);
  write_h4 (str_out_crd, h4);
  write_c0 (str_out_crd, c0);
  write_60 (str_out_crd, d60);
}

/*-------------------------------------------------------------------------
**
**      write_data - Write CRD Data records
**
**-----------------------------------------------------------------------*/
void
write_data (FILE * str_out_crd, int reset_def)
{
  static double opressure = -999;
  static double otemperature = -999;
  static double ohumidity = -999;
  static double orefraction_corr = -999;
  static double otarget_CofM_corr = -999;
  static double ond_value = -999;
  static double otime_bias = -999;
  static double oazimuth = -999;
  static double oelevation = -999;
  static double ocal_delay_shift = -999;

  if (reset_def)
    {
      opressure = otemperature = ohumidity = -999;
      orefraction_corr = otarget_CofM_corr = ond_value = otime_bias = -999;
      oazimuth = oelevation = ocal_delay_shift = -999;
    }

  if (h4.data_type != 1)
    write_10 (str_out_crd, d10);
  else
    write_11 (str_out_crd, d11);

  if ((fabs (d12.refraction_corr - orefraction_corr) > 1 ||
       fabs (d12.target_CofM_corr - otarget_CofM_corr) > 1 ||
       fabs (d12.nd_value - ond_value) > 1 || 
       fabs (d12.time_bias - otime_bias) > 1) && h4.data_type != 1)
    {
      write_12 (str_out_crd, d12);
      orefraction_corr= d12.refraction_corr;
      otarget_CofM_corr= d12.target_CofM_corr;
      ond_value= d12.nd_value;
      otime_bias= d12.time_bias;
    }

  if (fabs (d20.pressure - opressure) > 0.009 || fabs (d20.temperature - otemperature) > 0.09 || fabs (d20.humidity - ohumidity) > 0.9)	/* For existing real data! Normally '5' */
    {
      write_20 (str_out_crd, d20);
      opressure = d20.pressure;
      otemperature = d20.temperature;
      ohumidity = d20.humidity;
    }

  if ((fabs (d30.azimuth - oazimuth) > 0.1 ||
       fabs (d30.elevation - oelevation) > 0.1) && h4.data_type != 1)
    {
      write_30 (str_out_crd, d30);
      oazimuth = d30.azimuth;
      oelevation = d30.elevation;
    }

  if (fabs (d40.cal_delay_shift - ocal_delay_shift) > 1)
    {
      write_40 (str_out_crd, d40);
      ocal_delay_shift = d40.cal_delay_shift;
    }
}

/*-------------------------------------------------------------------------
**
**      write_end_of_data_block - Write CRD End-of-data-block record
**
**-----------------------------------------------------------------------*/
void
write_end_of_data_block (FILE * str_out_crd, int data_type)
{
  if (data_type == 1)
    write_50 (str_out_crd, d50);
  write_h8 (str_out_crd);
}

/*-------------------------------------------------------------------------
**
**      write_end_of_file - Write CRD End-of-file record
**
**-----------------------------------------------------------------------*/
void
write_end_of_file (FILE * str_out_crd)
{
  write_h9 (str_out_crd);
}

/*-------------------------------------------------------------------------
**
**	setup_files		- Open input and output file names
**
**-----------------------------------------------------------------------*/
void
setup_files (int argc, char *argv[])
{
  char mrt_in[FNLEN] = { "" };
  char crd_out[FNLEN] = { "" };

  int found = 0, i;

/*  Get file names  */
  for (i = 1; i < argc; i += 2)
    {
      if (argv[i][0] == '-')
	{
	  if (argv[i][1] == 'i')
	    {
	      strcpy (mrt_in, argv[i + 1]);
	      printf ("mrt_in = [%s]\n", mrt_in);
	      found += 1;
	    }
	  else if (argv[i][1] == 'o')
	    {
	      if (found == 1)
		{
		  strcpy (crd_out, argv[i + 1]);
		  /*strcat (crd_out, ".frd"); */
		}
	      printf ("crd_out = [%s]\n", crd_out);
	      found += 2;
	    }
	}
    }
  if (found != 3)
    {
      printf ("Usage: merit_to_crd -i meritfile -o crdfile\n");
      exit (1);
    }

/*  open output QLD file  */
  if (strlen (mrt_in) > 0)
    {
      if ((str_in = fopen (mrt_in, "r")) == NULL)
	{
	  printf ("Could not open file %s\n", mrt_in);
	  exit (1);
	}
    }

/*  open output CRD files  */
  if ((str_out_fr = fopen (crd_out, "w")) == NULL)
    {
      printf ("Could not open file %s\n", crd_out);
      exit (1);
    }
}

/*-------------------------------------------------------------------------
**
**      get_sat_ids - Given a laser target's ilrs ID, norad ID, sic, or
**                    name, get the other 3 IDs.
**
**-----------------------------------------------------------------------*/
void
get_sat_ids (int mode, int *ilrs_id, int *norad_id, int *sic, char *target,
	     int *delta)
{
  FILE *sat_id_in;
  char *sat_id_file = "./targets.dat";
  char str[256], ttarget[11];
  char *status;
  int tilrs_id, tsic, tnorad_id = 0;
  int i, l;

  if (mode != 3)
    {
      for (i = 0; i < 10; i++)
	{
	  target[i] = ' ';
	}
      target[10] = '\0';
    }

  if ((sat_id_in = fopen (sat_id_file, "r")) == NULL)
    {
      printf ("Could not open file %s\n", sat_id_file);
      exit (1);
    }
  while ((status = fgets (str, 256, sat_id_in)) != NULL)
    {
      sscanf (str, "%s %*s %d %d %d %d", ttarget, &tsic, &tilrs_id,
	      &tnorad_id, delta);

      if (mode == 0 && tilrs_id == *ilrs_id)
	{
	  *norad_id = tnorad_id;
	  *sic = tsic;
	  strcpy (target, ttarget);
	  l = strlen (target);
	  if (l < 10)
	    target[l] = ' ';
	  target[10] = '\0';
	  break;
	}
      else if (mode == 1 && tsic == *sic)
	{
	  *ilrs_id = tilrs_id;
	  *norad_id = tnorad_id;
	  strcpy (target, ttarget);
	  l = strlen (target);
	  if (l < 10)
	    target[l] = ' ';
	  target[10] = '\0';
	  break;
	}
      else if (mode == 2 && tnorad_id == *norad_id)	/* useless now */
	{
	  *ilrs_id = tilrs_id;
	  *sic = tsic;
	  strcpy (target, ttarget);
	  l = strlen (target);
	  target[10] = '\0';
	  break;
	}
      else if (mode == 3 && strcmp (ttarget, target) == 0)
	{
	  *ilrs_id = tilrs_id;
	  *norad_id = tnorad_id;
	  *sic = tsic;
	  break;
	}
    }
  fclose (sat_id_in);
  /*printf ("sic %d delta %d\n", *sic, *delta);*/
}

/*-------------------------------------------------------------------------
**
**       get_station_id - get the 10 character station id by using
**                        the marker id and sites.dat file.
**
**-----------------------------------------------------------------------*/
void
get_station_id (int marker, char *station)
{
  FILE *sttn_id_in;
  char *sttn_id_file = "./sites.dat";
  char str[256], tstation[11];
  char *status;
  int tmarker;
  int i;

  for (i = 0; i < 10; i++)
    {
      station[i] = ' ';
    }
  station[10] = '\0';
  if ((sttn_id_in = fopen (sttn_id_file, "r")) == NULL)
    {
      printf ("Could not open file %s\n", sttn_id_file);
      exit (1);
    }
  while ((status = fgets (str, 256, sttn_id_in)) != NULL)
    {
      sscanf (str, "%d %s", &tmarker, tstation);

      if (tmarker == marker)
	{
	  strncpy (station, tstation, 4);
	  break;
	}
    }
  fclose (sttn_id_in);

}
