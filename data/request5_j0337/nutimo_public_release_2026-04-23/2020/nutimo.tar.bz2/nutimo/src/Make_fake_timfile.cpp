/* This code implements a timing model and fitting procedures aimed at studiyng th triple system J0337+1715 (Ransom et al. 2013)
 *
 * Written by Guillaume Voisin 2017 , LUTh, Observatoire de Paris, PSL Research University (guillaume.voisin@obspm.fr astro.guillaume.voisin@google.com)
 *
 * *

 */

#include <iostream>
#include <chrono>
#include <random>
#include <cfloat>
#include "Utilities.h"
#include <stdio.h>
#include <string.h>

#include "Fittriple.h"
#include "IO.h"
#include "Constants.h"



// Needs at least gcc 4.8
// To compile without fittriple for monoproc : g++-4.8 -g -std=gnu++11 -o MCMCtest.exe MCMC_parallelaffineinvariant.cpp Utilities.cpp acc.cpp
// To run without fittriple : ./MCMCtest.exe fakeparfile fakedatfile mcmout.dat nbw_per_proc maxit chain_freq coeur (moy_freq) (previous_chain)
// To compile with fittriple for monoproc : g++-4.8  -g -std=gnu++11 -o MCMCtest.exe MCMC_parallelaffineinvariant.cpp Utilities.cpp acc.cpp  AllTheories3Bodies.cpp Delay_brut.cpp Fittriple-compute.cpp Fittriple-init.cpp Fittriple-IO.cpp Fittriple-diagnostics.cpp IO.cpp  Orbital_elements.cpp Spline.cpp  Diagnostics.cpp Parameters.cpp -Bstatic -I/usr/local/src/boost_1_55_0/  -I/usr/share/tempo2/include/ -L./libstatictempo2  -ltempo2 -lsofa
// To compile without fittriple and MPI :  mpic++ -D MPIMODE -std=gnu++11 -o MCMCtest.exe MCMC_parallelaffineinvariant.cpp Utilities.cpp acc.cpp
// To run : mpiexec -n 4 ./MCMCtest.exe parfile timfile outfile.dat nb_of_walkers_per_proc number_of_ensemble_iterations chain_saving_freq



using namespace std;



int main ( int argc, char *argv[] ) {

// Input/output
    char  parfile[500] ;
    char  datafile[500] ;
    value_type noisestddev;
    char faketimfile[500];
    char fakebats[550];
    char turnfile[550];

    strcpy(fakebats,"BATs-");
    strcpy(turnfile,"turns-");


    if (argc < 5 )
    {
      printf("Make_fake_timfile.exe parfile original_timfile noisestddev faketimfile\n");
      return 1;
    }
    strcpy(parfile,argv[1]) ;
    strcpy(datafile, argv[2]);
    sscanf(argv[3], "%Le",&noisestddev) ;
    strcpy(faketimfile, argv[4]);
    strcat(fakebats,faketimfile);
    strcat(turnfile,faketimfile);
    
    int i = 0;
// Random generator init
    // obtain a seed from the system clock:
    unsigned seed1 = chrono::system_clock::now().time_since_epoch().count();
    mt19937 randomgen(seed1);  // mt19937 is a standard mersenne_twister_engine
    normal_distribution<double> gaussian_noise(0.,noisestddev);

    Fittriple fonction(parfile,datafile);

    long double * toas;
    long double * sats_toas;
    double * noise;
    toas = (long double *) malloc(sizeof(value_type) * fonction.ntoas);
    sats_toas = (long double *) malloc(sizeof(value_type) * fonction.ntoas);
    noise = (double *) malloc(sizeof(double) * fonction.ntoas);

    fonction.Compute_fake_BATs_from_parameters(toas);
    // Uncomment to get fake bats as well
    Savetxt_L(fakebats, toas,  static_cast<int>(fonction.ntoas)) ;

    // Save turn numbers
    fonction.Save_turn_numbers(turnfile);

    fonction.Compute_fake_SATs_from_BATs(toas, sats_toas);
    for (i = 0; i < fonction.ntoas; i++)
    {
      sats_toas[i] += gaussian_noise(randomgen) * 1.e-6 / daysec ; // add noise in days
      noise[i] = static_cast<double>(noisestddev);
    }
    Write_new_tim_file(datafile, faketimfile, sats_toas, noise);

    free(sats_toas);
    free(toas);

    return 0;
    }
