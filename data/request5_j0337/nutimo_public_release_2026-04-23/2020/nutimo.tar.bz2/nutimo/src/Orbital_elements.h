/* This code implements a timing model and fitting procedures aimed at studiyng th triple system J0337+1715 (Ransom et al. 2013)
 * 
 * Written by Guillaume Voisin 2017 , LUTh, Observatoire de Paris, PSL Research University (guillaume.voisin@obspm.fr astro.guillaume.voisin@google.com)
 * 
 */

#ifndef Orbital_elements_h
# define Orbital_elements_h

#include <cmath>
#include "Constants.h"

long double Solve_Kepler(long double dt, long double P, long double e, long double err = pow(10.L,-19)) ;


void orbel2statevect(value_type t, value_type e, value_type a1, value_type om1, value_type angli, value_type tperi1, value_type OrbPeriod, value_type om_an1 ,
                     value_type statevector1[6],
                     int jours=1, int solarframe=1) ;
                     
void orbel2statevect_1pn(value_type t, value_type et, value_type ar, value_type om1, value_type angli, value_type tperi1, value_type OrbPeriod, value_type om_an1 , 
                        value_type m1, value_type mc,
                     value_type statevector1[6],
                     int jours=1, int solarframe=1) ;

    
#endif