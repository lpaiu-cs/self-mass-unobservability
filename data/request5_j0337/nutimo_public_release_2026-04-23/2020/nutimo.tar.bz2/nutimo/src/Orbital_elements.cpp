/* This code implements a timing model and fitting procedures aimed at studiyng th triple system J0337+1715 (Ransom et al. 2013)
 *
 * Written by Guillaume Voisin 2017 , LUTh, Observatoire de Paris, PSL Research University (guillaume.voisin@obspm.fr astro.guillaume.voisin@google.com)
 *
 */

#include "Constants.h"
#include <cmath>
#include <cstring>
# include <iostream>
#include "Utilities.h"

using namespace std ;

long double Solve_Kepler(long double dt, long double P, long double e, long double err = pow(10.L,-19)){
    /*
        Fixed point method to solve Kepler's equation : see Beutler's book
        dt : time elapsed since last pariastron passage
        P  : Period
        e  : eccentricity
        err : rounding error to achieve
    */
    long double  U = deuxpi * dt / P ;
    long double  dU = dix ;
    long double  sigma = zero ;
    int i = 0 ;

    while ( abs(dU) > err or i > 100 ) {
        sigma = 2.*pi*dt/P ;
        dU = (sigma - (U - e * sin(U) ) ) / ( un - e * cos(U) ) ;
        U += dU ;
        i += 1 ;
    }
    if (i == 101) cout << "Warning in 'Solve_Kepler' : maximum number of iterations reached. Last residual was : " << dU << endl ;

    return U ;
}


void orbel2statevect(value_type t, value_type e, value_type a1, value_type om1, value_type angli, value_type tperi1, value_type OrbPeriod, value_type om_an1 ,
                     value_type statevector1[6],
                     int jours=1, int solarframe=1) {
    /*
    Renvoie les positions et vitesses de l'objet 1 membre d'un système gravitationnel à deux corps de masses m1 et m0

        t       : temps (en jours, ou en s si jours=False)
        e       : excentricité
        a1      : demi grand axe de l'objet 1
        om1     : longitude du périastre de l'objet 1, par rapport à la ligne de noeuds ascendants (rad)
        angli   : angle 0 >= (h,nss) >= -pi  avec h le moment angulaire du système, nss le vecteur pointant du barycentre du système solaire vers celui du système
        tperi1  : époque d'un passage au périastre de l'objet 1 (en jours, ou en s si jours=False)
        jours   : True si les temps sont spécifiés en jours, False s'ils le sont en secondes


    Renvoie la position et la vitesse à chaque temps en m et m/s, dans le référentiel (na,nss,n3') par défaut et dans (na,h,n3) si solarFrame=False:
        nss est np.array([0,1,0])

        r1 = np.ndarray(len(t),3)   : position de 1 en m
        r1_t = np.ndarray(len(t),3) : vitesse de 1 en m/s

    Ressource : Beutler, Celestial Mechanics 1, $4.2.2
    */


    value_type et = e ;
    value_type a1t = a1 ;
    value_type om1t = om1 ;
    value_type anglit = angli ;
    value_type tperi1t = tperi1 ;

    value_type errKepler = pow(10.L, -18) ;

    value_type P;
    value_type dt ;
    value_type U = zero ;
    value_type sinv = zero ;
    value_type cosv = zero ;
    value_type v = zero ;
    value_type thet = zero ;
    value_type nr1 = zero ;
    value_type U_t = zero ;
    value_type trans[3] = {zero, zero, zero } ;
    value_type b =zero;
    

    P = OrbPeriod ;  //   2.*pi*a**2*np.sqrt(1.-et**2) / h  # Période


    // Résout Kepler

    dt = fmod( abs( t-tperi1t ),  P ) * sgn( t-tperi1t ) ;
    U = Solve_Kepler(dt, P, et, errKepler)  ;

    sinv = sqrt( un - pow(et, 2) ) * sin(U) / ( un - et * cos(U) );
    cosv = ( cos(U) - et ) / ( un - et * cos(U) ) ;
    v = inversetrigo(cosv , sinv) ;
    // ! Test !
    b = sqrt((un + et)/(un -et) ) ;
   // v = deux * atan(b * tan(U*undemi) ) ;
  //  cout << " test " <<  abs(v - deux * atan(b * tan(U*undemi) )) << endl;
    //
    thet = v + om1t ;
    nr1 = a1t * (un - et * cos( U ) ) ;

    value_type r1[3] = { cos( thet ) , sin( thet ) , zero } ;

    U_t = deuxpi * a1t / ( P * nr1 ) ;

    value_type r1_t[3] = { - sin( U ) , sqrt(un  - pow(et, 2) ) * cos( U ) , zero } ;

// // ! Test !
//     value_type nr1_t =  et *sin(U) ;//* U_t;
//
//     //cout << "test " << ar << "  " << U_t << "  " << er << "  " << et << "  " << etheta << endl ;
//     //printf("test %.19Le %.19Le %.19Le \n", J2 , K , eRR);
//     value_type v_t =  nr1 / a1t * b* deux / (deux*pow(cos(undemi*U),2) * (pow(b*tan(undemi*U),2) + un) ) ;//* U_t;
//     value_type r1_tbis[3] = { -v_t * sin( v ) + cos(v) *  nr1_t ,
//                             v_t * cos(v) + sin(v) * nr1_t,
//                             zero } ;
//     // printf(" test r1t , %.19Le, %.19Le, %.19Le \n",  r1_t[0], r1_t[1],   r1_t[2]) ;
//    //  printf(" test r1t , %.19Le, %.19Le, %.19Le \n", (r1_tbis[0] - r1_t[0]) /r1_t[0],(r1_tbis[1] - r1_t[1]) /r1_t[1],   (r1_tbis[2] - r1_t[2]) );///r1_t[2]) ;
// // fin test

     r1_t[0] *= U_t * a1t ;     r1_t[1] *= U_t * a1t ;     r1_t[2] *= U_t * a1t ;
     rot2D( om1t,r1_t , 0 , 1 ) ;       // Passe dans le repère (na,-n3,h/nh)

     if (solarframe == 1) {
        rot2D(anglit, r1_t, 1 , 2 ) ; // Passe dans le repère (na,n3',nss)
        rot2D(anglit,r1 , 1 , 2 ) ;        // Passe dans le repère (na,n3', nss)
        rot2D(om_an1, r1, 0 , 1 ) ;      // Passe dans le repère (x, y, nss) (ou x et y sont arbitraires)
        rot2D(om_an1, r1_t, 0 , 1) ;   // idem
        r1[0] *= nr1 ; r1[1] *= nr1 ; r1[2] *= nr1 ;
     }


    if (jours == 1 ) {
        r1_t[0] /= daysec ; r1_t[1] /= daysec ; r1_t[2] /= daysec ;
    }

    statevector1[0] = r1[0] ; statevector1[1] = r1[1] ; statevector1[2] = r1[2] ;
    statevector1[3] = r1_t[0] ; statevector1[4] = r1_t[1] ; statevector1[5] = r1_t[2] ;

    return ;

}



void orbel2statevect_1pn(value_type t, value_type et, value_type ar, value_type om1, value_type angli, value_type tperi1, value_type OrbPeriod, value_type om_an1 ,
                        value_type m1, value_type mc,
                     value_type statevector1[6],
                     int jours=1, int solarframe=1) {
    /*
     * Based on Damour & Deruelle 1985
     *
    Renvoie les positions et vitesses de l'objet 1 membre d'un système gravitationnel à deux corps de masses m1 et m0

        t       : temps (en jours, ou en s si jours=False)
        et      : excentricité "temporelle
        ar      : demi grand axe de l'objet 1 par rapport au barycentre 1PN
        om1     : longitude du périastre de l'objet 1, par rapport à la ligne de noeuds ascendants (rad)
        angli   : angle 0 >= (h,nss) >= -pi  avec h le moment angulaire du système, nss le vecteur pointant du barycentre du système solaire vers celui du système
        tperi1  : époque d'un passage au périastre de l'objet 1 (en jours, ou en s si jours=False)
        jours   : True si les temps sont spécifiés en jours, False s'ils le sont en secondes
        m1 : masse de l'objet 1 (en masse solaire)
        mc : masse du compagnon (masse 0)

    Renvoie la position et la vitesse à chaque temps en m et m/s, dans le référentiel (na,nss,n3') par défaut et dans (na,h,n3) si solarFrame=False:
        nss est np.array([0,1,0])

        r1 = np.ndarray(len(t),3)   : position de 1 en m
        r1_t = np.ndarray(len(t),3) : vitesse de 1 en m/s

    Ressource : Damour & Deruelle 1985, Beutler, Celestial Mechanics 1, $4.2.2
    */

    const value_type GMsol = Ggrav  * Msol ;

    value_type Mtot = m1 + mc;  // after formula DD85 2.4b
    value_type nu = m1 * mc / pow(Mtot,2);
    value_type aRR = Mtot / mc * ar ; // DD85 6.3a
    value_type eRR = et * (un + GMsol * Mtot / (aRR*clight2) * (quatre -troisdemis * nu) ) ; // DD85 3.8b
    value_type er = eRR * ( un - GMsol * m1 * (m1 - mc) / (deux * Mtot * aRR * clight2) ) ; // DD85 6.3b
    value_type etheta = eRR * (un + GMsol * m1 * mc / (deux * Mtot * aRR * clight2 ) ) ; // DD85 4.13


    value_type anglit = angli ;

    value_type errKepler = pow(10.L, -18) ;

    value_type P;
    value_type dt ;
    value_type U = zero ;
    value_type v = zero ;
    value_type v_t = zero;
    value_type thet = zero ;
    value_type nr1 = zero ;
    value_type nr1_t = zero ;
    value_type U_t = zero ;
    value_type trans[3] = {zero, zero, zero } ;
    value_type b = zero;
    value_type J2 =  zero;
    value_type K = zero;



    //Vérifie que angli est dans la bonne plage ou tente une correction

//     if (anglit > zero and fmod(anglit, deuxpi) < pi)   anglit = -(fmod(anglit,deuxpi)) ;
//     if (anglit > zero and fmod(anglit, deuxpi) >= pi )  anglit = fmod(anglit,deuxpi) - deuxpi ;
//     if (anglit <= zero and fmod((-anglit),deuxpi) < pi ) anglit = -fmod((-anglit),deuxpi) ;
//     if (anglit <= zero and fmod((-anglit),deuxpi) >= pi ) anglit = -(-fmod((-anglit),deuxpi) + deuxpi) ;
//     if ( anglit != angli )  cout << "orbel2statevect : 0 >= angli >= -pi not satisfied. Now assuming angli =  " << anglit << ". Old angli : " << angli << endl;
//

    P = OrbPeriod ;  // Période


    // Résout Kepler

    dt = fmod( abs( t-tperi1 ),  P ) * sgn( t-tperi1 ) ;
    //dt = t - tperi1;
    U = Solve_Kepler(dt, P, et, errKepler)  ;

    // Compute Ae with formula DD86 17d
    value_type Ae = U + deuxpi * ( t-tperi1  - dt) / P ;
    value_type Aeold = zero;
    value_type Ae_inter = deux;
    value_type Aefactor = etheta / (un + sqrt(un - pow(etheta,2)) );
//    printf("\n test aez deuxpi %.19Le\n\n", ( t-tperi1  - dt) / P);
    int i = 1;
    do
    {
        Aeold = Ae;
        Ae_inter *= Aefactor;
        Ae += sin(i*U) *Ae_inter / i;
        i+=1;
    } while ( abs((Ae - Aeold)/ Ae) > errKepler) ;

//     //! Test !
//     value_type nn = 86400.*sqrt(GMsol*Mtot/pow(aRR,3)) * ( un + (m1*mc/pow(Mtot,2) - neuf) * GMsol *Mtot / (deux*aRR*clight2) );
//     printf("\n n test %.19Le, %.19Le, %.19Le \n\n", P,deuxpi / nn, P - deuxpi/nn );
//     // fin test

    //sinv = sqrt( un - pow(et, 2) ) * sin(U) / ( un - et * cos(U) );
    //cosv = ( cos(U) - et ) / ( un - et * cos(U) ) ;
    J2 = aRR * (un - pow(eRR,2) ) * ( GMsol * Mtot ) ; // DD85 4.15
    K = sqrt(J2 / ( J2 - six* pow(GMsol * Mtot / clight,2) ) ) ; //DD85 4.14
  //  K *= deux; // factor 2 in the function Ae(u)
    b = sqrt((un + etheta)/(un -etheta) ) ;
    v = K * Ae;//* atan(b * tan(U*undemi) ) ;
    thet = v + om1 ;
    nr1 = ar * (un - er * cos( U ) ) ;
//             printf("\ntest ae %.19Le %.19Le %.19Le %i \n\n", tan(0.5*Ae), b * tan(U*undemi) , (tan(0.5*Ae) - b * tan(U*undemi))/(b * tan(U*undemi)), i );

    value_type r1[3] = { cos( thet ) , sin( thet ) , zero } ;

    U_t = deuxpi / ( P *  (un - et * cos( U ) )) ;
    nr1_t = ar * U_t * er *sin(U);

    //cout << "test " << ar << "  " << U_t << "  " << er << "  " << et << "  " << etheta << endl ;
    //printf("test %.19Le %.19Le %.19Le \n", J2 , K , eRR);

    // Compute derivative of Ae with respect to U (here variable Ae = dAe/dU) using DD86 17d
    i = 1;
    Ae_inter = deux;
    Ae = un;
    do
    {
        Aeold = Ae;
        Ae_inter *= Aefactor;
        Ae += cos(i*U) *Ae_inter ;
        i+=1;
    } while ( abs((Ae - Aeold)/ Ae) > errKepler) ;

    v_t = K* U_t * Ae * nr1 ; // derivative of v times nr1

    //v_t = U_t * nr1 * b*K / (deux*pow(cos(undemi*U),2) * (pow(b*tan(undemi*U),2) + un) ) ;
    value_type r1_t[3] = { -v_t * sin( v ) + cos(v) *  nr1_t ,
                            v_t * cos(v) + sin(v) * nr1_t,
                            zero } ;


  //   r1_t[0] *= U_t * a1t ;     r1_t[1] *= U_t * a1t ;     r1_t[2] *= U_t * a1t ;
     rot2D( om1,r1_t , 0 , 1 ) ;       // Passe dans le repère (na,-n3,h/nh)

 if (solarframe == 1) {
        rot2D(anglit, r1_t, 1 , 2 ) ; // Passe dans le repère (na,n3',nss)
        rot2D(anglit,r1 , 1 , 2 ) ;        // Passe dans le repère (na,n3', nss)
        rot2D(om_an1, r1, 0 , 1 ) ;      // Passe dans le repère (x, y, nss) (ou x et z sont arbitraires)
        rot2D(om_an1, r1_t, 0 , 1) ;   // idem
        r1[0] *= nr1 ; r1[1] *= nr1 ; r1[2] *= nr1 ;
     }


    if (jours == 1 ) {
        r1_t[0] /= daysec ; r1_t[1] /= daysec ; r1_t[2] /= daysec ;
    }

    statevector1[0] = r1[0] ; statevector1[1] = r1[1] ; statevector1[2] = r1[2] ;
    statevector1[3] = r1_t[0] ; statevector1[4] = r1_t[1] ; statevector1[5] = r1_t[2] ;

    return ;

}
