#coding:utf8
#/* This code implements a timing model and fitting procedures aimed at studiyng th triple system J0337+1715 (Ransom et al. 2013)
 #* 
 #* Written by Guillaume Voisin 2017 , LUTh, Observatoire de Paris, PSL Research University (guillaume.voisin@obspm.fr astro.guillaume.voisin@google.com)
 #* 
 #*/
 
import corner as cn
import numpy as np
from pylab import *
from acor_python import acorpython

symbols = [r"$f$",                      #0
                   r"$f'$",
                   r"$e_I\sin \omega_I$",       
                   r"$a_p\sin i_I$",            #3
                   r"$e_I\cos\omega_I$",
                   r"$a_p\cos i_I$",            #5
                   r"${t_{\mathrm{asc}}}_I$",
                   r"$P_I$",
                   r"$e_O\sin \omega_O$",       #8
                   r"$a_b\sin i_O$",
                   r"$e_O\cos\omega_O$",
                   r"$a_b\cos i_O$",            #11
                   r"${t_{\mathrm{asc}}}_O$",
                   r"$P_O$",
                   r"$(m_p+m_i)/2$",                    #14
                   r"$M_i$",#r"$(m_p-m_i)/2$",
                   r"$m_o$",
                   r"$\Omega_o$",                #17
                   r"$\delta\Omega$",           #18
                   r"$\delta\phi_0$",
                   r"$\Delta$",
                   r"$\alpha$",                 #21
                   r"$\delta$",
                   r"$d$",
                   r"$\mu_\alpha$",             #24
                   r"$\mu_\delta$",
                   r"$\mu_d$",
                   r"$\mathrm{DM}$",            #27
                   r"$\mathrm{DM}'$"
                   ]

unitstr= [r"\mathrm{s}^{-1}", r"\mathrm{s}^{-2}",
                  r"0",r"\mathrm{ls}",r"0",r"\mathrm{ls}",r"\mathrm{d}",r"\mathrm{d}",
                  r"0",r"\mathrm{ls}",r"0",r"\mathrm{ls}",r"\mathrm{d}",r"\mathrm{d}",
                  r"M_{\odot}",r"M_{\odot}",r"M_{\odot}",r"\degree", r"\degree",r"0", r"0",r"0",r"0",r"\mathrm{ly}",
                  r"\mathrm{mas}/\mathrm{yr}",r"\mathrm{mas}/\mathrm{yr}", r"\mathrm{mas}/\mathrm{yr}",
                  r"\mathrm{pc}\cdot\mathrm{cm}^{-3}",  r"\mathrm{pc}\cdot\mathrm{cm}^{-3}\mathrm{yr}^{-1}"
                  ]

paramnames = [symbols[i] + " ($" + unitstr[i] + "$) " for i in range(len(symbols))]
### mcmc-testnewmodel0_mcmc-288x200000d50.res
#parameter_map = [21, 22, 24, 25, 0, 1, 2, 3, 4, 5, 6, 8, 9, 10, 11, 12, 14, 15, 16, 18, 20]

### mcmc-testnewmodel0posransom_mcmc-192x1000000d50
#parameter_map = [24, 25, 0, 1, 2, 3, 4, 5, 6, 8, 9, 10, 11, 12, 14, 15, 16, 18, 20]




class mcmcresult :
    def __init__(self,chains=None, chi2=None, resfile=None, parameter_object = None, parameter_map=None, parameter_scales=None, parameter_initials=None, symbols=None):
        '''
            parameter_object is a object with methods "Get_fitted_parameter_map", "Get_parameter_scales", and "Get_fitted_parameter_names".
            If parameter_map, parameter_scales or symbols are given the values obtained from parameter_object are overwritten. 
        '''
        if resfile is not None :
            res = np.loadtxt(resfile, comments='#')
            self._ndim = res.shape[1] - 1
            self.res = np.ndarray((res.shape[0], self._ndim))
            self.chi2 = res[:,-1]
            self.res = res[:,:self._ndim]
        else :
            self.res = chains.copy()
            self.chi2 = chi2.copy()
            self._ndim = self.res.shape[1]
        
        if parameter_object is not None :
            self.parammap = np.array(parameter_object.Get_fitted_parameter_map())
            self.paramscales = np.array(parameter_object.Get_parameter_scales())
            self.symbols = parameter_object.Get_parameter_names()
            self.paraminitials = np.array(parameter_object.Get_parameters())
            print self.parammap
            print self.paramscales
            print self.symbols

        if parameter_map is not None :
            self.parammap = np.array(parameter_map)
            if len(parameter_map) < self._ndim :
                print "Error : parameter map too short ! %i < %i"%( len(parameter_map), self._ndim)
        elif parameter_object is None :
            self.parammap = np.arange(self._ndim) 
            
        if symbols is not None : 
            self.symbols = symbols[0: max(self.parammap)+1]
        elif parameter_object is None :
            self.symbols = ["{:i}".format(i) for i in range(max(self.parammap)+1)]    
            
        if parameter_scales is not None:
            self.paramscales = np.array(parameter_scales)
        elif parameter_object is None :
            self.paramscales = np.ones(max(self.parammap)+1)
            
        if parameter_initials is not None:
            self.paraminitials = np.array(parameter_initials)
        elif parameter_object is None :
            self.paraminitials = np.zeros(max(self.parammap)+1)
       
        for i in range(self._ndim) :
            self.res[:, i] *= self.paramscales[self.parammap[i]] 
            self.res[:, i] += self.paraminitials[self.parammap[i]] 
                
            

            
        #if parameter_map is not None :
           #for i in range(self._ndim) :
               #self.res[:, parameter_map[i]] = res[:, i ]
        #else :
            #self.res = res[:, :ndim]
            
        self.refparams = np.zeros(self._ndim)
            
        return
    
    def Mean_parameters(self, start=0, end=-1):
        '''
            Give an array of the chain averaged between the iterations "start" and "end".
        '''
        mean = np.zeros(self._ndim)
        for i in range(self._ndim):
            mean[i] = self.res[start:end,i].mean()
        return mean
    
    def Autocorrelation_time(self, start=0, end=-1) :
        '''
            autocorrelation times, standard deviations = Autocorrelation_time(start=0, end=-1)
            start and end give the range of steps to take into account in the computation of autocorrelation times
        '''
        autocor = np.ndarray(self._ndim)
        sigmas = np.ndarray(self._ndim)
        for i in range(self._ndim) : 
            autocor[i],mean, sigmas[i]  = acorpython(self.res[start:end, i])
        return autocor, sigmas
    
    def Corner_plot(self, start=0, end=-1):
        '''
            Create a corner plot using the chain between iterations "start" and "end"
        '''
        labels = [self.symbols[self.parammap[i]] for i in range(self._ndim) ]
        fig = cn.corner(self.res[start:end], labels = labels, label_kwargs={'fontsize':'x-large', })
        plts = fig.get_axes()
        formatter = matplotlib.ticker.ScalarFormatter(useMathText='True')
        formatter.set_scientific(True)
        formatter.set_powerlimits((0,0))
        xmin = 10.
        ymin = 10.
        for ax in plts : 
            if ax.get_position().xmin < xmin : xmin = ax.get_position().xmin
            if ax.get_position().ymin < ymin : ymin = ax.get_position().ymin
            
        for ax in plts : 
            if ax.get_position().xmin == xmin : 
                formatter = matplotlib.ticker.ScalarFormatter(useMathText='True')
                formatter.set_scientific(True)
                formatter.set_powerlimits((0,0))
                ax.yaxis.set_major_formatter(formatter)
            if ax.get_position().ymin == ymin : 
                formatter = matplotlib.ticker.ScalarFormatter(useMathText='True')
                formatter.set_scientific(True)
                formatter.set_powerlimits((0,0))
                ax.xaxis.set_major_formatter(formatter)
                 
            #ax.yaxis.set_major_formatter(formatter)
            #ax.ticklabel_format(style='sci', scilimits=(0,0), axis='both') 
        return fig
    

    def Chain_plot(self, start = 0, end =-1, average_window=1):
        '''
            fig = Chain_plot(start = 0, end =-1, average_window=1)
            
            Plot the chain between step "start" and step "end".
            Plot in blue horizontal lines the value of parameter in mcmcresult.parameter_initials
            Plot in red the value of the chain averaged over a sliding window of size "average_window". If average_window <=1, do not plot. 
        '''
        labels = [self.symbols[self.parammap[i]] for i in range(self._ndim) ]
        fig = figure(figsize=(16,30))
        if end < 0 :
            maxit = self.res.shape[0] + end 
        else :
            maxit = end 
        naverage = (maxit -start) / average_window
        print naverage
        iternb = start + np.arange(maxit - start)
        aviter = start + np.arange(naverage)*average_window
        avchaine = np.ndarray((self._ndim+1, naverage))
        for i in range(self._ndim):
            plt = fig.add_subplot(self._ndim+1,1,i+1)
            plt.plot(iternb, self.res[start:end,i], ',g')
            plt.hlines(self.refparams[i], start, maxit,  'b')
            if average_window > 1 : 
                for j in range(naverage):
                    avchaine[i,j] = (self.res[start + average_window * j : start + average_window*(j+1) -1, i]).mean()
                plt.plot(aviter, avchaine[i], '-r')
            plt.set_ylabel(labels[i])
        #    plt.yaxis.label.set_fontsize('x-large')
            plt.ticklabel_format(style='sci', scilimits=(0,0), axis='y') 
            
            
        plt = fig.add_subplot(self._ndim+1,1,self._ndim+1)
        i = self._ndim
        plt.plot(iternb, self.chi2[start :end], ',g')
        if average_window > 1 : 
                for j in range(naverage):
                    avchaine[i,j] = (self.chi2[start + average_window * j : start + average_window*(j+1) -1]).mean()
                plt.plot(aviter, avchaine[i], '-r')
        plt.set_ylabel("$-\chi^2$")
        #plt.yaxis.label.set_fontsize('x-large')
        plt.ticklabel_format(style='sci', scilimits=(0,0), axis='y') 
         
        fig.tight_layout(rect=(0,0,1,0.90), pad =1.11)
        fig.set_tight_layout(True)
        return fig# , avchaine, aviter
    
    
    
    def Parameter_filter(self, param_nb, minvalue, maxvalue ):
        '''
            Return a mcmcresult object with only the steps of the chain for which min value < parameters[param_nb] < maxvalue
            
            param_nb is the parameter as given by Fittriple objects, and mcmcresult.param_map is used to find the corresponding index in the chain. 
            
            If param_nb, minvalue, and maxvalue are a list or an array, then do it for the set of parameters in paramnb
        '''
        paramnb1 = np.array([param_nb]) 
        paramnb = np.ndarray(paramnb1.shape) 
        maxpa = self.parammap.max()
        for idim in range(paramnb.size): # Invert param_nb using param_map
            i=0
            while (i <= maxpa and self.parammap[i] != paramnb1[idim]):
                i+=1
            if i > maxpa : 
                print "Error : parameter number does not exist"
            paramnb[idim] = i
                
        mins = np.array([minvalue])
        maxs = np.array([maxvalue])
        
        for idim in range(paramnb.size) :
            im = 0
            chi2i = np.ndarray(self.chi2.shape)
            resi = np.ndarray(self.res.shape)
            for i in range(self.res.shape[0]):
                if (self.res[i, paramnb[idim]] < maxs[idim]) and  (self.res[i, paramnb[idim]] > mins[idim]):
                    resi[im] = self.res[i]
                    chi2i[im] = self.chi2[i]
                    im += 1 
            chi2i = chi2i[:im]
            resi = resi[:im]
        
        
        return mcmcresult(chains=resi, chi2=chi2i, resfile=None,  parameter_map=self.parammap.copy(), 
                          parameter_scales=np.ones(self.parammap.max()+1), parameter_initials=self.paraminitials.copy(), symbols=self.symbols)
