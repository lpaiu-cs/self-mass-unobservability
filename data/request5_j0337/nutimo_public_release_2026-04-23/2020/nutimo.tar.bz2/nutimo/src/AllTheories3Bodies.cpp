/* This code implements a timing model and fitting procedures aimed at studiyng th triple system J0337+1715 (Ransom et al. 2013)
 *
 * Written by Guillaume Voisin 2017 , LUTh, Observatoire de Paris, PSL Research University (guillaume.voisin@obspm.fr astro.guillaume.voisin@google.com)
 *
 */
// For the boost library :
// Copyright Ralf W. Grosse-Kunstleve 2002-2004. Distributed under the Boost
// Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
/*
******* !!!!! **********
Erreur avec gcc 4.8 pour la génération du boost::python !
Marche avec gcc 4.6, voir http://itk-users.7.n7.nabble.com/ITK-Build-Failing-td32665.html
pour la marche suivie pour faire cohabiter les deux versions
Erreur renvoyée par py++ :
gccxml-0.9/GCC/4.8/xmmintrin.h:1215: error: '__builtin_ia32_pause' was not declared in this scope


Compilation : g++ -c -I/usr/local/lib/boost_1_55_0/ AllTheories3Bodies.cpp

Ce code permet d'effectuer l'intégration des équations du mouvement de trois corps en intéraction gravitationnelle au premier ordre post-newtonien de la relativité générale.
cf Will, "Theory and experiment in gravitational physics".
Il s'agit d'une modification de Newtonian3Bodies.cpp et Newtonian3Bodies.hpp où la routine " Integrateur::rhs" est modifiée.
*/

#include <boost/numeric/odeint.hpp>
#include <iostream>
#include <fstream>
#include <string>
#include <cmath>
#include <valarray>
#include "AllTheories3Bodies.h"
# include "Constants.h"
#include "Utilities.h"

    using namespace std;
    using namespace boost::numeric::odeint;
  //  using namespace IntegratorScope;

// ***** Implementation Integrateur (newtonian-3-body integrator)
const int nbody =3;
valarray<valarray<valarray<value_type> > > dx(3);
valarray<valarray<valarray<value_type> > > ns(3);
valarray<valarray<value_type> >  rs(3);
valarray<valarray<value_type> > vs(3);
valarray<value_type>  vvs(3);
valarray<value_type> inter(3);
valarray<value_type> onebodyinter(3);
valarray<value_type> inter1(3);
valarray<value_type> inter2(3);
valarray<value_type> inter3(3);
value_type sinter = zero;
value_type sinter1 = zero;
value_type interflt = 0.;
value_type rmb = 0.;
int n1,n2,n3;
valarray<value_type> x (18);
valarray<value_type> dxdt(0., 18);
value_type Q1Ad = 1.;

// Dimensional coefficients of the differential equation system
    value_type k0 =1. ;
    value_type k1= 1. ;
    value_type k2 = 1. ;
// Body masses (in solar masses)
    value_type M0, M1, M2;
    valarray<value_type> Ms(3); // = {M0, M1, M2}; // Masses

// General SEP violation parameters
    value_type gammabar[3][3];
    value_type betabar[3][3][3];
    value_type Gg[3][3];

// SEP violation parameters
    value_type SEP_D; // In newtonian : M0_gravitational = (1 + SEP_D) M0_inertial

// Quadrupole parameters
    vector<value_type> quadrupole(4,zero);
    bool quadrupole_enabled;

// // Physical constants
//     const value_type Ggrav = 6.67384e-11 ;      // m^3 s^-2 kg^-1
//     const value_type clight = 299792458. ;     // m/s

// Adimensioned constants (prior to integration thanks to parameters given by the user)
    value_type GgravAd = Ggrav ;
    value_type G2oC2 = pow( Ggrav/clight , 2) ;
    value_type GoC2 = Ggrav / pow(clight , 2) ;
    value_type clightAd = clight;
    value_type clightAd2 = clight * clight;

//  Rough estimate of the quadrupolar momentum of the 0.2Msol white dwarf, from K. Boshkayev, H. Quevedo and B. Zhami 2017
    const value_type Qwd = 7.395682251336515e+48 ; // kg.m^2 / (2pi/Spin Period)^2
    value_type QwdAd = Qwd; // QwdAd = dimensionless version of Qwd, done further in the code


// Natural coordinates base vectors :
    valarray<value_type> e_xnat(3);
    valarray<value_type> e_ynat(3);
    valarray<value_type> e_znat(3);

// Type of integrator to be used (value equal to Integrateur::integrator_type )
    int integrator_choice;

// RHS counter : number of times a rhs has been called
    int rhs_counter =0;

// ------------- Small utilities
    int mantissa = 15;
value_type trimfloat(value_type x, int mantissa)
{
    value_type test;
    int puissance;

    puissance = -50;
    test = abs(x)/pow(dix,puissance);
    while((test > 10. or test <= 1.) and test != 0.)
    {
        test = abs(x)/pow(dix,puissance);
        puissance++;
    }
    puissance--;
    test = x * pow(dix,mantissa - 1 - puissance);
    if (test < 0.) test = test + floor(abs(test));
    if (test > 0.) test = test - floor(test);
    test = x - test/ pow(dix,mantissa - 1 - puissance);
    return test;
}



void Integrateur::Initialise()
{
  // Initialise computing variaibles (used in rhs)
  for (int i = 0 ; i < 3 ; i++)
  {
  dx[i] =  valarray<valarray<value_type> >(3) ;
  ns[i] =  valarray<valarray<value_type> >(3) ;
  rs[i] = valarray<value_type> (3) ;
  vs[i] = valarray<value_type> (3) ;
      for (int j = 0 ; j < 3 ; j++)
      {
      dx[i][j] = valarray<value_type>(3) ;    // Differences
      ns[i][j] = valarray<value_type>(3) ;    // unit vectors
      }
  }
}



//optimize
// Integrate only in the forward direction. "Integrate_Allways" should be used instead in general.
// void Integrateur::Integre()
// {
//     // Declarations
//     intervals_type interv;
//     const state_type xini = x0;
//     const value_type tini = ts[0] ;
//     const value_type dtini = dt0;
//     state_type current_state = x0;
//     deriv_type  dxdt;
//     int compteur=0;
//     int groscompt = 0;
//
//     // Initialisation des variables utilisées par rhs (static)
//     M0 = int_M0;
//     M1 = int_M1;
//     M2 = int_M2;
//     k0 = pow(length, 3) / ( pow(timescale, 2) * mass * Ggrav ) ; // compatibilité ac intégrateur Newton
//     G2oC2 = pow(Ggrav / clight, 2) * pow(timescale * mass, 2) /  pow( length, 4) ;
//     GoC2 = Ggrav / pow(clight, 2) * mass / length ;
//     GgravAd = Ggrav * pow(timescale, 2) * mass / pow(length, 3) ;
//     clightAd = clight * timescale / length ;
//     clightAd2 = clightAd * clightAd;
//     //k1 = trimfloat(int_k1, mantissa);
//     //k2 = trimfloat(int_k2, mantissa);
//     integrator_choice = integrator_type;
//
//     // Initialisation du stepper et de la récurrence
//     states.clear();
//     Stepper stepper(tolint, tolint, 1. ,1., true);
//     stepper.initialize(xini , tini, dtini );
//     states.push_back(x0);
//     if (roemer_second_order > -1)  SecondDerivative(x0);
//
//     for (int tn = 1; tn < ts.size(); tn=tn)
//     {
//         if (compteur > 10000)
//         {
//             cout << "Warning in Integrateur::Integre() : more than 10000 iteration to reach the next time step ! " ;
//             cout << " Time number is : " << tn << " in " << ts.size() << endl;
//             compteur = 0;
//             groscompt++;
//         }
//         if (groscompt > 10)
//         {
//             cout << "Error in Integrateur::Integre() : more than 100 000 iteration to reach the next time step ! Breaking the loop.." << endl;
//             cout << " Time number is : " << tn << " in " << ts.size() << " and time = " << ts[tn] << endl;
//             cout << "Initial time step was : " << dt0 << endl;
//             cout << "Last interpolation interval is : " << interv.first << "  " << interv.second << endl;
//             break;
//         }
//
//         interv = stepper.do_step( rhs ) ;
//
//         while (interv.first <= ts[tn] and interv.second > ts[tn])
//         {
//             stepper.calc_state( ts[tn] , current_state) ;
//             if (roemer_second_order > -1)  SecondDerivative(current_state);
//             states.push_back(current_state);
//             compteur=0;
//             tn++;
//         }
//         compteur++;
//     }
// }

// Main function : integrate the and put the results in "states".
// Integrate both forwards and backwards from the inital condition depending depending on the times recquired by the user.
void Integrateur::Integrate_Allways()
{
    // Declarations
    intervals_type interv;
    const state_type xini = x0;
    const value_type tini = 0. ;
    const value_type dtini = dt0;
    state_type current_state = x0;
    deriv_type  dxdt;
    int compteur=0;
    int groscompt = 0;
    const int nt = tpos.size();
    value_type pasmin=1000. ; // ! Test !
    int i,j,k;
    int tn=0;

    valarray<value_type> xx(3);
    valarray<value_type> vv(3);


    // Initialize state vectors
    states.resize( ts.size() );


    // Initialize constants used in the right-hand-side routine ("rhs" and "retro_rhs")
    M0 = int_M0;
    M1 = int_M1;
    M2 = int_M2;

    SEP_D = int_SEP_D;
    for (i = 0 ; i < nbody ; i++)
    {
        for (j = 0 ; j < nbody ; j++)
        {
            Gg[i][j] = int_Gg[i][j];
            gammabar[i][j] = int_gammabar[i][j];
            for (k = 0 ; k < nbody ; k++)
            {
                betabar[i][j][k] = int_betabar[i][j][k];
            }
        }
    }



// Defining natural coordinates :
    xx[0] = x0[0]; xx[1] = x0[1]; xx[2] = x0[2];
    vv[0] = x0[9]; vv[1] = x0[10]; vv[2] = x0[11];
    e_znat = crossprod(xx, vv) * M0;
    xx[0] = x0[3]; xx[1] = x0[4]; xx[2] = x0[5];
    vv[0] = x0[12]; vv[1] = x0[13]; vv[2] = x0[14];
    e_znat += crossprod(xx, vv) * M1;
    xx[0] = x0[6]; xx[1] = x0[7]; xx[2] = x0[8];
    vv[0] = x0[15]; vv[1] = x0[16]; vv[2] = x0[17];
    e_znat += crossprod(xx, vv) * M2;
    e_znat /= norm3d<value_type>(e_znat);

    e_ynat[0] = -e_znat[1];
    e_ynat[1] = e_znat[0] - e_znat[2];
    e_ynat[1] = e_znat[1];
    e_ynat /= norm3d<value_type>(e_ynat); // defined arbitrarily

    e_xnat = crossprod(e_ynat, e_znat); // defined arbitrarily, could be Laplace vector

// Uncumment to see what the natural basis is
    /*
    printf("\n Natural base unit vectors : \ne_x = %.4Le %.4Le %.4Le\ne_y = %.4Le %.4Le %.4Le\ne_z = %.4Le %.4Le %.4Le\n\n", e_xnat[0], e_xnat[1], e_xnat[2], e_ynat[0], e_ynat[1], e_ynat[2], e_znat[0], e_znat[1], e_znat[2]);
    */
    k0 = pow(length, 3) / pow(timescale, 2) / mass / Ggrav ;  // Proportionality constant in units of "length", "timescale" and "mass"
    G2oC2 = pow(Ggrav / clight, 2) * pow(timescale * mass, 2) /  pow( length, 4) ;
    GoC2 = Ggrav / pow(clight, 2) * mass / length ;
    GgravAd = Ggrav * pow(timescale, 2) * mass / pow(length, 3) ;
    clightAd = clight * timescale / length ;
    clightAd2 = clightAd * clightAd;
    integrator_choice = integrator_type;

    Ms[0] = M0 * GgravAd / clightAd2; Ms[1] = M1 * GgravAd / pow(clightAd,2); Ms[2] = M2 * GgravAd / pow(clightAd,2); // Takes into account that c = G = 1 in the expressions below

// Integrator specific initialsarions

  if (integrator_type == 10)
  {
      quadrupole = int_quadrupole;
      quadrupole[2] *= daysec/timescale;
      quadrupole[3] *= daysec/timescale;
      quadrupole[0] *= clight * clight / length / length ; // convert Msol.ls^2 -> Msol.length^2
  //     printf("\nquadrupole %.5Le %.5Le %.5Le %.5Le \n\n",quadrupole[0], quadrupole[1], quadrupole[2], quadrupole[3] );
  }
  if (integrator_type == 1)
  {
      if (int_quadrupole.size() > 0)
          quadrupole = int_quadrupole;
      else
          quadrupole[0] = zero;
      QwdAd = Qwd / (mass * length * length * timescale * timescale);
      quadrupole[0] *= timescale * timescale;

      if ( abs(quadrupole[0]) > zero )
          quadrupole_enabled = true;
      else
          quadrupole_enabled = false;
  }

    if (integrator_type == 2)
    {
      quadrupole[0] = int_quadrupole[0] / (mass * length * length);
      Q1Ad =  GgravAd *  neufdemis  * quadrupole[0] /  Ms[1] ;
    }



// Do the backward integration
    Retro_Integre();


    // Now integrate forward

    // Initialize the Boost stepper.
     Stepper stepper(tolint, tolint, 1. ,1., true);

    // boost::numeric::odeint::result_of::make_dense_output< errstepper >::type stepper = make_dense_output(tolint, tolint, errstepper());


    stepper.initialize(xini , tini, dtini );

    if (tini == tpos[0]) // & tn == 0
    {
        states[ntneg] = x0 ;
        //states.push_back(x0);
      //optimization  if (roemer_second_order > -1)  SecondDerivative(x0);
        tn=1; // tn++
    }

    while (tn < nt) //for (tn = 0; tn < nt; tn=tn)
    {

        if (compteur > 10000)
        {
            cout << "Warning in Integrateur::Integre_Allways() : more than 10000 iteration to reach the next time step ! " ;
            cout << " Time number is : " << tn << " in " << nt << endl;
            compteur = 0;
            groscompt++;
            if (groscompt > 10)
            {
                cout << "Error in Integrateur::Integre_Allways() : more than 100 000 iteration to reach the next time step ! Breaking the loop.." << endl;
                cout << " Time number is : " << tn << " in " << nt << " and time = " << tpos[tn] << endl;
                cout << "Initial time step was : " << dt0 << endl;
                cout << "Last interpolation interval is : " << interv.first << "  " << interv.second << endl;
                break;
            }
        }

        // Do the actual step forward
        switch (integrator_type) {
            case 1:
              interv = stepper.do_step(rhs_GR) ;
              break;
            case 2:
              interv = stepper.do_step(rhs_GR_quadrupole);
              break;
            case -1:
              interv = stepper.do_step( rhs_biKeplerian ) ;
              break;
            case 0:
              interv = stepper.do_step(rhs_Newt) ;
              break;
            case 10:
              interv = stepper.do_step(rhs_NewtQuad) ;
              break;
            default :
              cout << "Integrator type does not match anything known ! Using Newtonian." << "\n";
        }
        //interv = stepper.do_step( rhs ) ; // Do the actual step forward

        // Uncomment to print the width of each step
//          cout << "--> dif : " << interv.second - interv.first << endl;
//         if (interv.second - interv.first < pasmin) //  ! Test !
//         {
//             pasmin = interv.second - interv.first ;
//         }

        while ( interv.second > tpos[tn] and tn < nt) // interv.first <= tpos[tn] and
        {
            stepper.calc_state( tpos[tn] , current_state) ;
            //optimization if (roemer_second_order > -1)  SecondDerivative(current_state); // save for roemer delay in case corrections to go from toa to toe are calculated whith derivatives of the position. (not used anymore in the present version of the code)
            //states.push_back(current_state);
            states[ ntneg + tn ] = current_state ;
            compteur=0;
            tn++;
        }
        compteur++;
    }
    // Uncomment to print the minimum width between two steps
    //cout << "--------> pasmin : " << pasmin << endl;
    return;
}



//  Do the backward integration and store the result in the "ntneg" first terms of "states". Called by "Integrateur::Integrate_Allways()"
void Integrateur::Retro_Integre()
{
    // Declarations
    intervals_type interv;
    const state_type xini = x0;
    const value_type tini = 0. ;
    const value_type dtini = dt0;
//optimization     vector<state_type> locstates;
    state_type current_state = x0;
    deriv_type  dxdt;
    int compteur=0;
    int groscompt = 0;
    const int nt = tneg.size();

  //optimization   locstates.reserve(nt);


    // Initialisation du stepper et de la récurrence
    Stepper stepper(tolint, tolint, 1. ,1., true);
    stepper.initialize(xini , tini, dtini );

    int tn = nt -1;
    while (tn >= 0) //for (int tn = nt - 1; tn >= 0; tn=tn)
    {
        if (compteur > 10000)
        {
            cout << "Warning in Integrateur::Retro_Integre() : more than 10000 iteration to reach the next time step ! " ;
            cout << " Time number is : " << tn << " in " << nt << endl;
            cout << "Current initial time: " << tini *timescale << "| Current time target: " << (tini+dtini)*timescale << " timescale "<< timescale << endl;
            compteur = 0;
            groscompt++;
            if (groscompt > 10)
            {
                cout << "Error in Integrateur::Retro_Integre : more than 100 000 iteration to reach the next time step ! Breaking the loop.." << endl;
                cout << " Time number is : " << tn << " in " << nt << " and time = " << tneg[tn] << endl;
                cout << "Initial time step was : " << dt0 << endl;
                cout << "Last interpolation interval is : " << interv.first << "  " << interv.second << endl;
                break;
            }
        }
         // interv = stepper.do_step( retro_rhs ) ;
        // Do the actual step
        switch (integrator_type) {
            case 1:
              interv = stepper.do_step(retro_rhs_GR) ;
              break;
            case 2:
              interv = stepper.do_step(retro_rhs_GR_quadrupole);
              break;
            case -1:
              interv = stepper.do_step( retro_rhs_biKeplerian ) ;
              break;
            case 0:
              interv = stepper.do_step(retro_rhs_Newt) ;
              break;
            case 10:
              interv = stepper.do_step(retro_rhs_NewtQuad) ;
              break;
            default :
              cout << "Integrator type does not match anything known ! Using Newtonian." << "\n";
        }

        while ( interv.second > tneg[tn] and tn >= 0) // interv.first <= tneg[tn]  and
        {
            stepper.calc_state( tneg[tn] , current_state) ;
      //optimization      if (roemer_second_order > -1) Retro_SecondDerivative(current_state);
            states[tn ] = current_state;
            //locstates.push_back(current_state); //optimization
            compteur=0;
            tn--;
        }
        compteur++;
    }

    // // Now put everything in the forward order in the main variables
    // for (int i = nt -1 ; i >= 0  ; i--)
    // {
    //     states[(nt - 1)  - i ] = locstates[i] ;
    //     //states.push_back(locstates[i]);
    //     //optimization if (roemer_second_order > -1)
    //     // {
    //         // cout << " push_back not corrected for derivatives in Retro_Integre ! " << endl;
    //         // derivatives.push_back(retro_derivatives[i]);
    //     // }
    // }
    return;


}

// Right-hand side for forward integration
// This routine is an interface that chooses which right-hand-side to use depending on the theory defined by the user.
void Integrateur::rhs(const state_type& xvect, state_type& dxdtvect, const value_type& t)
{
    rhs_GR(xvect, dxdtvect, t) ;
    // switch (integrator_choice) {
    //     case -1:
    //         rhs_biKeplerian(xvect, dxdtvect, t) ;
    //         break;
    //     case 0:
    //         rhs_Newt(xvect, dxdtvect, t) ;
    //         break;
    //     case 1:
    //         rhs_GR(xvect, dxdtvect, t) ;
    //         break;
    //     case 10:
    //         rhs_NewtQuad(xvect, dxdtvect, t) ;
    //         break;
    //     default :
    //         cout << "Integrator type does not match anything known ! Using Newtonian." << "\n";
    //         rhs_Newt(xvect, dxdtvect, t) ;
    //     }
}

// Right-hand side for backward integration
// This routine is an interface that chooses which right-hand-side to use depending on the theory defined by the user.
void Integrateur::retro_rhs(const state_type& xvect, state_type& dxdtvect, const value_type& t)
{
    rhs(xvect, dxdtvect, t);
    for (int i=0 ; i < dxdtvect.size() ; i++)
    {
        dxdtvect[i] = - dxdtvect[i]; // Only change from rhs here !!
    }
}



// RHS for 3-body integration at first post-newtonian order
void Integrateur::rhs_GR(const state_type& xvect, state_type& dxdtvect, const value_type& t) // Version with equations from equation from Soffel, Relativity in astrometry, Celestial mechanics and Geodesy 1989
{
    // const int nbody =3;
    // valarray<valarray<valarray<value_type> > > dx(3);
    // valarray<valarray<valarray<value_type> > > ns(3);
    // valarray<valarray<value_type> >  rs(3);
    // valarray<valarray<value_type> > vs(3);
    // valarray<value_type>  vvs(3);
    // //optimization valarray<value_type> Ms(3); // = {M0, M1, M2}; // Masses
    // // Ms[0] = M0 * GgravAd / pow(clightAd,2); Ms[1] = M1 * GgravAd / pow(clightAd,2); Ms[2] = M2 * GgravAd / pow(clightAd,2); // Takes into account that c = G = 1 in the expressions below
    // valarray<value_type> inter(3);
    // valarray<value_type> onebodyinter(3);
    // valarray<value_type> inter1(3);
    // valarray<value_type> inter2(3);
    // valarray<value_type> inter3(3);
    // value_type sinter = zero;
    // value_type sinter1 = zero;
    // value_type interflt = 0.;
    // value_type rmb = 0.;
    // int n1,n2,n3;
    // valarray<value_type> x (18);
    // valarray<value_type> dxdt(0., 18);

//    // Natural coordinates ( ie z = total angular momentum, defined in Integrate_Allways)
//optimization
    // value_type dxnat = zero;
    // value_type dynat = zero;
    // value_type dznat = zero;




  // // Test DD
    // value_type Mt = 0.;
    // value_type nu = 0.;
    // value_type nVt = 0.;
    // valarray<value_type> Rt(3) ;
    // valarray<value_type> Vt(3) ;
    // valarray<value_type> dVdt(3) ;
    // valarray<value_type> dVdtdd(3) ;
    // valarray<value_type> Nt(3) ;

///////    int c=0;

    for (int i=0 ; i < xvect.size() ; i++)
    {
        x[i] = xvect[i];
    }
   // cout << "forw a" << endl ;
/* Initialize matrixes for the differences between the locations of the bodies, two by two ;
   the distances between two bodies; and unit vectors. */
    for (int i = 0 ; i < 3 ; i++)
    {
      //optimization
    // dx[i] =  valarray<valarray<value_type> >(3) ;
    // ns[i] =  valarray<valarray<value_type> >(3) ;
    // rs[i] = valarray<value_type> (3) ;
    // vs[i] = valarray<value_type> (3) ;
    vs[i] = x[slice(9 + i * 3, 3, 1)] ;
    vs[i] /= clightAd;    // Takes into account that c = G = 1 in the expressions below
    inter = pow(vs[i], deux);
    vvs[i] = inter.sum() ;
        for (int j = 0 ; j < 3 ; j++)
        {
        //optimization dx[i][j] = valarray<value_type>(3) ;    // Differences
        dx[i][j] = x[slice(j * 3,3,1)];     // !! Different convention from Will's !
        dx[i][j] -= x[slice(i * 3,3,1)];

        inter = pow(dx[i][j], deux);
        rs[i][j] = sqrt ( inter.sum() );    // Distances

        //optimization ns[i][j] = valarray<value_type>(3) ;    // unit vectors
        ns[i][j] = dx[i][j];
            ns[i][j] /= rs[i][j];
        }
    }


    dxdt[slice(0,9,1)] = x[slice(9,9,1)]; // Set first derivatives

// Computation of the acceleration :
//optimization  if (Ms[2] > 0.) {   // Three-body case


    for (n1 = 0 ; n1 < nbody ; n1++)
     {
        onebodyinter =zero;

        for (n2 = 0 ; n2 < nbody ; n2++)
        {
          inter1 = zero;
          if (n2 != n1)
          {
            // 2 body terms in the direction of ns[n1][n2]
              sinter = un;
              sinter1 = dotprod3d<value_type>(vs[n1], vs[n2]);
              sinter -= (quatre + deux *  gammabar[n1][n2])*sinter1 ;
              sinter += vvs[n1] * ( un  + gammabar[n1][n2]);
              sinter += (deux + gammabar[n1][n2]) * vvs[n2];
              sinter1 = dotprod3d<value_type>(vs[n2], ns[n1][n2]);
              sinter -= troisdemis * sinter1 * sinter1;
              inter1 += ns[n1][n2] * sinter;

            // 2-body terms in the direction of (vs[n2] - vs[n1])
              inter = (vs[n2] - vs[n1]);
              inter *= - deux * gammabar[n1][n2];
              inter +=  quatre * vs[n1] - trois * vs[n2];
              sinter = dotprod3d<value_type>(ns[n1][n2], inter);//quatre * vs[n1] - trois * vs[n2] - deux * gammabar[n1][n2] * (vs[n2] - vs[n1]));
              inter1 += (vs[n2] - vs[n1]) * sinter ;
            // Prefactor 2-body
              inter1 *= Gg[n1][n2] * Ms[n2] / (rs[n1][n2]*rs[n1][n2]) ;

            // 3-body terms
            inter2 = zero;
            inter3 = zero;
            for (n3 = 0 ; n3 < nbody ; n3++)
            {
            // 3-body terms with n3 != n2
                if (n3 != n2)
                {
                    // terms in the direction of ns[n1][n2]
                    sinter = undemi * dotprod3d<value_type>(ns[n1][n2], ns[n2][n3]) / rs[n2][n3] ;
                    sinter -= (un + betabar[n2][n3][n1] + betabar[n2][n1][n3]) / rs[n1][n2];
                    inter = sinter * ns[n1][n2];

                    // terms in the direction of ns[n2][n3]
                    sinter = (septdemis + deux * gammabar[n1][n2]) / rs[n2][n3] ;
                    inter += sinter * ns[n2][n3];

                    // prefactor
                    inter *=  Gg[n1][n2] * Gg[n2][n3] * Ms[n2] * Ms[n3] / (rs[n1][n2]*rs[n2][n3]);

                    inter2 += inter;
                }
             // 3-body terms with n3 != n1
                if (n3 != n1)
                {
                    sinter = (quatre + deux * gammabar[n1][n3] + betabar[n1][n2][n3] + betabar[n1][n3][n2]) ;
                    sinter *= Gg[n1][n2] * Gg[n1][n3] * Ms[n2] * Ms[n3] / (rs[n1][n2]*rs[n1][n2]*rs[n1][n3]);
                    inter3 -= ns[n1][n2] * sinter ;
                }
            }
            onebodyinter += inter1 + inter2 + inter3;
          }
        }
        onebodyinter *= clightAd2;
        dxdt[std::slice(9 + n1 * 3,3,1)] = onebodyinter;
    }

 /*
// Interaction quadrupolar momentum of inner WD with NS.
    inter =  ns[0][1] * ( GgravAd *  neufdemis * QwdAd * quadrupole[0] / (pow(rs[0][1], 4) * Ms[1]) );
    if (rhs_counter < 10)
    {
        rhs_counter += 1;
        sinter = sqrt(dotprod3d<value_type>(inter*Ms[1],inter*Ms[1]));
        sinter1 = sqrt(dotprod3d<value_type>(dxdt[std::slice(9 + 0 * 3,3,1)], dxdt[std::slice(9 + 0 * 3,3,1)]));
        printf("t %.10Le quad1 %.4Le  QwAd %.4Le rs[0][1] %.4Le sinter %.4Le sinter1 %.4Le ratio %.4Le \n", t, quadrupole[0], QwdAd, rs[0][1],sinter, sinter1, sinter/sinter1);
        printf(" %.4Le %.4Le %.4Le | %.4Le %.4Le %.4Le\n", dxdt[9], dxdt[10], dxdt[11],  inter[0]*Ms[1], inter[1]*Ms[1], inter[2]*Ms[1]);
        printf("ratio P-O/P-I : %.4Le \n\n", rs[0][1]*rs[0][1] / rs[0][2] / rs[0][2] * Ms[2]/Ms[1]);
    }

    dxdt[std::slice(9 + 0 * 3,3,1)] += inter*Ms[1];
    dxdt[std::slice(9 + 1 * 3,3,1)] -= inter*Ms[0];

// Interaction quadrupolar momentum of inner WD with outer WD, shoud be negligible in J0337+1715
    inter =  ns[1][2] * ( GgravAd *  neufdemis * QwdAd * quadrupole[0] / (pow(rs[1][2], 4) *Ms[1]) );
    dxdt[std::slice(9 + 1 * 3,3,1)] += inter*Ms[2];
    dxdt[std::slice(9 + 2 * 3,3,1)] -= inter*Ms[1];
      */

//optimization
// ###### Version of quadrupole, aligned with total angular momentum.
    // if (quadrupole_enabled == true )
    // {
    //     dxnat = dotprod3d<value_type>(dx[0][1], e_xnat) ;
    //     dynat = dotprod3d<value_type>(dx[0][1], e_ynat) ;
    //     dznat = dotprod3d<value_type>(dx[0][1], e_znat) ;
    // //     sinter = pow(rs[0][1], 5);
    // //     inter =  -( - e_znat * quatre* dznat + e_xnat * dxnat + e_ynat * dynat ) / sinter;
    // //     inter -= ns[0][1] * cinq * ( 2*dznat * dznat - dxnat * dxnat - dynat * dynat ) / (sinter * rs[0][1]);
    // //     inter *= troisdemis * ( GgravAd * QwdAd * quadrupole[0] / ( Ms[1]) ) ;
    //
    //     sinter = rs[0][1]*rs[0][1] ;
    //     inter = ns[0][1] * ( cinq * (dxnat * dxnat +  dynat * dynat - 2*dznat * dznat)/(sinter) - deux);
    //     inter += e_znat * cinq * dznat / rs[0][1] ;
    //     inter *= troisdemis *  GgravAd * QwdAd * quadrupole[0] / ( Ms[1] * sinter * sinter) ;
    //
    //     dxdt[std::slice(9 + 0 * 3,3,1)] += inter*Ms[1];
    //     dxdt[std::slice(9 + 1 * 3,3,1)] -= inter*Ms[0];
    //
    // //     if (rhs_counter < 10)
    // //     {
    // //         rhs_counter += 1;
    // //         sinter = sqrt(dotprod3d<value_type>(inter*Ms[1],inter*Ms[1]));
    // //         sinter1 = sqrt(dotprod3d<value_type>(dxdt[std::slice(9 + 0 * 3,3,1)], dxdt[std::slice(9 + 0 * 3,3,1)]));
    // //         printf("t %.10Le quad1 %.4Le  QwAd %.4Le rs[0][1] %.4Le sinter %.4Le sinter1 %.4Le ratio %.4Le \n", t, quadrupole[0], QwdAd, rs[0][1],sinter, sinter1, sinter/sinter1);
    // //         printf(" %.4Le %.4Le %.4Le | %.4Le %.4Le %.4Le\n", dxdt[9], dxdt[10], dxdt[11],  inter[0]*Ms[1], inter[1]*Ms[1], inter[2]*Ms[1]);
    // //         sinter = cinq * dznat / rs[0][1] ;
    // //         sinter *= troisdemis *  GgravAd * QwdAd * quadrupole[0] / ( pow(rs[0][1],4)) ;
    // //         printf("z term :  %.4Le %.4Le \n\n", sinter, sinter/sinter1);
    // //     }
    //
    //     dxnat = dotprod3d<value_type>(dx[2][1], e_xnat) ;
    //     dynat = dotprod3d<value_type>(dx[2][1], e_ynat) ;
    //     dznat = dotprod3d<value_type>(dx[2][1], e_znat) ;
    //
    // //     sinter = pow(rs[2][1], 5);
    // //     inter =  ( - e_znat * deux* dznat + e_xnat * dxnat + e_ynat * dynat ) / sinter;
    // //     inter += ns[2][1] * cinq * ( dznat * dznat - dxnat * dxnat - dynat * dynat ) / (sinter * rs[2][1]);
    // //     inter *= troisdemis * ( GgravAd * QwdAd * quadrupole[0] / ( Ms[1]) ) ;
    // //
    //     sinter = rs[2][1]*rs[2][1] ;
    //     inter = ns[2][1] * ( cinq * (dxnat * dxnat +  dynat * dynat - 2*dznat * dznat)/(sinter) - deux);
    //     inter += e_znat * cinq * dznat / rs[2][1] ;
    //     inter *= troisdemis *  GgravAd * QwdAd * quadrupole[0] / ( Ms[1] * sinter * sinter) ;
    //
    //     dxdt[std::slice(9 + 2 * 3,3,1)] += inter*Ms[1];
    //     dxdt[std::slice(9 + 1 * 3,3,1)] -= inter*Ms[2];
    // }
// ### End of quadrupole
/*  // In the three-body GR case, the following is rigorously equivalent to the previous loop. One can check it using the 3 printf coded below.
n1 = 0; n2 = 1; n3 = 2;
inter =  dotprod3d<value_type>(dx[n1][n2],quatre*vs[n1] - trois*vs[n2])*Ms[n2]*(-vs[n1] + vs[n2])*pow(rs[n1][n2],-3) +
   dotprod3d<value_type>(dx[n1][n3],quatre*vs[n1] - trois*vs[n3])*Ms[n3]*(-vs[n1] + vs[n3])*pow(rs[n1][n3],-3) +
   Ms[n2]*dx[n1][n2]*pow(rs[n1][n2],-3)*(un - quatre*dotprod3d<value_type>(vs[n1],vs[n2]) + vvs[n1] + deux*vvs[n2] - troisdemis*pow(dotprod3d<value_type>(vs[n2],dx[n1][n2]),2)*pow(rs[n1][n2],-2) -
      5*Ms[n1]*pow(rs[n1][n2],-1) - quatre*(Ms[n2]*pow(rs[n1][n2],-1) + Ms[n3]*pow(rs[n1][n3],-1)) +
      Ms[n3]*(-1 + (dotprod3d<value_type>(dx[n1][n2],dx[n2][n3])*pow(rs[n2][n3],-2))/deux)*pow(rs[n2][n3],-1)) +
   (deux + troisdemis)*(Ms[n2]*Ms[n3]*dx[n2][n3]*pow(rs[n1][n2],-1)*pow(rs[n2][n3],-3) + Ms[n2]*Ms[n3]*dx[n3][n2]*pow(rs[n1][n3],-1)*pow(rs[n3][n2],-3)) +
   Ms[n3]*dx[n1][n3]*pow(rs[n1][n3],-3)*(un - quatre*dotprod3d<value_type>(vs[n1],vs[n3]) + vvs[n1] + deux*vvs[n3] - troisdemis*pow(dotprod3d<value_type>(vs[n3],dx[n1][n3]),2)*pow(rs[n1][n3],-2) -
      cinq*Ms[n1]*pow(rs[n1][n3],-1) - quatre*(Ms[n2]*pow(rs[n1][n2],-1) + Ms[n3]*pow(rs[n1][n3],-1)) +
      Ms[n2]*(-1 + (dotprod3d<value_type>(dx[n1][n3],dx[n3][n2])*pow(rs[n3][n2],-2))/deux)*pow(rs[n3][n2],-1)) ;
inter *=  pow(clightAd,2);   // Takes into account that c = G = 1 in the expressions below
//dxdt[std::slice(9 + n1 * 3,3,1)] = inter * (un + SEP_D);

inter1 = dxdt[std::slice(9 + n1 * 3,3,1)];
printf("test 1 %.10Le %.10Le %.10Le \n", (inter1[0] - inter[0])/inter[0], (inter1[1] - inter[1])/inter[1], (inter1[2] - inter[2])/inter[2]);

Ms[0] *=  (un + SEP_D);  // For SEP violation

n1 = 1; n2 = 2; n3 = 0;
inter =  dotprod3d<value_type>(dx[n1][n2],quatre*vs[n1] - trois*vs[n2])*Ms[n2]*(-vs[n1] + vs[n2])*pow(rs[n1][n2],-3) +
   dotprod3d<value_type>(dx[n1][n3],quatre*vs[n1] - trois*vs[n3])*Ms[n3]*(-vs[n1] + vs[n3])*pow(rs[n1][n3],-3) +
   Ms[n2]*dx[n1][n2]*pow(rs[n1][n2],-3)*(un - quatre*dotprod3d<value_type>(vs[n1],vs[n2]) + vvs[n1] + deux*vvs[n2] - troisdemis*pow(dotprod3d<value_type>(vs[n2],dx[n1][n2]),2)*pow(rs[n1][n2],-2) -
      5*Ms[n1]*pow(rs[n1][n2],-1) - quatre*(Ms[n2]*pow(rs[n1][n2],-1) + Ms[n3]*pow(rs[n1][n3],-1)) +
      Ms[n3]*(-1 + (dotprod3d<value_type>(dx[n1][n2],dx[n2][n3])*pow(rs[n2][n3],-2))/deux)*pow(rs[n2][n3],-1)) +
   (deux + troisdemis)*(Ms[n2]*Ms[n3]*dx[n2][n3]*pow(rs[n1][n2],-1)*pow(rs[n2][n3],-3) + Ms[n2]*Ms[n3]*dx[n3][n2]*pow(rs[n1][n3],-1)*pow(rs[n3][n2],-3)) +
   Ms[n3]*dx[n1][n3]*pow(rs[n1][n3],-3)*(un - quatre*dotprod3d<value_type>(vs[n1],vs[n3]) + vvs[n1] + deux*vvs[n3] - troisdemis*pow(dotprod3d<value_type>(vs[n3],dx[n1][n3]),2)*pow(rs[n1][n3],-2) -
      cinq*Ms[n1]*pow(rs[n1][n3],-1) - quatre*(Ms[n2]*pow(rs[n1][n2],-1) + Ms[n3]*pow(rs[n1][n3],-1)) +
      Ms[n2]*(-1 + (dotprod3d<value_type>(dx[n1][n3],dx[n3][n2])*pow(rs[n3][n2],-2))/deux)*pow(rs[n3][n2],-1)) ;
inter *=  pow(clightAd,2);   // Takes into account that c = G = 1 in the expressions below
// dxdt[std::slice(9 + n1 * 3,3,1)] = inter;

inter1 = dxdt[std::slice(9 + n1 * 3,3,1)];
printf("test 2 %.10Le %.10Le %.10Le \n", (inter1[0] - inter[0])/inter[0], (inter1[1] - inter[1])/inter[1], (inter1[2] - inter[2])/inter[2]);


n1 = 2; n2 = 0; n3 = 1;
inter =  dotprod3d<value_type>(dx[n1][n2],quatre*vs[n1] - trois*vs[n2])*Ms[n2]*(-vs[n1] + vs[n2])*pow(rs[n1][n2],-3) +
   dotprod3d<value_type>(dx[n1][n3],quatre*vs[n1] - trois*vs[n3])*Ms[n3]*(-vs[n1] + vs[n3])*pow(rs[n1][n3],-3) +
   Ms[n2]*dx[n1][n2]*pow(rs[n1][n2],-3)*(un - quatre*dotprod3d<value_type>(vs[n1],vs[n2]) + vvs[n1] + deux*vvs[n2] - troisdemis*pow(dotprod3d<value_type>(vs[n2],dx[n1][n2]),2)*pow(rs[n1][n2],-2) -
      5*Ms[n1]*pow(rs[n1][n2],-1) - quatre*(Ms[n2]*pow(rs[n1][n2],-1) + Ms[n3]*pow(rs[n1][n3],-1)) +
      Ms[n3]*(-1 + (dotprod3d<value_type>(dx[n1][n2],dx[n2][n3])*pow(rs[n2][n3],-2))/deux)*pow(rs[n2][n3],-1)) +
   (deux + troisdemis)*(Ms[n2]*Ms[n3]*dx[n2][n3]*pow(rs[n1][n2],-1)*pow(rs[n2][n3],-3) + Ms[n2]*Ms[n3]*dx[n3][n2]*pow(rs[n1][n3],-1)*pow(rs[n3][n2],-3)) +
   Ms[n3]*dx[n1][n3]*pow(rs[n1][n3],-3)*(un - quatre*dotprod3d<value_type>(vs[n1],vs[n3]) + vvs[n1] + deux*vvs[n3] - troisdemis*pow(dotprod3d<value_type>(vs[n3],dx[n1][n3]),2)*pow(rs[n1][n3],-2) -
      cinq*Ms[n1]*pow(rs[n1][n3],-1) - quatre*(Ms[n2]*pow(rs[n1][n2],-1) + Ms[n3]*pow(rs[n1][n3],-1)) +
      Ms[n2]*(-1 + (dotprod3d<value_type>(dx[n1][n3],dx[n3][n2])*pow(rs[n3][n2],-2))/deux)*pow(rs[n3][n2],-1)) ;
inter *=  pow(clightAd,2);   // Takes into account that c = G = 1 in the expressions below
// dxdt[std::slice(9 + n1 * 3,3,1)] = inter;

inter1 = dxdt[std::slice(9 + n1 * 3,3,1)];
printf("test 3 %.10Le %.10Le %.10Le \n", (inter1[0] - inter[0])/inter[0], (inter1[1] - inter[1])/inter[1], (inter1[2] - inter[2])/inter[2]);

*/
//optimization }

//optimization // else {  // Two-body case
//
//     n1 = 0; n2 = 1;
//     inter =  dotprod3d<value_type>(dx[n1][n2],quatre*vs[n1] - trois*vs[n2])*Ms[n2]*(-vs[n1] + vs[n2])*pow(rs[n1][n2],-3) +
//    Ms[n2]*dx[n1][n2]*pow(rs[n1][n2],-3)*(un - quatre*dotprod3d<value_type>(vs[n1],vs[n2]) + vvs[n1] + deux*vvs[n2] - troisdemis*pow(dotprod3d<value_type>(vs[n2],dx[n1][n2]),2)*pow(rs[n1][n2],-2) -
//       cinq*Ms[n1]*pow(rs[n1][n2],-1) - quatre*Ms[n2]*pow(rs[n1][n2],-1));
//     inter *=  pow(clightAd,2)  ;   // Takes into account that c = G = 1 in the expressions below
//     dxdt[std::slice(9 + n1 * 3,3,1)] = inter;
//
//
//     n1 = 1; n2 = 0;
//     inter = dotprod3d<value_type>(dx[n1][n2],quatre*vs[n1] - trois*vs[n2])*Ms[n2]*(-vs[n1] + vs[n2])*pow(rs[n1][n2],-3) +
//    Ms[n2]*dx[n1][n2]*pow(rs[n1][n2],-3)*(un - quatre*dotprod3d<value_type>(vs[n1],vs[n2]) + vvs[n1] + deux*vvs[n2] - troisdemis*pow(dotprod3d<value_type>(vs[n2],dx[n1][n2]),2)*pow(rs[n1][n2],-2) -
//       cinq*Ms[n1]*pow(rs[n1][n2],-1) - quatre*Ms[n2]*pow(rs[n1][n2],-1));
//     inter *=  pow(clightAd,2)  ;   // Takes into account that c = G = 1 in the expressions below
//     dxdt[std::slice(9 + n1 * 3,3,1)] = inter;
//
//     dxdt[std::slice(9 + 2 * 3,3,1)] = zero;
// }

//    for (int a = 0 ; a < 3 ; a++)  // loop over bodies, could be optimized...
//    {
//     for (int b = 0 ; b < 3 ; b++)
//     {
//         if (a != b ) {
//             c = int(6. / ( (a+1)*(b+1) ) ) - 1 ; // gives the third index
//             if ((c+1)*(a+1)*(b+1) != 6) cout << "abc != 6 !!!!!!!!!!!!" << endl;
//
//             if ( a == 2  && M2 == 0. ) {                // Case with two bodies only !
//                 dxdt[std::slice(9 + a * 3,3,1)] = 0.;
//             }
//             else {
//
//             // Newtonian  terms
//         //        dxdt[std::slice(9 + a * 3,3,1)] += - pow(clightAd,2) * Ms[b] * ns[a][b] / pow(rs[a][b], 2);
//                 //cout << " rapport     : " << sqrt( interflt / dotprod(dxdt[std::slice(9 + a * 3,3,1)], dxdt[std::slice(9 + a * 3,3,1)]) ) << endl;
//             }
//         }
//     }
//     }

              // Test two bodies (uncomment to enable) :
//                 if ( M2 == 0. ) {
//                     Ms = Ms / GgravAd * pow(clightAd,2);
//                     Mt = M0 + M1;
//                     Rt = rs[0][1];
//                     Nt = ns[0][1];
//                     Vt = dxdt[slice(0,3,1)] ;
//                     Vt -= dxdt[slice(3,3,1)] ;
//                     inter = pow(Vt, deux);
//                     nVt = sqrt ( inter.sum() );
//                     nu  = M0*M1 / pow( Mt, deux );
//
//                     dVdtdd = GoC2 * Mt / pow(Rt,deux) * ( GgravAd * Mt / Rt * ( 4. + 2. * nu ) - pow(nVt,deux) * (1. + 3.*nu) + troisdemis * nu * pow( dotprod3d<value_type>(Nt,Vt), deux ) ) * Nt ;
//                     dVdtdd += GoC2 * Mt / pow(Rt,deux) * ( 4. - 2. * nu ) * dotprod3d<value_type>(Nt,Vt) * Vt;
//                     inter = pow( dVdtdd, deux) ;
//                     interflt = sqrt ( inter.sum() );
//                     dVdtdd += -GgravAd * Mt / pow(Rt,deux) * Nt ;
//
//                     dVdt = dxdt[std::slice(9 + 1 * 3,3,1)] ;
//                     dVdt -= dxdt[std::slice(9 + 0 * 3,3,1)];
//                     inter = (dVdt - dVdtdd) ;
//                     inter = abs(inter) / abs(dVdtdd) ;
//                     if (inter.max() > pow(10.,-10) ) {
//                         cout << "  Comparison with DD86-I formula 2.5 for two bodies " << endl;
//                         cout << "     Norme partie 1PN DD :  " <<  interflt << endl;
//                         cout << dVdtdd[0] << "   " << dVdt[0] - dVdtdd[0] << "   " << inter[0] << endl;
//                         cout << dVdtdd[1] << "   " << dVdt[1] - dVdtdd[1] << "   " << inter[1] << endl;
//                         cout << dVdtdd[2] << "   " << dVdt[2] - dVdtdd[2] << "   " << inter[2]<< endl;
//                         cout << endl;
//                     }
//                 }
//                end test

    //optimization if (dxdtvect.size() < xvect.size()) dxdtvect.resize(18);
    for (int i=0 ; i < dxdtvect.size() ; i++)
    {
        dxdtvect[i] = dxdt[i];
    }
    //cout << " max interflt : " << rmb << endl;

 };

 void Integrateur::retro_rhs_GR(const state_type& xvect, state_type& dxdtvect, const value_type& t)
 {
     rhs_GR(xvect, dxdtvect, t);
     for (int i=0 ; i < dxdtvect.size() ; i++)
     {
         dxdtvect[i] = - dxdtvect[i]; // Only change from rhs here !!
     }
 }



 // RHS for 3-body integration at first post-newtonian order
 void Integrateur::rhs_GR_quadrupole(const state_type& xvect, state_type& dxdtvect, const value_type& t) // Version with equations from equation from Soffel, Relativity in astrometry, Celestial mechanics and Geodesy 1989
 {

 //    // Natural coordinates ( ie z = total angular momentum, defined in Integrate_Allways)
 //optimization
     // value_type dxnat = zero;
     // value_type dynat = zero;
     // value_type dznat = zero;


     for (int i=0 ; i < xvect.size() ; i++)
     {
         x[i] = xvect[i];
     }
     /* Initialize matrixes for the differences between the locations of the bodies, two by two ;
    the distances between two bodies; and unit vectors. */
     for (int i = 0 ; i < 3 ; i++)
     {
         vs[i] = x[slice(9 + i * 3, 3, 1)] ;
         vs[i] /= clightAd;    // Takes into account that c = G = 1 in the expressions below
         inter = pow(vs[i], deux);
         vvs[i] = inter.sum() ;
         for (int j = 0 ; j < 3 ; j++)
         {
         dx[i][j] = x[slice(j * 3,3,1)];     // !! Different convention from Will's !
         dx[i][j] -= x[slice(i * 3,3,1)];

         inter = pow(dx[i][j], deux);
         rs[i][j] = sqrt ( inter.sum() );    // Distances

         ns[i][j] = dx[i][j];
             ns[i][j] /= rs[i][j];
         }
     }


     dxdt[slice(0,9,1)] = x[slice(9,9,1)]; // Set first derivatives

 // Computation of the acceleration :
 //optimization  if (Ms[2] > 0.) {   // Three-body case


     for (n1 = 0 ; n1 < nbody ; n1++)
      {
         onebodyinter =zero;

         for (n2 = 0 ; n2 < nbody ; n2++)
         {
           inter1 = zero;
           if (n2 != n1)
           {
             // 2 body terms in the direction of ns[n1][n2]
               sinter = un;
               sinter1 = dotprod3d<value_type>(vs[n1], vs[n2]);
               sinter -= (quatre + deux *  gammabar[n1][n2])*sinter1 ;
               sinter += vvs[n1] * ( un  + gammabar[n1][n2]);
               sinter += (deux + gammabar[n1][n2]) * vvs[n2];
               sinter1 = dotprod3d<value_type>(vs[n2], ns[n1][n2]);
               sinter -= troisdemis * sinter1 * sinter1;
               inter1 += ns[n1][n2] * sinter;

             // 2-body terms in the direction of (vs[n2] - vs[n1])
               inter = (vs[n2] - vs[n1]);
               inter *= - deux * gammabar[n1][n2];
               inter +=  quatre * vs[n1] - trois * vs[n2];
               sinter = dotprod3d<value_type>(ns[n1][n2], inter);//quatre * vs[n1] - trois * vs[n2] - deux * gammabar[n1][n2] * (vs[n2] - vs[n1]));
               inter1 += (vs[n2] - vs[n1]) * sinter ;
             // Prefactor 2-body
               inter1 *= Gg[n1][n2] * Ms[n2] / (rs[n1][n2]*rs[n1][n2]) ;

             // 3-body terms
             inter2 = zero;
             inter3 = zero;
             for (n3 = 0 ; n3 < nbody ; n3++)
             {
             // 3-body terms with n3 != n2
                 if (n3 != n2)
                 {
                     // terms in the direction of ns[n1][n2]
                     sinter = undemi * dotprod3d<value_type>(ns[n1][n2], ns[n2][n3]) / rs[n2][n3] ;
                     sinter -= (un + betabar[n2][n3][n1] + betabar[n2][n1][n3]) / rs[n1][n2];
                     inter = sinter * ns[n1][n2];

                     // terms in the direction of ns[n2][n3]
                     sinter = (septdemis + deux * gammabar[n1][n2]) / rs[n2][n3] ;
                     inter += sinter * ns[n2][n3];

                     // prefactor
                     inter *=  Gg[n1][n2] * Gg[n2][n3] * Ms[n2] * Ms[n3] / (rs[n1][n2]*rs[n2][n3]);

                     inter2 += inter;
                 }
              // 3-body terms with n3 != n1
                 if (n3 != n1)
                 {
                     sinter = (quatre + deux * gammabar[n1][n3] + betabar[n1][n2][n3] + betabar[n1][n3][n2]) ;
                     sinter *= Gg[n1][n2] * Gg[n1][n3] * Ms[n2] * Ms[n3] / (rs[n1][n2]*rs[n1][n2]*rs[n1][n3]);
                     inter3 -= ns[n1][n2] * sinter ;
                 }
             }
             onebodyinter += inter1 + inter2 + inter3;
           }
         }
         onebodyinter *= clightAd2;
         dxdt[std::slice(9 + n1 * 3,3,1)] = onebodyinter;
     }


 // Interaction quadrupolar momentum of inner WD with NS.
    inter =  ns[0][1];
    inter *=   (Q1Ad / pow(rs[0][1], 4)) ;
     // if (rhs_counter < 10)
     // {
     //     rhs_counter += 1;
     //     sinter = sqrt(dotprod3d<value_type>(inter*Ms[1],inter*Ms[1]));
     //     sinter1 = sqrt(dotprod3d<value_type>(dxdt[std::slice(9 + 0 * 3,3,1)], dxdt[std::slice(9 + 0 * 3,3,1)]));
     //     printf("t %.10Le quad1 %.4Le  QwAd %.4Le rs[0][1] %.4Le sinter %.4Le sinter1 %.4Le ratio %.4Le \n", t, quadrupole[0], QwdAd, rs[0][1],sinter, sinter1, sinter/sinter1);
     //     printf(" %.4Le %.4Le %.4Le | %.4Le %.4Le %.4Le\n", dxdt[9], dxdt[10], dxdt[11],  inter[0]*Ms[1], inter[1]*Ms[1], inter[2]*Ms[1]);
     //     printf("ratio P-O/P-I : %.4Le \n\n", rs[0][1]*rs[0][1] / rs[0][2] / rs[0][2] * Ms[2]/Ms[1]);
     // }

     dxdt[std::slice(9 + 0 * 3,3,1)] += inter*Ms[1];
     dxdt[std::slice(9 + 1 * 3,3,1)] -= inter*Ms[0];

 // Interaction quadrupolar momentum of inner WD with outer WD, shoud be negligible in J0337+1715
     inter =  ns[1][2] ;
    inter *= ( Q1Ad / pow(rs[1][2], 4) );
     dxdt[std::slice(9 + 1 * 3,3,1)] += inter*Ms[2];
     dxdt[std::slice(9 + 2 * 3,3,1)] -= inter*Ms[1];


 //optimization
 // ###### Version of quadrupole, aligned with total angular momentum.
     // if (quadrupole_enabled == true )
     // {
     //     dxnat = dotprod3d<value_type>(dx[0][1], e_xnat) ;
     //     dynat = dotprod3d<value_type>(dx[0][1], e_ynat) ;
     //     dznat = dotprod3d<value_type>(dx[0][1], e_znat) ;
     // //     sinter = pow(rs[0][1], 5);
     // //     inter =  -( - e_znat * quatre* dznat + e_xnat * dxnat + e_ynat * dynat ) / sinter;
     // //     inter -= ns[0][1] * cinq * ( 2*dznat * dznat - dxnat * dxnat - dynat * dynat ) / (sinter * rs[0][1]);
     // //     inter *= troisdemis * ( GgravAd * QwdAd * quadrupole[0] / ( Ms[1]) ) ;
     //
     //     sinter = rs[0][1]*rs[0][1] ;
     //     inter = ns[0][1] * ( cinq * (dxnat * dxnat +  dynat * dynat - 2*dznat * dznat)/(sinter) - deux);
     //     inter += e_znat * cinq * dznat / rs[0][1] ;
     //     inter *= troisdemis *  GgravAd * QwdAd * quadrupole[0] / ( Ms[1] * sinter * sinter) ;
     //
     //     dxdt[std::slice(9 + 0 * 3,3,1)] += inter*Ms[1];
     //     dxdt[std::slice(9 + 1 * 3,3,1)] -= inter*Ms[0];
     //
     // //     if (rhs_counter < 10)
     // //     {
     // //         rhs_counter += 1;
     // //         sinter = sqrt(dotprod3d<value_type>(inter*Ms[1],inter*Ms[1]));
     // //         sinter1 = sqrt(dotprod3d<value_type>(dxdt[std::slice(9 + 0 * 3,3,1)], dxdt[std::slice(9 + 0 * 3,3,1)]));
     // //         printf("t %.10Le quad1 %.4Le  QwAd %.4Le rs[0][1] %.4Le sinter %.4Le sinter1 %.4Le ratio %.4Le \n", t, quadrupole[0], QwdAd, rs[0][1],sinter, sinter1, sinter/sinter1);
     // //         printf(" %.4Le %.4Le %.4Le | %.4Le %.4Le %.4Le\n", dxdt[9], dxdt[10], dxdt[11],  inter[0]*Ms[1], inter[1]*Ms[1], inter[2]*Ms[1]);
     // //         sinter = cinq * dznat / rs[0][1] ;
     // //         sinter *= troisdemis *  GgravAd * QwdAd * quadrupole[0] / ( pow(rs[0][1],4)) ;
     // //         printf("z term :  %.4Le %.4Le \n\n", sinter, sinter/sinter1);
     // //     }
     //
     //     dxnat = dotprod3d<value_type>(dx[2][1], e_xnat) ;
     //     dynat = dotprod3d<value_type>(dx[2][1], e_ynat) ;
     //     dznat = dotprod3d<value_type>(dx[2][1], e_znat) ;
     //
     // //     sinter = pow(rs[2][1], 5);
     // //     inter =  ( - e_znat * deux* dznat + e_xnat * dxnat + e_ynat * dynat ) / sinter;
     // //     inter += ns[2][1] * cinq * ( dznat * dznat - dxnat * dxnat - dynat * dynat ) / (sinter * rs[2][1]);
     // //     inter *= troisdemis * ( GgravAd * QwdAd * quadrupole[0] / ( Ms[1]) ) ;
     // //
     //     sinter = rs[2][1]*rs[2][1] ;
     //     inter = ns[2][1] * ( cinq * (dxnat * dxnat +  dynat * dynat - 2*dznat * dznat)/(sinter) - deux);
     //     inter += e_znat * cinq * dznat / rs[2][1] ;
     //     inter *= troisdemis *  GgravAd * QwdAd * quadrupole[0] / ( Ms[1] * sinter * sinter) ;
     //
     //     dxdt[std::slice(9 + 2 * 3,3,1)] += inter*Ms[1];
     //     dxdt[std::slice(9 + 1 * 3,3,1)] -= inter*Ms[2];
     // }
 // ### End of quadrupole

     for (int i=0 ; i < dxdtvect.size() ; i++)
     {
         dxdtvect[i] = dxdt[i];
     }

  };

void Integrateur::retro_rhs_GR_quadrupole(const state_type& xvect, state_type& dxdtvect, const value_type& t)
  {
      rhs_GR_quadrupole(xvect, dxdtvect, t);
      for (int i=0 ; i < dxdtvect.size() ; i++)
      {
          dxdtvect[i] = - dxdtvect[i]; // Only change from rhs here !!
      }
  }




// // RHS for 3-body integration at newtonian order
// Includes two-body newtonian integration.
void Integrateur::rhs_Newt(const state_type& xvect, state_type& dxdtvect, const value_type& t)
{
    valarray<value_type> f01(3);
    valarray<value_type> f02(3);
    valarray<value_type> f12(3);
    valarray<value_type> inter(3);

    valarray<value_type> x (18);
    valarray<value_type> dxdt(18);
    value_type dist01;
    value_type dist02;
    value_type dist12;

    for (int i=0 ; i < xvect.size() ; i++)
    {
        x[i] = xvect[i];
    }


    dxdt[slice(0,9,1)] = x[slice(9,9,1)]; // Set first derivatives
    //cout << "dxdt : " << dxdt[0] << "  " << x[9] << endl;

    f01 = x[slice(0,3,1)];
    f01 -= x[slice(3,3,1)];
    f02 = x[slice(0,3,1)];
    f02 -= x[slice(6,3,1)];
    f12 = x[slice(3,3,1)];
    f12 -= x[slice(6,3,1)];

    inter = pow(f01, deux); dist01 = sqrt( inter.sum() );
    inter = pow(f02, deux); dist02 = sqrt( inter.sum() );
    inter = pow(f12, deux); dist12 = sqrt( inter.sum() );

    f01 /= pow(dist01, trois);  // force of 0 on 1 (without masses)
    f02 /= pow(dist02, trois);  //
    f12 /= pow(dist12, trois);  //

    dxdt[std::slice(9,3,1)] = un/k0 * ( - M1*f01 - M2*f02 ) *  (un + SEP_D) ;
    dxdt[std::slice(12,3,1)] = un/k0 * ( (un + SEP_D)* M0 * f01 - M2*f12 );
    if (M2 > zero)
        dxdt[std::slice(15,3,1)] = un/k0 * ( (un + SEP_D) * M0*f02 + M1*f12 ) ;
    else
        dxdt[std::slice(15,3,1)] = zero ;
    //cout << "dxdt 9: " << dxdt[10] << "  " << f01[1] << " " << k0 << " " << M1 << " f02 :" << f02[1] << endl;
    if (dxdtvect.size() < xvect.size()) dxdtvect.resize(18);
    for (int i=0 ; i < dxdtvect.size() ; i++)
    {
        dxdtvect[i] = dxdt[i];
    }

};
void Integrateur::retro_rhs_Newt(const state_type& xvect, state_type& dxdtvect, const value_type& t)
{
    rhs_Newt(xvect, dxdtvect, t);
    for (int i=0 ; i < dxdtvect.size() ; i++)
    {
        dxdtvect[i] = - dxdtvect[i]; // Only change from rhs here !!
    }
}




// RHS bikeplerian : Newtonian without crossed terms !!!!!!!!! UNCOMPLETE
void Integrateur::rhs_biKeplerian(const state_type& xvect, state_type& dxdtvect, const value_type& t)
{
    valarray<value_type> f01(3);
    valarray<value_type> f02(3);
    valarray<value_type> inter(3);

    valarray<value_type> x (18);
    valarray<value_type> dxdt(18);
    value_type dist01;
    value_type dist02;
    value_type dist12;


    for (int i=0 ; i < xvect.size() ; i++)
    {
        x[i] = xvect[i];
    }


    dxdt[slice(0,9,1)] = x[slice(9,9,1)]; // Set first derivatives
    //cout << "dxdt : " << dxdt[0] << "  " << x[9] << endl;

    f01 = x[slice(0,3,1)];
    f01 -= x[slice(3,3,1)];
    f02 = x[slice(0,3,1)];
    f02 -= x[slice(6,3,1)];

    inter = pow(f01, deux); dist01 = sqrt( inter.sum() );
    inter = pow(f02, deux); dist02 = sqrt( inter.sum() );

    f01 /= pow(dist01, trois);  // force of 0 on 1 (without masses)
    f02 /= pow(dist02, trois);  //

    dxdt[std::slice(9,3,1)] = un/k0 * ( - M1*f01 - M2*f02 );
    dxdt[std::slice(12,3,1)] = un/k0 * ( M0*f01 );
    if (M2 > zero)
        dxdt[std::slice(15,3,1)] = un/k0 * ( M0*f02 ) ;
    else
        dxdt[std::slice(15,3,1)] = zero ;
    //cout << "dxdt 9: " << dxdt[10] << "  " << f01[1] << " " << k0 << " " << M1 << " f02 :" << f02[1] << endl;
    if (dxdtvect.size() < xvect.size()) dxdtvect.resize(18);
    for (int i=0 ; i < dxdtvect.size() ; i++)
    {
        dxdtvect[i] = dxdt[i];
    }

};

void Integrateur::retro_rhs_biKeplerian(const state_type& xvect, state_type& dxdtvect, const value_type& t)
{
    rhs_biKeplerian(xvect, dxdtvect, t);
    for (int i=0 ; i < dxdtvect.size() ; i++)
    {
        dxdtvect[i] = - dxdtvect[i]; // Only change from rhs here !!
    }
}

//optimize
// void Integrateur::SecondDerivative(state_type& xvect)
// {
//     const state_type state = xvect;
//     deriv_type dxdt;
//     value_type t=1.;
//
//     rhs(state, dxdt, t);
//     derivatives.push_back(dxdt[roemer_second_order]);
//         cout << " push_back not corrected in SecondDerivative" << endl;
//
// };

//optimize
// void Integrateur::Retro_SecondDerivative(state_type& xvect)
// {
//     const state_type state = xvect;
//     deriv_type dxdt;
//     value_type t=1.;
//
//     retro_rhs(state, dxdt, t);
//     retro_derivatives.push_back(dxdt[roemer_second_order]);
//     cout << " push_back not corrected in Retro_SecondDerivative" << endl;
// };

//optimize
// void Integrateur::Append_initial_component(const value_type& state_component)
// // Do not use with standard constructor because it preallocates space for x0
// {
//     x0.push_back( trimfloat(state_component, mantissa) );
// };

//optimize
// void Integrateur::Append_time(const value_type& t)
// {
//     value_type tps = trimfloat(t, mantissa) - t0;
//     ts.push_back( tps );
//     if (tps < 0.)
//     {
//         tneg.push_back(abs(tps));
//         ntneg = tneg.size();
//     }
//     if (tps >= 0.) tpos.push_back(tps);
// };

void Integrateur::Clear()
{
    ts.clear();
    x0.clear();
    //ts = 0.;
    //x0 = 0.;
};

// ****** Fin implémentation GR



// ******************** RHS 2-body Newtonian with quadrupole moment ***********

// // RHS 2-body integration with quadrupolar interaction at Newtonian order
// Includes two-body newtonian integration.
void Integrateur::rhs_NewtQuad(const state_type& xvect, state_type& dxdtvect, const value_type& t)
// All 3-body lines are commented
{
    valarray<value_type> f01(3);
//     valarray<value_type> f02(3);
//     valarray<value_type> f12(3);
    valarray<value_type> fq01(3);
    valarray<value_type> x (18);
    valarray<value_type> dxdt(18);
    value_type dist01;
//     value_type dist02;
//     value_type dist12;

    value_type qi=zero;
    value_type dtq = zero;

    for (int i=0 ; i < xvect.size() ; i++)
    {
        x[i] = xvect[i];
    }


    dxdt[slice(0,9,1)] = x[slice(9,9,1)]; // Set first derivatives


    f01 = x[slice(0,3,1)];
    f01 -= x[slice(3,3,1)];
//     f02 = x[slice(0,3,1)];
//     f02 -= x[slice(6,3,1)];
//     f12 = x[slice(3,3,1)];
//     f12 -= x[slice(6,3,1)];

    dist01 = sqrt(dotprod3d<value_type>(f01,f01));
//     inter = pow(f02, 2); dist02 = sqrt( inter.sum() );
//     inter = pow(f12, 2); dist12 = sqrt( inter.sum() );

    // Quadrupole force between 0 and 1
    fq01 = f01;
    fq01 *=  (neufdemis * quadrupole[0] / (pow(dist01, 5) *M1));

    // Quadrupole time dependence
    dtq = (quadrupole[3] - quadrupole[2])/trois;
    if (t > quadrupole[2] && t <= quadrupole[2] + dtq) fq01 *= un - quadrupole[1] * ( t - quadrupole[2])/( quadrupole[3] - quadrupole[2])  ;
    qi = quadrupole[1] * ( dtq )/( quadrupole[3] - quadrupole[2])  ;
    if (t > quadrupole[2] + dtq  && t <= quadrupole[3] ) fq01 *= un - qi + quadrupole[1] * ( t - quadrupole[2] - dtq )/( quadrupole[3] - quadrupole[2])  ;
    qi = quadrupole[1] * ( quadrupole[3] - quadrupole[2] - dtq )/( quadrupole[3] - quadrupole[2]) - qi;
    if (t > quadrupole[3] ) fq01 *= un + qi;
//     else
//         printf(" not it quad3\n");

    // Normal Newtonian forces
    f01 /= pow(dist01, 3);  // force of 0 on 1 (without masses)
//     f02 /= pow(dist02, 3);  //
//     f12 /= pow(dist12, 3);  //


    dxdt[std::slice(9,3,1)] = GgravAd * ( - M1*f01    - fq01 * M1)  ;
    dxdt[std::slice(12,3,1)] = GgravAd * (  M0 * f01   + fq01*M0) ;
    dxdt[std::slice(15,3,1)] = zero ;
//     dxdt[std::slice(9,3,1)] = un/k0 * ( - M1*f01 - M2*f02 ) *  (un + SEP_D) - fq01*M1  ;
//     dxdt[std::slice(12,3,1)] = un/k0 * ( (un + SEP_D)* M0 * f01 - M2*f12 ) + fq01*M0 ;
//     if (M2 > zero)
//         dxdt[std::slice(15,3,1)] = un/k0 * ( (un + SEP_D) * M0*f02 + M1*f12 ) ;
//     else
//         dxdt[std::slice(15,3,1)] = zero ;
    if (dxdtvect.size() < xvect.size()) dxdtvect.resize(18);
    for (int i=0 ; i < dxdtvect.size() ; i++)
    {
        dxdtvect[i] = dxdt[i];
    }

};

void Integrateur::retro_rhs_NewtQuad(const state_type& xvect, state_type& dxdtvect, const value_type& t)
{
    rhs_NewtQuad(xvect, dxdtvect, t);
    for (int i=0 ; i < dxdtvect.size() ; i++)
    {
        dxdtvect[i] = - dxdtvect[i]; // Only change from rhs here !!
    }
}

// ******************** End RHS 2-body Newtonian with quadrupole moment ***********
