/* This code implements a timing model and fitting procedures aimed at studiyng th triple system J0337+1715 (Ransom et al. 2013)
 *
 * Written by Guillaume Voisin 2017 , LUTh, Observatoire de Paris, PSL Research University (guillaume.voisin@obspm.fr astro.guillaume.voisin@google.com)
 *
 */

# include "Parameters.h"
# include <cctype>
#include "Constants.h"
#include <cmath>
#include "Utilities.h"
#include <valarray>
#include <string>
#include <cstring>
#include <cstdlib>
#include <cstdio>
#include "Orbital_elements.h"
#include <iostream>


using namespace std;

Parametres::Parametres(const char * filename)
{
    //n_absparameters = 29;
    allocation_flag = false;
    Load_new_parfile( filename)   ;
    motion_changed = true;
    return ;
}

void Parametres::Set_fitted_parameter_map(const vector<int> list_of_fitted_parameters)
{
    fitted_parameters = list_of_fitted_parameters;
    return;
}


vector<int> Parametres::Get_fitted_parameter_map()
{
    return fitted_parameters;
}

int Parametres::Get_fitted_parameter_index(int absolute_index)
// Return the index of parameter absolute_index  in the fitted parameter list fitted_parameters.
// If this parameter is not fitted, returns -1
{
    int index = absolute_parameter_map[absolute_index];
    int i = 0;
    while (i < fitted_parameters.size() and fitted_parameters[i] != index) i++;
    if (i >= fitted_parameters.size())
        return -1;
    else
        return i;
}


void Parametres::ParamList2AbsParam(int paramnumber, int & absparamnumber, int & index)
/* Map: paramnumber in Parameter List -> (absolute parameter, index)
 * Basically inverts  absolute_parameter_map
 */
{
    int i = 0;
    while(i < absolute_parameter_map.size() and absolute_parameter_map[i] <= paramnumber)
    {
        i++;
    }
    absparamnumber = i -1 ;
    index = paramnumber - absolute_parameter_map[absparamnumber];
};


int Parametres::Is_in_parameter_set(int pset)
// Returns -1 if all fitted parameter are in parameter_sets[pset]. Otherwise returns the absolute index of the first fitted parameter not in the list.
{
  int absparam;
  int subindex;
  const int * psetarray = parameter_sets[pset];
  for (int i = 0; i < fitted_parameters.size(); i++)
      {
        ParamList2AbsParam(fitted_parameters[i], absparam, subindex);
        if (SearchArray<int>(absparam, psetarray, n_absparameters) < 0 )
        {
          return absparam;
        }
      }
    return -1;
}


value_type Parametres::Parameters(int paramnumber)
{
    if (paramnumber >= nfitparams or paramnumber < 0)
    {
        cout << "Error : Wrong parnumber in Parametres::Parameters(int paramnumber) " << endl ;
        return zero;
    };

    int absparamnumber=0;
    int index = 0;

    ParamList2AbsParam(paramnumber, absparamnumber, index);


    if (absparamnumber == 0) return f;
    if (absparamnumber == 1) return f1;

    if (absparamnumber == 2) return etap;
    if (absparamnumber == 3) return apsinii;
    if (absparamnumber == 4) return kappap;
    if (absparamnumber == 5) return apcosii;
    if (absparamnumber == 6) return tascp;
    if (absparamnumber == 7) return Pi;

    if (absparamnumber == 8) return etaB;
    if (absparamnumber == 9) return aBsinio;
    if (absparamnumber == 10) return kappaB;
    if (absparamnumber == 11) return aBcosio;
    if (absparamnumber == 12) return tascB;
    if (absparamnumber == 13) return Po;

    if (absparamnumber == 14) return mui;
    if (absparamnumber == 15) return muio;
    if (absparamnumber == 16) return Mo;

    if (absparamnumber == 17) return oman;
    if (absparamnumber == 18) return delta_oman;

    if (absparamnumber == 19) return dphase0;

    if (absparamnumber == 20) return SEP_D;
    if (absparamnumber == 21) return SEP_gamma ;
    if (absparamnumber == 22) return SEP_beta_0pp  ;
    if (absparamnumber == 23) return SEP_beta_p00 ;
    if (absparamnumber == 24) return SEP_beta_0p0 ;

    if (absparamnumber == 25) return RA;
    if (absparamnumber == 26) return DEC;
    if (absparamnumber == 27) return distance;
    if (absparamnumber == 28) return RA1;
    if (absparamnumber == 29) return DEC1;
    if (absparamnumber == 30) return distance1;

    if (absparamnumber == 31) return DM;
    if (absparamnumber == 32) return DM1;
    if (absparamnumber == 33) return DMX[index];
    if (absparamnumber == 34) return FD[index];

    if (absparamnumber == 35) return quadrupole[index];

    if (absparamnumber == 36) return efac ;

    if (absparamnumber == 37) return delta_i;
    // Add parameter here


    return zero;

}



void Parametres::Set_parameters(int paramnumber, const value_type newvalue)
{
    if (paramnumber >= nfitparams or paramnumber < 0)
    {
        cout << "Error : Wrong paramnumber in Parametres::Set_parameters(int paramnumber, const value_type newvalue) " << endl ;
        return;
    };

    int absparamnumber=0;
    int index = 0;

    ParamList2AbsParam(paramnumber, absparamnumber, index);

    if (absparamnumber == 0) f = newvalue;
    if (absparamnumber == 1) f1 = newvalue ;

    if (absparamnumber == 2) etap = newvalue ;
    if (absparamnumber == 3) apsinii = newvalue ;
    if (absparamnumber == 4) kappap = newvalue ;
    if (absparamnumber == 5) apcosii = newvalue ;
    if (absparamnumber == 6) tascp = newvalue ;
    if (absparamnumber == 7) Pi = newvalue ;

    if (absparamnumber == 8) etaB = newvalue ;
    if (absparamnumber == 9) aBsinio = newvalue ;
    if (absparamnumber == 10) kappaB = newvalue ;
    if (absparamnumber == 11) aBcosio = newvalue ;
    if (absparamnumber == 12) tascB = newvalue ;
    if (absparamnumber == 13) Po = newvalue ;

    if (absparamnumber == 14) mui = newvalue ;
    if (absparamnumber == 15) muio = newvalue ;
    if (absparamnumber == 16) Mo = newvalue ;

    if (absparamnumber == 17) oman = newvalue ;
    if (absparamnumber == 18) delta_oman = newvalue ;

    if (absparamnumber == 19) dphase0 = newvalue ;

    if (absparamnumber == 20) SEP_D = newvalue ;
    if (absparamnumber == 21) SEP_gamma = newvalue ;
    if (absparamnumber == 22) SEP_beta_0pp = newvalue ;
    if (absparamnumber == 23) SEP_beta_p00 = newvalue ;
    if (absparamnumber == 24) SEP_beta_0p0 = newvalue ;

    if (absparamnumber == 25) RA = newvalue ;
    if (absparamnumber == 26) DEC = newvalue ;
    if (absparamnumber == 27) distance = newvalue;
    if (absparamnumber == 28) RA1 = newvalue ;
    if (absparamnumber == 29) DEC1 = newvalue ;
    if (absparamnumber == 30) distance1 = newvalue;

    if (absparamnumber == 31) DM = newvalue;
    if (absparamnumber == 32) DM1 = newvalue;
    if (absparamnumber == 33) DMX[index] = newvalue;
    if (absparamnumber == 34) FD[index] = newvalue;

    if (absparamnumber == 35) quadrupole[index] = newvalue;

    if (absparamnumber == 36) efac = newvalue ;

    if (absparamnumber == 37) delta_i = newvalue ;

    // Add parameter here
    return;
}



value_type Parametres::Parameter_scale(int paramnumber)
{// Return scale of parameter "paramnumber"
    if (paramnumber >= nfitparams or paramnumber < 0)
    {
        cout << "Error : Wrong parnumber in Parametres::Parameter_scale(int paramnumber) " << endl ;
        return zero;
    }

    int absparamnumber=0;
    int index = 0;

    ParamList2AbsParam(paramnumber, absparamnumber, index);

    if (absparamnumber == 0) return scale_f;
    if (absparamnumber == 1) return scale_f1;

    if (absparamnumber == 2) return scale_etap;
    if (absparamnumber == 3) return scale_apsinii;
    if (absparamnumber == 4) return scale_kappap;
    if (absparamnumber == 5) return scale_apcosii;
    if (absparamnumber == 6) return scale_tascp;
    if (absparamnumber == 7) return scale_Pi;

    if (absparamnumber == 8) return scale_etaB;
    if (absparamnumber == 9) return scale_aBsinio;
    if (absparamnumber == 10) return scale_kappaB;
    if (absparamnumber == 11) return scale_aBcosio;
    if (absparamnumber == 12) return scale_tascB;
    if (absparamnumber == 13) return scale_Po;

    if (absparamnumber == 14) return scale_mui;
    if (absparamnumber == 15) return scale_muio;
    if (absparamnumber == 16) return scale_Mo;

    if (absparamnumber == 17) return scale_oman;
    if (absparamnumber == 18) return scale_delta_oman;

    if (absparamnumber == 19) return scale_dphase0;

    if (absparamnumber == 20) return scale_SEP_D;
    if (absparamnumber == 21) return scale_SEP_gamma ;
    if (absparamnumber == 22) return scale_SEP_beta_0pp  ;
    if (absparamnumber == 23) return scale_SEP_beta_p00  ;
    if (absparamnumber == 24) return scale_SEP_beta_0p0  ;


    if (absparamnumber == 25) return scale_RA;
    if (absparamnumber == 26) return scale_DEC;
    if (absparamnumber == 27) return scale_distance;
    if (absparamnumber == 28) return scale_RA1;
    if (absparamnumber == 29) return scale_DEC1;
    if (absparamnumber == 30) return scale_distance1;

    if (absparamnumber == 31) return scale_DM;
    if (absparamnumber == 32) return scale_DM1;
    if (absparamnumber == 33) return scale_DMX[index];
    if (absparamnumber == 34) return scale_FD[index];

    if (absparamnumber == 35) return scale_quadrupole[index];

    if (absparamnumber == 36) return scale_efac  ;

    if (absparamnumber == 37) return scale_delta_i;

    // Add parameter here
}



void Parametres::Set_parameter_scale(int paramnumber, const value_type newvalue)
{
    if (paramnumber >= nfitparams or paramnumber < 0)
    {
        cout << "Error : Wrong parnumber in Parametres::Set_parameter_scale(int paramnumber, const value_type newvalue) " << endl ;
        return;
    }

    int absparamnumber=0;
    int index = 0;

    ParamList2AbsParam(paramnumber, absparamnumber, index);


    if (absparamnumber == 0) scale_f = newvalue;
    if (absparamnumber == 1) scale_f1 = newvalue ;

    if (absparamnumber == 2) scale_etap = newvalue ;
    if (absparamnumber == 3) scale_apsinii = newvalue ;
    if (absparamnumber == 4) scale_kappap = newvalue ;
    if (absparamnumber == 5) scale_apcosii = newvalue ;
    if (absparamnumber == 6) scale_tascp = newvalue ;
    if (absparamnumber == 7) scale_Pi = newvalue ;

    if (absparamnumber == 8) scale_etaB = newvalue ;
    if (absparamnumber == 9) scale_aBsinio = newvalue ;
    if (absparamnumber == 10) scale_kappaB = newvalue ;
    if (absparamnumber == 11) scale_aBcosio = newvalue ;
    if (absparamnumber == 12) scale_tascB = newvalue ;
    if (absparamnumber == 13) scale_Po = newvalue ;

    if (absparamnumber == 14) scale_mui = newvalue ;
    if (absparamnumber == 15) scale_muio = newvalue ;
    if (absparamnumber == 16) scale_Mo = newvalue ;

    if (absparamnumber == 17) scale_oman = newvalue ;
    if (absparamnumber == 18) scale_delta_oman = newvalue ;

    if (absparamnumber == 19) scale_dphase0 = newvalue ;

    if (absparamnumber == 20) scale_SEP_D = newvalue ;
    if (absparamnumber == 21) scale_SEP_gamma = newvalue ;
    if (absparamnumber == 22) scale_SEP_beta_0pp = newvalue ;
    if (absparamnumber == 23) scale_SEP_beta_p00 = newvalue ;
    if (absparamnumber == 24) scale_SEP_beta_0p0 = newvalue ;

    if (absparamnumber == 25) scale_RA = newvalue ;
    if (absparamnumber == 26) scale_DEC = newvalue ;
    if (absparamnumber == 27) scale_distance = newvalue;
    if (absparamnumber == 28) scale_RA1 = newvalue ;
    if (absparamnumber == 29) scale_DEC1 = newvalue ;
    if (absparamnumber == 30) scale_distance1 = newvalue;

    if (absparamnumber == 31) scale_DM = newvalue;
    if (absparamnumber == 32) scale_DM1 = newvalue;
    if (absparamnumber == 33) scale_DMX[index] = newvalue;
    if (absparamnumber == 34) scale_FD[index] = newvalue;

    if (absparamnumber == 35) scale_quadrupole[index] = newvalue;

    if (absparamnumber == 36) scale_efac = newvalue ;

    if (absparamnumber == 37) scale_delta_i = newvalue;
    // Add parameter here
    return;
}


void Parametres::Load_new_parfile(const char * filename)
{
  int i = 0;
  int j,k;
  char snumber[30];
  char paramname_with_number[50];

  //****** Default values before reading parfile

    strcpy(t2parfile,"");

    // *** default values of fittable parameters
        // Fittable parameters          Index in array
    f = zero ;            //        0
    f1 = zero ;           //        1

    etap = zero ;         //        2
    apsinii = zero ;      //        3
    kappap = zero ;       //        4
    apcosii = zero ;      //        5
    tascp = zero ;        //        6
    Pi = zero ;           //        7

    etaB = zero ;         //        8
    aBsinio = zero ;      //        9
    kappaB = zero ;       //        10
    aBcosio = zero ;      //        11
    tascB = zero ;        //        12
    Po = zero ;           //        13

    mui = zero ;          //        14
    muio = zero ;         //        15
    Mo = zero ;           //        16

    oman = zero;          //        17
    delta_oman = zero ;   //        18

    dphase0 = zero ;      //        19

    SEP_D = zero ;        //        20
    SEP_gamma = zero;       //      21
    SEP_beta_0pp = zero;    //      22
    SEP_beta_p00 = zero;    //      23
    SEP_beta_0p0 = zero;    //      24

    RA = zero;            //        25
    DEC = zero;           //        26
    distance = pow(dix, 12) ;     //27 // by default set distance to 10^12 light years
    RA1 = 0.;            //        28
    DEC1 = 0.;           //        29
    distance1 = zero ;     //        30

    DM = zero;            //        31
    DM1 = zero;           //        32
    DMX.resize(0);        //        33
    DMXranges.resize(0);
    FD.resize(0);         //        34

    quadrupole.resize(0);   //      35

    efac = un;              //      36

    delta_i  = zero;        //      37
    // Add parameter here

// For relative modification of parameters : newpar = oldpar + scale_par * dpar

        scale_f = un ;            //        0
        scale_f1 = un ;           //        1

        scale_etap = un ;         //        2
        scale_apsinii = un ;      //        3
        scale_kappap = un ;       //        4
        scale_apcosii = un ;      //        5
        scale_tascp = un ;        //        6
        scale_Pi = un ;           //        7

        scale_etaB = un ;         //        8
        scale_aBsinio = un ;      //        9
        scale_kappaB = un ;       //        10
        scale_aBcosio = un ;      //        11
        scale_tascB = un ;        //        12
        scale_Po = un ;           //        13

        scale_mui = un ;          //        14
        scale_muio = un ;         //        15
        scale_Mo = un ;           //        16

        scale_oman = un ;         //        17
        scale_delta_oman = un ;   //        18

        scale_dphase0 = un ;      //        19

        scale_SEP_D = un ;        //        20
        scale_SEP_gamma = un;       //    21
        scale_SEP_beta_0pp = un;    //    22
        scale_SEP_beta_p00 = un;    //    23
        scale_SEP_beta_0p0 = un;    //    24

        scale_RA = un;            //        25
        scale_DEC = un;           //        26
        scale_distance = 100 ;     //        27  // Big uncertainty on the distance (in light years)
        scale_RA1 = un;            //        28
        scale_DEC1 = un;           //        29
        scale_distance1 = un ;     //        30

        scale_DM = un ;           //        31
        scale_DM1 = un ;          //        32
        scale_DMX.resize(0);      //        33
        scale_FD.resize(0);      //         34

        scale_quadrupole.resize(0); //      35

        scale_efac = un;            //      36

        scale_delta_i = zero;       //      37
        // Add parameter here


   // *********** End of default values of fittable parameters

  // *************** Initialise absolute parameter map ***************
  // Add parameter here
    absolute_parameter_map.resize(n_absparameters);
    for (i=0; i < 33; i++)
    {
        absolute_parameter_map[i] = i;
    }
    //a parameter stored in a vector has the same fitting index as the next parameter if its size is zero
    for (i=33; i < 36; i++) absolute_parameter_map[i] = 33;
    absolute_parameter_map[36] = 33; // efac
    absolute_parameter_map[37] = 34; // delta_i
    nfitparams = 35; // Sum of the "sizes" of each parameter (see also below)
  // *************** End absolute parameter map ***************


    // Delays parameters
    treference = zero ;
    posepoch = zero ;
    geometric = true ;
    kopeikin=true;
    shklovskii = false;
    roemer = false ;
    einstein  = true ;
    shapiro = true ;
    aberration = false ;

    truefreq = 1;
    DopplerF = un ;

    // Integrator and computation parameters
    interpsteps_per_period_i = 100 ;
    interp_margin = 1.;
    integrator_type = 0;
    tolint = pow(10.L, -16) ;

    // Deduced parameters
     Mp = 0. ;
     Mi = 0. ;
     ei = 0. ;
     eo = 0. ;
     omp = 0. ;
     omB  = 0. ;
     tperii = 0. ;
     tperio = 0. ;
     ap  = 0. ;
     aB = 0. ;
     anglii = 0. ;
     anglio = 0. ;
     for (i = 0 ; i < 3 ; i++)
     {
        for (j = 0 ; j < 3 ; j++)
        {
            Gg[i][j] = un;;
            gammabar[i][j] = zero;
            for (k = 0 ; k < 3 ; k++)
            {
                betabar[i][j][k] = zero;
            }
        }
     }
    quadrupole_kgm2.resize(0);

   // Parameter set
    parameter_set = -1;

    Read_parfile(filename) ;


  // Initialize and check parameter set
  int inpset ;
    if (parameter_set > -1)
    {
      inpset = Is_in_parameter_set(parameter_set);
      if (inpset >= 0)
      {
        printf("WARNING : parameter with absolute index %i is not in the current parameter set !", inpset);
      }
    }

    // int parameter0 = 0;
    // int parameter1 = 0;
    // int parameter3 = 0;
    // int absparam, absparam_index;
    //
    // for (i =0; i < fitted_parameters.size() ; i++)
    // {
    //     ParamList2AbsParam(fitted_parameters[i], absparam, absparam_index);
    //     if (absparam == 14 or absparam == 16)
    //         parameter1 += 1;
    //     else if (absparam == 7 or absparam == 13)
    //         parameter0 += 1;
    // }
    // if (parameter0 ==2)
    // {
    //     if (parameter_set < 0)
    //     {
    //         parameter_set = 0;
    //         printf(" A fitted parameter set compatible with parameter_set = 0 has been detected.  Setting parameter_set = 0.\n");
    //     }
    //     else if (parameter_set != 0)
    //         printf("\n Warning ! The set of fitted parameters may not correspond to parameter_set or you may have too many fitted parameters. \n\n");
    // } else if (parameter1 == 2)
    // {
    //     if (parameter_set < 0)
    //     {
    //         parameter_set = 1;
    //         printf("A fitted parameter set compatible with parameter_set = 1 has been detected. Setting parameter_set = 1.  \n");
    //     }
    //     else if (parameter_set != 1)
    //         printf("\n Warning ! The set of fitted parameters may not correspond to parameter_set or you may have too many fitted parameters. \n\n");
    // }
    // if (parameter_set < 0 ) printf("\n Warning ! No way to determine which parameter set to use. Using parameter_set = 0 as default. \n\n");


    // Apply timeshift to all time references

    timeshift = treference ;

    treference -= timeshift ;
    posepoch -= timeshift ;
    tascp -= timeshift ;
    tascB -= timeshift ;

    // Max number of fittable parameters
    nfitparams = nfitparams + DMX.size() + FD.size() + quadrupole.size();
    // Add parameter here : if it is a vector parameter, its size must be part of the sum above

    if ( allocation_flag == false )
    {
            // Initialize parameter names
        fitparams_names = (char**) malloc(nfitparams * sizeof( char *) );
        for (i = 0 ; i< nfitparams ; i++) fitparams_names[i] = (char*) malloc(50 * sizeof( char ) );
        //for (int i = 0 ; i < nfitparams ; i++) fitparams_names[i] = (char*) malloc(100* sizeof( char ) );
        strcpy(fitparams_names[absolute_parameter_map[0]], "spinfreq");
        strcpy(fitparams_names[absolute_parameter_map[1]], "spinfreq1");
        strcpy(fitparams_names[absolute_parameter_map[2]], "eta_p");
        strcpy(fitparams_names[absolute_parameter_map[3]] , "apsini_i");
        strcpy(fitparams_names[absolute_parameter_map[4]] , "kappa_p");
        strcpy(fitparams_names[absolute_parameter_map[5]] , "apcosi_i");
        strcpy(fitparams_names[absolute_parameter_map[6]] , "tasc_p");
        strcpy(fitparams_names[absolute_parameter_map[7]] , "period_i");
        strcpy(fitparams_names[absolute_parameter_map[8]] , "eta_b");
        strcpy(fitparams_names[absolute_parameter_map[9]] , "absini_o");
        strcpy(fitparams_names[absolute_parameter_map[10]] , "kappa_b");
        strcpy(fitparams_names[absolute_parameter_map[11]] , "abcosi_o");
        strcpy(fitparams_names[absolute_parameter_map[12]] , "tasc_b");
        strcpy(fitparams_names[absolute_parameter_map[13]] , "period_o");
        strcpy(fitparams_names[absolute_parameter_map[14]] , "masspar_p");
        strcpy(fitparams_names[absolute_parameter_map[15]] , "masspar_i");
        strcpy(fitparams_names[absolute_parameter_map[16]] , "mass_o");
        strcpy(fitparams_names[absolute_parameter_map[17]] , "oman");
        strcpy(fitparams_names[absolute_parameter_map[18]] , "deltaoman");
        strcpy(fitparams_names[absolute_parameter_map[19]] , "dphase0");
        strcpy(fitparams_names[absolute_parameter_map[20]] , "SEP_D");
        strcpy(fitparams_names[absolute_parameter_map[21]] , "SEP_gamma");
        strcpy(fitparams_names[absolute_parameter_map[22]] , "SEP_beta_0pp");
        strcpy(fitparams_names[absolute_parameter_map[23]] , "SEP_beta_p00");
        strcpy(fitparams_names[absolute_parameter_map[24]] , "SEP_beta_0p0");
        strcpy(fitparams_names[absolute_parameter_map[25]] , "right_ascension");
        strcpy(fitparams_names[absolute_parameter_map[26]] , "declination");
        strcpy(fitparams_names[absolute_parameter_map[27]] , "distance");
        strcpy(fitparams_names[absolute_parameter_map[28]] , "right_ascension1");
        strcpy(fitparams_names[absolute_parameter_map[29]] , "declination1");
        strcpy(fitparams_names[absolute_parameter_map[30]] , "distance1");
        strcpy(fitparams_names[absolute_parameter_map[31]] , "dispmeasure");
        strcpy(fitparams_names[absolute_parameter_map[32]] , "dispmeasure1");
        for (i = 0; i  <  DMX.size() ; i++)
            {
                sprintf(snumber, "%d", i+1);
                strcpy(paramname_with_number, "dispmeasure_X") ;
                strcat(paramname_with_number, snumber);
                strcpy(fitparams_names[absolute_parameter_map[33]+i] , paramname_with_number);
            };
        for (i = 0; i  <  FD.size() ; i++)
            {
                sprintf(snumber, "%d", i+1);
                strcpy(paramname_with_number, "dispmeasure_FD") ;
                strcat(paramname_with_number, snumber);
                strcpy(fitparams_names[absolute_parameter_map[34]+i] , paramname_with_number);
            };
        for (i = 0; i  <  quadrupole.size() ; i++)
            {
                sprintf(snumber, "%d", i+1);
                strcpy(paramname_with_number, "quadrupole") ;
                strcat(paramname_with_number, snumber);
                strcpy(fitparams_names[absolute_parameter_map[35]+i] , paramname_with_number);
            };
        strcpy(fitparams_names[absolute_parameter_map[36]] , "efac");
        strcpy(fitparams_names[absolute_parameter_map[37]] , "delta_i");
        // Add parameter here
        };


        parameters_ini  = (value_type*) malloc( nfitparams * sizeof(value_type ) );

        allocation_flag = true;
//      printf("prout2 \n");
//     Print_table(absolute_parameter_map);
//     printf("DMX");
//     Print_table(DMX);
//     printf("FD\n");
//     Print_table(FD);
//     printf(" fitted\n");
//     Print_table(fitted_parameters);
//     int tparam, tindex;
//     ParamList2AbsParam(31, tparam, tindex);
//     printf("test parlist %d %d \n", tparam, tindex);
    Set_reference_to_current_parameters();

    return;
}


void Parametres::Set_reference_to_current_parameters()
{
    for (int i = 0 ; i < nfitparams ; ++i ) parameters_ini[i] = Parameters(i);
    return;
}

void Parametres::Reset_to_initial_parameters()
{
    for (int i = 0 ; i < nfitparams ; ++i ) Set_parameters(i, parameters_ini[i]);
    return;
}


void Parametres::Insert_in_parameter_maps(int absolute_parameter_map_index, int index )
// Update the paramater maps ( fittable, and fitted) when a new parameteris inserted at  absolute parameter map index  absolute_parameter_map_index, and subindex index.
{
    int shift_absparam=0;
    int min_shifted_index=0;
    int j=0;

    if (absolute_parameter_map_index < absolute_parameter_map.size() - 1)
    {
        shift_absparam = index - (absolute_parameter_map[absolute_parameter_map_index+1] - absolute_parameter_map[absolute_parameter_map_index]);
        min_shifted_index = absolute_parameter_map[absolute_parameter_map_index+1];
    }
    else
    {
        shift_absparam = 0;
        min_shifted_index = nfitparams;
    }

    // Update the fitted-parameter map
    for (j=0; j < fitted_parameters.size() ; j++)
    {
        if (fitted_parameters[j] >= min_shifted_index ) fitted_parameters[j] += shift_absparam;
    };

    // Update the absolute parameter map
    for (j=absolute_parameter_map_index + 1; j < absolute_parameter_map.size() ; j++)
    {
        absolute_parameter_map[j] += shift_absparam;
    };
};


void Parametres::Read_parfile(const char * filename)
{
    /*To add a parameter, add a block like the following :
     *
     * else if (str.find("paramname") != string::npos){
            sscanf( line, "%s %Le %Le ", textin, &param, &scale_param, &active );
            param *= convert_coeff // convert to the internal system of units if necessary
            if ( active == 1 ) fitted_parameters.push_back(param number);
        }
     * Where paramname should be as in fitparams_names, param number as defined by convention in the header.
     * Be careful with name redundances : if the "param name " pattern appears in another name it might be confused (this would need improvement), like for "spinfreq" and "spinfreq1".
     */

    FILE *fp;
    const int sizechar = 100;
    //int returnvalue = 0;
    //value_type val, dval = zero;
    int ival ;
    int i, j;
    char line[sizechar];
    char car[1];
    char textin[sizechar]; // Should be the same size as line otherwise sscanf fails
    string str ;

    int active = 1;
    int shift_absparam =0;
    int min_shifted_index = 0;
    int index = 0;
    value_type xread = zero;
    value_type xread_scale = zero;

    fitted_parameters.resize(0);

    fp = fopen(filename,"r");
    if (fp == NULL)
    {
        printf("\n\n Opening of parfile %s failed ! \n\n", filename);
        return;
    }

    while ( fgets(line, sizechar, fp) != NULL ){
    //    val = zero ;
      //  dval = zero; timeshift
        active = 1;

        // Skip commented line
//         i = 0;
//
//                 str = textin ;
//                 //the following line trims white space from the beginning of the string
//         str.erase(str.begin(), find_if(str.begin(), str.end(), not1(ptr_fun<int, int>(isspace))));
//         if (str[0] == '#') {
//              cout << "comment : " << line << "   car " << str[0] << str[1] << endl;
//             continue;
//         }
//         while( isblank(line[i]) and i < sizechar ) ++i;
//
//         if (str[i] == '#') {
//             cout << "comment : " << line << endl;
//             continue;
//         }

        if (sscanf( line, "%s ", textin) == EOF )  continue ;
        str = textin ;

        if (str.find("tempo2parfile") != string::npos) {
            sscanf( line, "%s %s", textin, t2parfile );
        }

         if (sscanf( line, "spinfreq1 %Le %Le %i", &f1, &scale_f1, &active  ) == 3) {
//             sscanf( line, "%s %Le %Le %i", textin, &f1, &scale_f1, &active );
            f1 *= pow(daysec,2);
            if ( active == 1 ) fitted_parameters.push_back(absolute_parameter_map[1]);
        }
        else  if (sscanf( line, "spinfreq %Le %Le %i", &f, &scale_f, &active  ) == 3){ // ! Be careful with the order !
//                 sscanf( line, "%s %Le %Le %i", textin, &f, &scale_f, &active  );
                f *= daysec;
                if ( active == 1 ) fitted_parameters.push_back(absolute_parameter_map[0]);
        }
        if (sscanf( line, "eta_p %Le %Le %i", &etap, &scale_etap, &active  ) == 3){ //str.find("eta_p") != string::npos){
//                 sscanf( line, "%s %Le %Le %i", textin, &etap, &scale_etap, &active  );
                if ( active == 1 ) fitted_parameters.push_back(absolute_parameter_map[2]);
        }
        if (str.find("apsini_i") != string::npos){
                sscanf( line, "%s %Le %Le %i", textin, &apsinii, &scale_apsinii , &active );
                apsinii *= clight;
                if ( active == 1 ) fitted_parameters.push_back(absolute_parameter_map[3]);
        }
        if (str.find("kappa_p") != string::npos){
                sscanf( line, "%s %Le %Le %i", textin, &kappap, &scale_kappap , &active );
                if ( active == 1 ) fitted_parameters.push_back(absolute_parameter_map[4]);
        }
        if (str.find("apcosi_i") != string::npos){
                sscanf( line, "%s %Le %Le %i", textin, &apcosii, &scale_apcosii , &active );
                apcosii *= clight;
                if ( active == 1 ) fitted_parameters.push_back(absolute_parameter_map[5]);
        }
        if (str.find("tasc_p") != string::npos){
                sscanf( line, "%s %Le %Le %i", textin, &tascp, &scale_tascp , &active );
                if ( active == 1 ) fitted_parameters.push_back(absolute_parameter_map[6]);
        }
        if (str.find("period_i") != string::npos){
                sscanf( line, "%s %Le %Le %i", textin, &Pi, &scale_Pi, &active  );
                if ( active == 1 )
                {
                    fitted_parameters.push_back(absolute_parameter_map[7]);
                }
        }
        if (str.find("eta_b") != string::npos){
                sscanf( line, "%s %Le %Le %i", textin, &etaB, &scale_etaB, &active  );
                if ( active == 1 ) fitted_parameters.push_back(absolute_parameter_map[8]);
        }
        if (str.find("absini_o") != string::npos){
                sscanf( line, "%s %Le %Le %i", textin, &aBsinio, &scale_aBsinio, &active  );
                aBsinio *= clight;
                if ( active == 1 ) fitted_parameters.push_back(absolute_parameter_map[9]);
        }
        if (str.find("kappa_b") != string::npos){
                sscanf( line, "%s %Le %Le %i", textin, &kappaB, &scale_kappaB, &active  );
                if ( active == 1 ) fitted_parameters.push_back(absolute_parameter_map[10]);
        }
        if (str.find("abcosi_o") != string::npos){
                sscanf( line, "%s %Le %Le %i", textin, &aBcosio, &scale_aBcosio, &active  );
                aBcosio *= clight;
                if ( active == 1 ) fitted_parameters.push_back(absolute_parameter_map[11]);
        }
        if (str.find("tasc_b") != string::npos){
                sscanf( line, "%s %Le %Le %i", textin, &tascB, &scale_tascB, &active  );
                if ( active == 1 ) fitted_parameters.push_back(absolute_parameter_map[12]);
        }
        if (str.find("period_o") != string::npos){
                sscanf( line, "%s %Le %Le %i", textin, &Po, &scale_Po, &active  );
                if ( active == 1 )
                {
                    fitted_parameters.push_back(absolute_parameter_map[13]);
                }
        }
        if (str.find("masspar_p") != string::npos){
                sscanf( line, "%s %Le %Le %i", textin, &mui, &scale_mui, &active  );
                if ( active == 1 )
                {
                    fitted_parameters.push_back(absolute_parameter_map[14]);
                }
        }
        if (str.find("masspar_i") != string::npos){
                sscanf( line, "%s %Le %Le %i", textin, &muio, &scale_muio, &active  );
                if ( active == 1 )
                {
                    fitted_parameters.push_back(absolute_parameter_map[15]);
                }
        }
        if (str.find("mass_o") != string::npos){
                sscanf( line, "%s %Le %Le %i", textin, &Mo, &scale_Mo, &active  );
                if ( active == 1 )
                {
                    fitted_parameters.push_back(absolute_parameter_map[16]);
                }
        }
        if (str.find("deltaoman") != string::npos){
                sscanf( line, "%s %Le %Le %i", textin, &delta_oman, &scale_delta_oman, &active  );
                delta_oman *= raddeg;
                if ( active == 1 ) fitted_parameters.push_back(absolute_parameter_map[18]);
        }
        else if (str.find("oman") != string::npos){
                sscanf( line, "%s %Le %Le %i", textin, &oman, &scale_oman, &active  );
                oman *= raddeg;
                if ( active == 1 ) fitted_parameters.push_back(absolute_parameter_map[17]);
        }
        if (str.find("dphase0") != string::npos){
                sscanf( line, "%s %Le %Le %i", textin, &dphase0, &scale_dphase0, &active  );
                if ( active == 1 ) fitted_parameters.push_back(absolute_parameter_map[19]);
        }
        if (str.find("SEP_D") != string::npos){
                sscanf( line, "%s %Le %Le  %i", textin, &SEP_D, &scale_SEP_D, &active  );
                if ( active == 1 ) fitted_parameters.push_back(absolute_parameter_map[20]);
        }
        if (sscanf( line, "SEP_gamma %Le %Le %i", &SEP_gamma, &scale_SEP_gamma, &active  ) == 3){
                if ( active == 1 ) fitted_parameters.push_back(absolute_parameter_map[21]);
        }
        if (sscanf( line, "SEP_beta_0pp %Le %Le %i", &SEP_beta_0pp, &scale_SEP_beta_0pp, &active  ) == 3){
                if ( active == 1 ) fitted_parameters.push_back(absolute_parameter_map[22]);
        }
         if (sscanf( line, "SEP_beta_p00 %Le %Le %i", &SEP_beta_p00, &scale_SEP_beta_p00, &active  ) == 3){
                if ( active == 1 ) fitted_parameters.push_back(absolute_parameter_map[23]);
        }
        if (sscanf( line, "SEP_beta_0p0 %Le %Le %i", &SEP_beta_0p0, &scale_SEP_beta_0p0, &active  ) == 3){
                if ( active == 1 ) fitted_parameters.push_back(absolute_parameter_map[24]);
        }
        if (str.find("right_ascension1") != string::npos){
            sscanf( line, "%s %Le %Le %i", textin, &RA1, &scale_RA1, &active );
            if ( active == 1 ) fitted_parameters.push_back(absolute_parameter_map[28]);
        }
        else if (str.find("right_ascension") != string::npos){
            sscanf( line, "%s %Le %Le %i", textin, &RA, &scale_RA, &active );
            if ( active == 1 ) fitted_parameters.push_back(absolute_parameter_map[25]);
        }
        if (str.find("declination1") != string::npos){
            sscanf( line, "%s %Le %Le %i ", textin, &DEC1, &scale_DEC1, &active );
            if ( active == 1 ) fitted_parameters.push_back(absolute_parameter_map[29]);
        }
        else if (str.find("declination") != string::npos){
            sscanf( line, "%s %Le %Le %i", textin, &DEC, &scale_DEC, &active );
            if ( active == 1 ) fitted_parameters.push_back(absolute_parameter_map[26]);
        }
        if (str.find("distance1") != string::npos){
            sscanf( line, "%s %Le %Le %i", textin, &distance1, &scale_distance1, &active );
            if ( active == 1 ) fitted_parameters.push_back(absolute_parameter_map[30]);
        }
        else if (str.find("distance") != string::npos){
            sscanf( line, "%s %Le %Le %i", textin, &distance, &scale_distance, &active );
            if ( active == 1 ) fitted_parameters.push_back(absolute_parameter_map[27]);
        }
        if (str.find("dispmeasure1") != string::npos){
            sscanf( line, "%s %Le %Le %i", textin, &DM1, &scale_DM1, &active );
            if ( active == 1 ) fitted_parameters.push_back(absolute_parameter_map[32]);
        }
        else if (str.find("dispmeasure") != string::npos){
            if (str.find("dispmeasure_X") != string::npos){
                sscanf(line, "dispmeasure_X%i %Le %Le %i", &index, &xread, &xread_scale, &active );
                if (index > DMX.size())
                {
                    DMX.resize(index, zero );
                    scale_DMX.resize(index, un);
                    Insert_in_parameter_maps(33, index);
//                     shift_absparam = 0.;//index - (absolute_parameter_map[30] - absolute_parameter_map[29]);
//
//                     // Update the fitted the parameter map
//                     min_shifted_index = 30;//absolute_parameter_map[28]
//                     for (j=0; j < fitted_parameters.size() ; j++)
//                     {
//                         if (fitted_parameters[j] >= min_shifted_index ) fitted_parameters[j] += shift_absparam;
//                     };
//
//                     // Update the absolute parameter map
//                     for (j=29 + 1; j < absolute_parameter_map.size() ; j++)
//                     {
//                         absolute_parameter_map[j] += shift_absparam;
//                     };

                };
                DMX[index-1] = xread;
                scale_DMX[index-1] = xread_scale;
                if ( active == 1 ) fitted_parameters.push_back(absolute_parameter_map[33] + index - 1 );
            }
            if (str.find("dispmeasure_FD") != string::npos){
                sscanf(line, "dispmeasure_FD%i %Le %Le %i", &index, &xread, &xread_scale, &active );
//                 printf("index %d \n", index);
//                 printf("indexxread %.15Le \n", xread);
//                 printf("indexsca %.15Le \n", xread_scale);
                if (index > FD.size())
                {
                    FD.resize(index, zero );
                    scale_FD.resize(index, un);
                    Insert_in_parameter_maps(34, index );
                    printf("fd size %i\n", FD.size());
                    printf("fd size %i\n", FD.size());
                };
                FD[index-1] = xread;
                scale_FD[index-1] = xread_scale;
                if ( active == 1 ) fitted_parameters.push_back(absolute_parameter_map[34] + index - 1 );

            }
            else
            {
                sscanf( line, "%s %Le %Le %i", textin, &xread, &xread_scale, &active );
                DM = xread;
                scale_DM = xread_scale;
                if ( active == 1 ) fitted_parameters.push_back(absolute_parameter_map[31]);
            }
        }
        if (str.find("quadrupole") != string::npos){
                sscanf(line, "quadrupole%i %Le %Le %i", &index, &xread, &xread_scale, &active );
                if (index > 0)
                {
                    if (index > quadrupole.size())
                    {
                        quadrupole.resize(index, zero );
                        scale_quadrupole.resize(index, un);
                        Insert_in_parameter_maps(35, index );
                    };
                    quadrupole[index-1] = xread;
                    scale_quadrupole[index-1] = xread_scale;
                    if ( active == 1 ) fitted_parameters.push_back(absolute_parameter_map[35] + index - 1 );
                } else
                {
                    printf("\nError ! quadrupole index invalid : %i\n\n", index);
                }
        }
        if (sscanf( line, "efac %Le %Le %i", &efac, &scale_efac, &active  ) == 3){
                if ( active == 1 ) fitted_parameters.push_back(absolute_parameter_map[36]);
        }
        if (sscanf( line, "delta_i %Le %Le %i", &delta_i, &scale_delta_i, &active  ) == 3){
                if ( active == 1 ) fitted_parameters.push_back(absolute_parameter_map[37]);
        }
        // Add parameter here : "else if ... " beware if a parameter name is included in another parameter name you need to take care of the reading order. See the example of "dispmeasure" or "spinfreq".
        if (str.find("treference") != string::npos){
            sscanf( line, "%s %Le ", textin, &treference );
        }
        if (str.find("geometric") != string::npos){
            sscanf( line, "%s %i ", textin, &ival );
            geometric = ival;
        }
        if (str.find("shklovskii") != string::npos){
            sscanf( line, "%s %i ", textin, &ival );
            shklovskii = ival;
        }
        if (str.find("kopeikin") != string::npos){
            sscanf( line, "%s %i ", textin, &ival );
            kopeikin = ival;
        }
        if (str.find("roemer") != string::npos){
            sscanf( line, "%s %i ", textin, &ival );
            roemer = ival;
        }
        if (str.find("einstein") != string::npos){
            sscanf( line, "%s %i ", textin, &ival );
            einstein = ival;
        }
        if (str.find("shapiro") != string::npos){
            sscanf( line, "%s %i ", textin, &ival );
            shapiro = ival;
        }
        if (str.find("aberration") != string::npos){
            sscanf( line, "%s %i ", textin, &ival );
            aberration = ival;
        }
        if (str.find("truefreq") != string::npos){
            sscanf( line, "%s %i ", textin, &ival );
            truefreq = ival;
        }
        if (str.find("interpsteps") != string::npos){
            sscanf( line, "%s %i ", textin, &ival );
            interpsteps_per_period_i = ival;
        }
        if (str.find("interpolation_margin") != string::npos){
            sscanf( line, "%s %f ", textin, &interp_margin );
        }
        if (str.find("integrator") != string::npos){
            sscanf( line, "%s %i ", textin, &ival );
            integrator_type = ival;
        }
        if (str.find("integration_tolerance") != string::npos){
            sscanf( line, "%s %Le ", textin, &tolint );
        }
        if (str.find("posepoch") != string::npos){
            sscanf(line, "%s %Le ", textin, &posepoch);
        }
        if (str.find("parameter_set") != string::npos){
            sscanf(line, "%s %i ", textin, &parameter_set);
        }
//         else
//         {printf("\n-------++++++++++++++++end\n\n");}
    }
    fclose(fp);


    return;
}


void Parametres::Save_parfile(const char * filename)
{
    FILE *fp;
    value_type inter = 0.;

    fp = fopen(filename,"w");

    vector<int> fitstatus(nfitparams, 0);
    for (int i = 0 ; i < fitted_parameters.size() ; i++)
    {
        fitstatus[ fitted_parameters[i] ] = 1;
    }

    fprintf( fp, "# Tempo2 parfile\n");
    fprintf( fp, "%s %s \n", "tempo2parfile", t2parfile ) ;

    fprintf( fp, "\n# Time of reference\n");
    fprintf( fp, "%s %.19Le \n", "treference", treference + timeshift ) ;
    fprintf( fp, "%s %.19Le \n", "posepoch", posepoch + timeshift ) ;

    fprintf( fp, "\n# Enabled delays\n");
    fprintf( fp, "%s %i \n", "geometric", int(geometric) ) ;
    fprintf( fp, "%s %i \n", "kopeikin", int(kopeikin) ) ;
    fprintf( fp, "%s %i \n", "shklovskii", int(shklovskii) ) ;
    fprintf( fp, "%s %i \n", "roemer", int(roemer) ) ;
    fprintf( fp, "%s %i \n", "einstein", int(einstein) ) ;
    fprintf( fp, "%s %i \n", "shapiro", int(shapiro) ) ;
    fprintf( fp, "%s %i \n", "aberration", int(aberration) ) ;
    fprintf( fp, "%s %i \n", "truefreq", int(truefreq) ) ;

    fprintf( fp, "\n# Integrator parameters \n");
    fprintf( fp, "%s %i \n", "integrator", integrator_type ) ;
    fprintf( fp, "%s %.19Le \n", "integration_tolerance", tolint ) ;

    fprintf( fp, "\n# Interpolation parameters \n");
    fprintf( fp, "%s %i \n", "interpsteps", interpsteps_per_period_i ) ;
    fprintf( fp, "%s %f \n", "interpolation_margin", interp_margin ) ;

    fprintf( fp, "\n# Parameter set \n");
    fprintf( fp, "%s %i \n", "parameter_set", parameter_set ) ;

    fprintf( fp, "\n# ***** Fittable parameters ****\n");
    fprintf( fp, "\n# Position in the sky\n");
    fprintf( fp, "%s %.19Le %.19Le %i \n", "right_ascension", RA, scale_RA, fitstatus[absolute_parameter_map[25]]) ;
    fprintf( fp, "%s %.19Le %.19Le %i \n", "declination", DEC, scale_DEC , fitstatus[absolute_parameter_map[26]]) ;
    fprintf( fp, "%s %.19Le %.19Le %i \n", "distance", distance, scale_distance , fitstatus[absolute_parameter_map[27]]) ;
    fprintf( fp, "%s %.19Le %.19Le %i \n", "right_ascension1", RA1, scale_RA1, fitstatus[absolute_parameter_map[28]]) ;
    fprintf( fp, "%s %.19Le %.19Le %i \n", "declination1", DEC1, scale_DEC1 , fitstatus[absolute_parameter_map[29]]) ;
    fprintf( fp, "%s %.19Le %.19Le %i \n", "distance1", distance1, scale_distance1 , fitstatus[absolute_parameter_map[30]]) ;

    fprintf( fp, "\n# Dispersion Measure\n");
    fprintf( fp, "%s %.19Le %.19Le %i \n", "dispmeasure",  DM, scale_DM, fitstatus[absolute_parameter_map[31]]) ;
    fprintf( fp, "%s %.19Le %.19Le %i \n", "dispmeasure1", DM1, scale_DM1 , fitstatus[absolute_parameter_map[32]]) ;
    if (DMX.size() >= 1)
    {
        for (int i = 0 ; i < DMX.size() ; i++)
        {
            fprintf( fp, "%s%i %.19Le %.19Le %i \n", "dispmeasure_X",i+1,  DMX[i], scale_DMX[i], fitstatus[absolute_parameter_map[33] + i]) ;
        };
    };

    if (FD.size() >= 1)
    {
        for (int i = 0 ; i < FD.size() ; i++)
        {
            fprintf( fp, "%s%i %.19Le %.19Le %i \n", "dispmeasure_FD",i+1,  FD[i], scale_FD[i], fitstatus[absolute_parameter_map[34] + i]) ;
        };
    };

    if (quadrupole.size() >= 1)
    {
        for (int i = 0 ; i < quadrupole.size() ; i++)
        {
            fprintf( fp, "%s%i %.19Le %.19Le %i \n", "quadrupole",i+1,  quadrupole[i], scale_quadrupole[i], fitstatus[absolute_parameter_map[35] + i]) ;
        };
    };

    fprintf( fp, "\n#Pulsar system parameters \n");
    fprintf( fp, "%s %.19Le  %.19Le %i \n", "spinfreq", Parameters(absolute_parameter_map[0])/daysec, Parameter_scale(absolute_parameter_map[0]) , fitstatus[absolute_parameter_map[0]]) ;
    fprintf( fp, "%s %.19Le %.19Le %i \n", "spinfreq1", Parameters(absolute_parameter_map[1])/pow(daysec,2), Parameter_scale(absolute_parameter_map[1]) , fitstatus[absolute_parameter_map[1]]) ;
    fprintf( fp, "\n");
    fprintf( fp, "%s %.19Le %.19Le %i \n", "eta_p", Parameters(absolute_parameter_map[2]), Parameter_scale(absolute_parameter_map[2]) , fitstatus[absolute_parameter_map[2]]) ;
    fprintf( fp, "%s %.19Le %.19Le %i \n", "apsini_i", Parameters(absolute_parameter_map[3])/clight, Parameter_scale(absolute_parameter_map[3]) , fitstatus[absolute_parameter_map[3]]) ;
    fprintf( fp, "%s %.19Le %.19Le %i \n", "kappa_p", Parameters(absolute_parameter_map[4]), Parameter_scale(absolute_parameter_map[4]) , fitstatus[absolute_parameter_map[4]]) ;
    fprintf( fp, "%s %.19Le %.19Le %i \n", "apcosi_i", Parameters(absolute_parameter_map[5])/clight, Parameter_scale(absolute_parameter_map[5]) , fitstatus[absolute_parameter_map[5]]) ;
    fprintf( fp, "%s %.19Le %.19Le %i \n", "delta_i", Parameters(absolute_parameter_map[37]), Parameter_scale(absolute_parameter_map[37]) , fitstatus[absolute_parameter_map[37]]) ;

    inter = Parameters(absolute_parameter_map[6]) + timeshift ;
    fprintf( fp, "%s %.19Le %.19Le %i \n", "tasc_p", inter, Parameter_scale(absolute_parameter_map[6]) , fitstatus[absolute_parameter_map[6]]) ;
    fprintf( fp, "%s %.19Le %.19Le %i \n", "period_i", Parameters(absolute_parameter_map[7]), Parameter_scale(absolute_parameter_map[7]) , fitstatus[absolute_parameter_map[7]]) ;
    fprintf( fp, "\n");
    fprintf( fp, "%s %.19Le %.19Le %i \n", "eta_b", Parameters(absolute_parameter_map[8]), Parameter_scale(absolute_parameter_map[8]) , fitstatus[absolute_parameter_map[8]]) ;
    fprintf( fp, "%s %.19Le %.19Le %i \n", "absini_o", Parameters(absolute_parameter_map[9])/clight, Parameter_scale(absolute_parameter_map[9]) , fitstatus[absolute_parameter_map[9]]) ;
    fprintf( fp, "%s %.19Le %.19Le %i \n", "kappa_b", Parameters(absolute_parameter_map[10]), Parameter_scale(absolute_parameter_map[10]) , fitstatus[absolute_parameter_map[10]]) ;
    fprintf( fp, "%s %.19Le %.19Le %i \n", "abcosi_o", Parameters(absolute_parameter_map[11])/clight, Parameter_scale(absolute_parameter_map[11]) , fitstatus[absolute_parameter_map[11]]) ;
    inter = Parameters(absolute_parameter_map[12]) + timeshift ;
    fprintf( fp, "%s %.19Le %.19Le %i \n", "tasc_b", inter, Parameter_scale(absolute_parameter_map[12]) , fitstatus[absolute_parameter_map[12]]) ;
    fprintf( fp, "%s %.19Le %.19Le %i \n", "period_o", Parameters(absolute_parameter_map[13]), Parameter_scale(absolute_parameter_map[13]) , fitstatus[absolute_parameter_map[13]]) ;
    fprintf( fp, "\n");
    fprintf( fp, "%s %.19Le %.19Le %i \n", "masspar_p", Parameters(absolute_parameter_map[14]), Parameter_scale(absolute_parameter_map[14]) , fitstatus[absolute_parameter_map[14]]) ;
    fprintf( fp, "%s %.19Le %.19Le %i \n", "masspar_i", Parameters(absolute_parameter_map[15]), Parameter_scale(absolute_parameter_map[15]), fitstatus[absolute_parameter_map[15]]) ;
    fprintf( fp, "%s %.19Le %.19Le %i \n", "mass_o", Parameters(absolute_parameter_map[16]), Parameter_scale(absolute_parameter_map[16]), fitstatus[absolute_parameter_map[16]]) ;
    fprintf( fp, "\n");
    fprintf( fp, "%s %.19Le %.19Le %i \n", "oman", Parameters(absolute_parameter_map[17])/raddeg, Parameter_scale(absolute_parameter_map[17]) , fitstatus[absolute_parameter_map[17]]) ;
    fprintf( fp, "%s %.19Le %.19Le %i \n", "deltaoman", Parameters(absolute_parameter_map[18])/raddeg, Parameter_scale(absolute_parameter_map[18]) , fitstatus[absolute_parameter_map[18]]) ;
    fprintf( fp, "\n");
    fprintf( fp, "%s %.19Le %.19Le %i \n", "dphase0", Parameters(absolute_parameter_map[19]), Parameter_scale(absolute_parameter_map[19]) , fitstatus[absolute_parameter_map[19]]) ;
    fprintf( fp, "\n");
    fprintf( fp, "\n#SEP violation parameters \n");
    fprintf( fp, "%s %.19Le %.19Le %i \n", "SEP_D", Parameters(absolute_parameter_map[20]), Parameter_scale(absolute_parameter_map[20]) , fitstatus[absolute_parameter_map[20]]) ;
    fprintf( fp, "%s %.19Le %.19Le %i \n", "SEP_gamma", Parameters(absolute_parameter_map[21]), Parameter_scale(absolute_parameter_map[21]) , fitstatus[absolute_parameter_map[21]]) ;
    fprintf( fp, "%s %.19Le %.19Le %i \n", "SEP_beta_0pp", Parameters(absolute_parameter_map[22]), Parameter_scale(absolute_parameter_map[22]) , fitstatus[absolute_parameter_map[22]]) ;
    fprintf( fp, "%s %.19Le %.19Le %i \n", "SEP_beta_p00", Parameters(absolute_parameter_map[23]), Parameter_scale(absolute_parameter_map[23]) , fitstatus[absolute_parameter_map[23]]) ;
    fprintf( fp, "%s %.19Le %.19Le %i \n", "SEP_beta_0p0", Parameters(absolute_parameter_map[24]), Parameter_scale(absolute_parameter_map[24]) , fitstatus[absolute_parameter_map[24]]) ;
    fprintf( fp, "\n");
    fprintf( fp, "\n#Others \n");
    fprintf( fp, "%s %.19Le %.19Le %i", "efac", Parameters(absolute_parameter_map[36]), Parameter_scale(absolute_parameter_map[36]) , fitstatus[absolute_parameter_map[36]]) ;
    // Add parameter here

    fclose(fp);

    return ;
}




void Parametres::Print()
{
    int i = 0;
    vector<int> fitstatus(nfitparams, 0);
    for (i = 0 ; i < fitted_parameters.size() ; i++)
    {
        fitstatus[ fitted_parameters[i] ] = 1;
    }
    printf("%s %s \n", "Tempo 2 parfile :", t2parfile) ;
    printf("%s %.19Le \n", "Time of reference, treference + timeshift :", treference + timeshift ) ;
    printf("%s %.19Le \n", "Time of reference for position in the sky, posepoch + timeshift :", posepoch + timeshift ) ;

    printf("%s %i \n", "geometric", int(geometric) ) ;
    printf("%s %i \n", "kopeikin", int(kopeikin) ) ;
    printf("%s %i \n", "shklovskii", int(shklovskii) ) ;
    printf("%s %i \n", "roemer", int(roemer) ) ;
    printf("%s %i \n", "einstein", int(einstein) ) ;
    printf("%s %i \n", "shapiro", int(shapiro) ) ;
    printf("%s %i \n", "aberration", int(aberration) ) ;
    printf("%s %i \n", "truefreq", int(truefreq) ) ;

    printf("%s %i \n", "integrator", integrator_type ) ;
    printf("%s %i \n", "interpsteps_per_period_i", interpsteps_per_period_i ) ;
    printf("%s %f \n", "interp_margin", interp_margin ) ;
    printf("%s %.19Le \n", "Tolerance level of integrator, tolint : ", tolint ) ;

    printf("%s %.19Le \n", "Timeshift applied to times internally, timeshift : ", timeshift );

    printf("%s %i \n", "Parameter set (0 : Pi and Po fitted ; 1 : masspar_p and mo fitted) :", parameter_set ) ;

    printf("\n   Fittable parameters : \n");
    for (i = 0 ; i < nfitparams ; i++)
    {
        if (fitstatus[i] == 1)
            printf( "%i : %s %.19Le %.19Le fitted \n", i, fitparams_names[i], Parameters(i), Parameter_scale(i) ) ;
        else
            printf( "%i : %s %.19Le %.19Le \n", i, fitparams_names[i], Parameters(i), Parameter_scale(i) ) ;
    }
    printf("\nNumber of fitted parameters : %i \n", static_cast<int>(fitted_parameters.size()));

    printf("\n   DMX ranges : \n");
    for (i = 0 ; i < DMX.size() ; i++)
        printf("DMX %i %.0Lf %.0Lf\n", i+1, DMXranges[i], DMXranges[i+1]);

    printf("\n   Derived parameters : \n");

    printf("Mp %.19Le \n", Mp);
    printf("Mi %.19Le \n", Mi);
    printf("ei %.19Le \n", ei);
    printf("eo %.19Le \n", eo);
    printf("omp %.19Le \n", omp);
    printf("omB %.19Le \n", omB);
    printf("tperii %.19Le \n", tperii);
    printf("tperio %.19Le \n", tperio);
    printf("ap %.19Le \n", ap);
    printf("aB %.19Le \n", aB);
    printf("anglii %.19Le \n", anglii);
    printf("anglio %.19Le \n", anglio);
    printf("DopplerF %.19Le \n", DopplerF);
    for (i=0 ; i < quadrupole_kgm2.size(); i++) printf("quadrupole%i (kg.m^2) %.19Le \n", i, quadrupole_kgm2[i]);

    return;

}



void Rotate_PSB_to_SSB(valarray<value_type> & vector3, const value_type & alpha, const value_type & delta)
// Rotate the vectors expressed in the PSB frame (as expressed from orbel2statevect) in the SSB frame. No Lorentz boost just rotation.
{
    value_type sa = sin(alpha);
    value_type ca = cos(alpha);
    value_type sd = sin(delta);
    value_type cd = cos(delta);
    value_type vi[3] ;

    vi[0] = vector3[0] ;
    vi[1] = vector3[1] ;
    vi[2] = vector3[2] ;

/*    vector3[0] = vi[0] * sa    +  vi[1] *  ca*cd  +  vi[2] * ( - ca * sd );
    vector3[1] = vi[0] * (-ca) +  vi[1] *  sa*cd  +  vi[2] * ( - sa * sd );
    vector3[2] =                  vi[1] *  sd     +  vi[2] * cd;   */
//                    na // u_alpha     nss                 n3' -> -u_delta
/*    vector3[0] = vi[0] * (-sa)    +  vi[1] *  ca*cd  +  vi[2] * (  ca * sd );
    vector3[1] = vi[0] * ca       +  vi[1] *  sa*cd  +  vi[2] * (  sa * sd );
    vector3[2] =                     vi[1] *  sd     +  vi[2] * -cd;  */

//                    na // u_alpha     u_delta                 nss
    vector3[0] = vi[0] * (-sa)    +  vi[1] * (  -ca * sd ) + vi[2] *  ca*cd    ;
    vector3[1] = vi[0] * ca       +  vi[1] * (  -sa * sd ) + vi[2] *  sa*cd    ;
    vector3[2] =                     vi[1] * cd            + vi[2] *  sd       ;

    return;
}

void Rotate_PSB_to_SSB(value_type * vector3, const value_type & alpha, const value_type & delta)
// Rotate the vectors expressed in the PSB frame (as expressed from orbel2statevect) in the SSB frame. No Lorentz boost just rotation.
{
    value_type sa = sin(alpha);
    value_type ca = cos(alpha);
    value_type sd = sin(delta);
    value_type cd = cos(delta);
    value_type vi[3] ;

    vi[0] = vector3[0] ;
    vi[1] = vector3[1] ;
    vi[2] = vector3[2] ;

    vector3[0] = vi[0] * (-sa)    +  vi[1] * (  -ca * sd ) + vi[2] *  ca*cd    ;
    vector3[1] = vi[0] * ca       +  vi[1] * (  -sa * sd ) + vi[2] *  sa*cd    ;
    vector3[2] =                     vi[1] * cd            + vi[2] *  sd       ;

    return;
}

void Rotate_SSB_to_PSB(valarray<value_type> & vector3, const value_type & alpha, const value_type & delta)
// Inverse of Rotate_PSB_to_SSB
{
    value_type sa = sin(alpha);
    value_type ca = cos(alpha);
    value_type sd = sin(delta);
    value_type cd = cos(delta);
    value_type vi[3] ;

    vi[0] = vector3[0] ;
    vi[1] = vector3[1] ;
    vi[2] = vector3[2] ;

    vector3[0] = vi[0] * (-sa)          +  vi[1] * ca     ;
    vector3[1] = vi[0] * (-ca*sd)       +  vi[1] * (  -sa * sd ) + vi[2] *  cd    ;
    vector3[2] = vi[0] * ca*cd          +  vi[1] * sa*cd         + vi[2] *  sd       ;

    return;
}

void Rotate_SSB_to_PSB(value_type * vector3, const value_type & alpha, const value_type & delta)
// Inverse of Rotate_PSB_to_SSB
{
    value_type sa = sin(alpha);
    value_type ca = cos(alpha);
    value_type sd = sin(delta);
    value_type cd = cos(delta);
    value_type vi[3] ;

    vi[0] = vector3[0] ;
    vi[1] = vector3[1] ;
    vi[2] = vector3[2] ;

    vector3[0] = vi[0] * (-sa)          +  vi[1] * ca     ;
    vector3[1] = vi[0] * (-ca*sd)       +  vi[1] * (  -sa * sd ) + vi[2] *  cd    ;
    vector3[2] = vi[0] * ca*cd          +  vi[1] * sa*cd         + vi[2] *  sd       ;

    return;
}





void Parametres::Compute_state_vectors(valarray<value_type> & rp, valarray<value_type> & rpt,
                                       valarray<value_type> & ri, valarray<value_type> & rit,
                                       valarray<value_type> & ro, valarray<value_type> & rot )
/*
 * This routine computes all the inner variables that depend on the parameters used .
 * It should be called every time parameters are changed . (it just need all the outer info : par file and data file)
 * It should ensure compatibility with different system of parameters (since the inner variables should be fairly independant on it)
 * Variables set :
 * spinfreq, spinfreq1, delaymax
 * dt_interp, ninterp, toa_in_interp, treference_in_interp
 *
 *  Compute end Initialize all the necessary stuff for integration of the equation of motion       * with the inherited properties from the "Integrateur" class;
 *
 *  Add parameter here: if your parameter is used to initialize some seocndary quantities.
 *
 * TODO : Ideally the parti that initialises derived quatities should be separate from the actual computation of state vectors.
 */
{

        value_type Mpi = zero ;
        valarray<value_type> rBi(3);
        valarray<value_type> rBit(3);
        valarray<value_type> nip(3), nio(3), npo(3);
        valarray<value_type> Ppi(3), MXip(3);

        value_type rip, rpo, rio = zero ;
        value_type nrpt2, nrit2, nrot2 = zero ;
        value_type M1PN = zero ;
        value_type fmasse = zero;
        value_type Moold = zero;
        value_type Mb = zero;
        value_type nu = zero;
        value_type norbi = zero;
        value_type sepi = zero;

//         value_type pmra = RA1 * 2.3044227750662406e-15 ; // mas/yr -> rad / s
//         value_type pmdec = DEC1 * 2.3044227750662406e-15 ; // mas/yr -> rad/s

//             DopplerF =pow(-pmra * sin(RA)  - pmdec*cos(RA)*sin(DEC) ,2); //pow(-pmra * sin(RA) *cos(DEC) - pmdec*cos(RA)*sin(DEC) ,2);
//             DopplerF += pow( pmra * cos(RA)  - pmdec * sin(RA) * sin(DEC), 2);//pow( pmra * cos(RA) * cos(DEC) - pmdec * sin(RA) * sin(DEC), 2);
//             DopplerF += pow( cos(DEC) * pmdec, 2);
//             DopplerF *= pow(distance * (31557600.0),2); // conversion année lumière -> seconde lumière
//             DopplerF += pow((1000 * distance1) / clight,2);
//             DopplerF = (un - (1000 * distance1) / clight) / sqrt( un - DopplerF) ;
             DopplerF = un;

    // SEP parameters, assuming index 0 = neutron star and index>0 weak field body (eg white dwarf):
             Gg[0][1] = un + SEP_D;
             Gg[0][2] = un + SEP_D;
             Gg[1][0] = un + SEP_D;
             Gg[2][0] = un + SEP_D;
             gammabar[0][1] = SEP_gamma;
             gammabar[1][0] = SEP_gamma;
             gammabar[0][2] = SEP_gamma;
             gammabar[2][0] = SEP_gamma;
             betabar[1][0][0] = SEP_beta_0pp;
             betabar[2][0][0] = SEP_beta_0pp;
             betabar[0][1][1] = SEP_beta_p00;
             betabar[0][1][2] = SEP_beta_p00;
             betabar[0][2][1] = SEP_beta_p00;
             betabar[0][2][2] = SEP_beta_p00;
             betabar[1][0][1] = SEP_beta_0p0;
             betabar[1][0][2] = SEP_beta_0p0;
             betabar[2][0][1] = SEP_beta_0p0;
             betabar[2][0][2] = SEP_beta_0p0;
     // Quadrupolar moment parameters

     // Parameter set 3 : goes from delta_i to ap cos(i_i)

     {

     }

     // Orbital parameters
        // Outer orbit
             if (Mo > zero) {// Three-body case
                 eo = sqrt( pow( etaB, 2) + pow(kappaB, 2) ) ;
                 omB = inversetrigo( kappaB / eo, etaB / eo ) ;
//                  tperio = ( tascB + Po * omB / deuxpi ) * DopplerF;
                 aB = sqrt( pow( aBsinio, 2 ) + pow(aBcosio, 2 ) ) ;
                 anglio = acos( aBcosio / aB ) * sgn( aBsinio ) ;
             }
        // Inner orbit
             ei = sqrt( pow(etap,2) + pow(kappap,2) ) ;
             omp = inversetrigo( kappap / ei , etap / ei ) ;
             // tperii moved below in case Pi determined from masses
             if (parameter_set==3 or parameter_set==4 or parameter_set==5 or parameter_set == 6)
             {
               anglii = anglio + delta_i * raddeg;
               ap =  apsinii / sin(anglii);
               apcosii = ap * cos(anglii);
             }
             else
             {
               ap = sqrt( pow(apsinii, 2) + pow( apcosii , 2 ) ) ;
               anglii = acos( apcosii / ap ) * sgn( apsinii ) ;
             }
        // Checks on eccentricities
             if (ei > un )
             {
                 cout << endl << "Warning ! ei > 1" << endl;
                 printf("   etap kappap ei omp %.19Le %.19Le %.19Le %.19Le \n ", etap, kappap, ei, omp);
                 cout << "setting ei = 0.99999999999" << endl << endl;
                 ei = 0.99999999999;
             }
             if (eo > un )
             {
                 cout << endl << "Warning ! eo > 1" << endl;
                 printf("   etaB kappaB eo omB %.19Le %.19Le %.19Le %.19Le \n ", etaB, kappaB, eo, omB);
                 cout << "setting eo = 0.99999999999" << endl << endl;
                 eo = 0.99999999999;
             }


        // Deduce masses from parameters in the same way as in parameter system 1 and 10
            if (Mo > zero) {// Three-body case
                if (parameter_set == 0)
                {
                // Uncomment the following lines to use kepler's third law to deduce the masses
                    Mi = muio ;
                    fmasse = quatre*pi*pi *pow(ap,3) / (Pi*Pi * daysec * daysec * GMsol);
                    Mp = sqrt( pow(Mi,3) / fmasse ) - Mi ;
                    Mb = Mp + Mi ;
                    fmasse = quatre*pi*pi *pow(aB,3) / (Po*Po * daysec * daysec * GMsol);
                    // Solve kepler's third law for third body
                    Mo = 0.4; // initial guess
                    do
                    {
                        Moold = Mo;
                        Mo = pow(fmasse * (Mo + Mb) * (Mo+Mb) , un/trois );
                    }
                    while (abs(Mo - Moold) > pow(dix, -15));
                } else if (parameter_set == 1)
                {
                    Mp = muio + mui; // mui = (Mp + Mi) * 0.5  et muio = (Mp - Mi) * 0.5
                    Mi = mui - muio;
                    // uncomment to deduce periods from masses
                    Pi = sqrt(quatre*pi*pi *pow(ap,3) / ( daysec * daysec * GMsol) / pow(Mi,3)) * (Mp + Mi);
                    Mb = Mp + Mi ;
                    Po = sqrt(quatre*pi*pi *pow(aB,3) / ( daysec * daysec * GMsol) / pow(Mo,3)) * (Mb + Mo);
                }
               else if (parameter_set == 2 or parameter_set == 3 or parameter_set==4 or parameter_set==5  or parameter_set == 6) // mp, mi, mo given by : mui = Mi/Mp, Pi, Po
                {
                  sepi = ap * (1. + 1./mui); // separation of the inner binary
                  norbi = deuxpi/(Pi*daysec);
                  Mb = pow(sepi,3) * pow(norbi,2) / (Ggrav*Msol);
                  Mp = Mb / (1. + mui);
                  Mi = mui * Mp;

                  fmasse = quatre*pi*pi *pow(aB,3) / (Po*Po * daysec * daysec * GMsol);
                  // Solve kepler's third law for third body
                  Mo = 0.4; // initial guess
                  do
                  {
                      Moold = Mo;
                      Mo = pow(fmasse * (Mo + Mb) * (Mo+Mb) , un/trois );
                  }
                  while (abs(Mo - Moold) > pow(dix, -15));
                }
            // version with masses fitted
//                 Mp = undemi * ( muio/ Mo + sqrt( pow( muio/Mo , 2 ) - quatre * mui ) ) ;
//                 Mi = undemi * ( muio/ Mo - sqrt( pow( muio/Mo , 2 ) - quatre * mui ) ) ;
             // version with masses fitted  and a different parametrization

           }
            else { // 2-body case
                Mp = mui ;
                Mi = muio ;
                if (integrator_type == 1 ) // 1PN case
                {
                    // cout << " a " <<endl;
                    fmasse = quatre*pi*pi *pow(ap,3) / (Pi*Pi * daysec * daysec * GMsol);
                    Mp = 1.4;
                    do
                    {
                        nu = Mp * Mi / pow(Mp + Mi, 2);
                        Moold = Mp ;
                        Mp = sqrt( pow(Mi,3) / fmasse )* (un  + GMsol * Mi / (deux*ap * clight2) * ( -neuf + nu) )  - Mi ;
                    } while (abs( Moold - Mp) > pow(dix, -15));
                }
                else //Newtonian case
                {
                    if ( parameter_set ==1 )
                    {
                        // Deduce pulsar mass from companion's mass
                        fmasse = quatre*pi*pi *pow(ap,3) / (Pi*Pi * daysec * daysec * GMsol);
                        Mp = sqrt( pow(Mi,3) / fmasse ) - Mi ;
                    }
                    else
                    {
                        fmasse = quatre*pi*pi *pow(ap,3) / (Pi*Pi * daysec * daysec * GMsol);
                        // Solve kepler's equation for companion
                        Mi = 0.4; // initial guess
                        do
                        {
                            Moold = Mi;
                            Mi = pow(fmasse * (Mi + Mp) * (Mi+Mp) , un/trois );
                        }
                        while (abs(Mi - Moold) > pow(dix, -15));
                    }
                }

            }

            value_type vp2, vb2;
            value_type Uo, Ui;
            value_type DT;
            value_type muperp, mupara;

            if (parameter_set == 4 or parameter_set==5) // pset 4 is equivalent to pset3 with Einstein delay correction to spin frequency
            {
              vp2 = deuxpi * ap / (Pi *daysec) / clight;
              vp2 *= vp2;
              vb2 = deuxpi * aB / (Po*daysec)  / clight;
              vb2 *= vb2;
              Uo = GMsol * Mo / (clight2 * aB *(1 + Mb / Mo));
              Ui = GMsol * Mi / (clight2 * ap *(1 + Mp / Mi));
              true_spinfreq = f/(un - 0.5*(vp2 + vb2) - Ui - Uo);
            }
            else
            {
              true_spinfreq = f;
            }

            if (parameter_set == 5 ) // pset 5 is equivalent to pset 4 with Schklovskii correction to spin frequency derivative
            {
              value_type muperp = sqrt(RA1 * RA1 + DEC1 * DEC1) * radmasdeg / yrsec;
              value_type mupara = distance1 * radmasdeg / yrsec;
              true_spinfreq1 = f1 + f* distance * lightyrmeter * muperp * muperp *(1 - muperp * mupara)/clight * daysec; //  there's a mistake here. See pset 6 below for the correct expression
            }
            else if (parameter_set == 6) // pset 6  is equivalent to pset 5 but with a corrrected expression for the spin freq derivative and shklovskii correction to the spin frequency too
            {
              vp2 = deuxpi * ap / (Pi *daysec) / clight;
              vp2 *= vp2;
              vb2 = deuxpi * aB / (Po*daysec)  / clight;
              vb2 *= vb2;
              Uo = GMsol * Mo / (clight2 * aB *(1 + Mb / Mo));
              Ui = GMsol * Mi / (clight2 * ap *(1 + Mp / Mi));
              muperp = sqrt(RA1 * RA1 + DEC1 * DEC1) * radmasdeg / yrsec;
              mupara = distance1 * radmasdeg / yrsec;
              DT = (treference - posepoch) * daysec;

              true_spinfreq = f/(un - 0.5*(vp2 + vb2) - Ui - Uo - distance * lightyrmeter * muperp * muperp * DT * (1 - 1.5*DT * mupara)/clight);

              true_spinfreq1 = f1 +  true_spinfreq * distance * lightyrmeter * muperp * muperp *(1 - 3*DT * mupara)/clight * daysec; // day^-2
            }
            else
            {
              true_spinfreq1 = f1;
            }

            // Derive internal quadrupole parameters
            quadrupole_kgm2.assign(quadrupole.begin(), quadrupole.end());
            if (parameter_set == 3 or parameter_set == 4 or parameter_set==5 or parameter_set==6) // quadrupole[0] = J2 = 3/2 Q/(M1 a^2) where a is the separation of the inner binary
            {
              for (int i = 0 ; i < quadrupole.size(); i++)
              {
                quadrupole_kgm2[i] *=  deuxtiers * Mi*Msol * pow(ap *(1+ Mp/Mi),2); // in kg.m^2
              }
              if (quadrupole.size() > 0  and integrator_type != 2 and msg_count < 10)
              {
                msg_count++;
                printf("\n WARNING : Bad combination of quadrupole and integrator type !\n");
              }
            }
            else
            {
              printf("\n WARNING : with the current parameter set quadrupole_kgm2 might be in a different unit than kg.m^2. Implementation to do ?\n");
            }


            // Determine tperi here in case Pi and Po are determined from masses (above)
            tperii = (tascp   + Pi * omp / deuxpi) * DopplerF ; // Temps de passage au périastre par rapport au temps de passge au noeud ascendant
            if (Mo > zero)  {
                tperio = ( tascB + Po * omB / deuxpi ) * DopplerF;
            }
            Mpi = Mp + Mi ;

            value_type sv[6] ; // temporary state vector

            // Initial orbital elements to state vector for inner binary
            if (integrator_type == 1 or integrator_type==2)
            {
                 orbel2statevect_1pn(treference, ei, DopplerF*ap, omp, anglii, tperii, DopplerF*Pi, oman +delta_oman, Mp, Mi,
                            sv,
                            1, 1) ;}
            else
                orbel2statevect(treference, ei, DopplerF*ap, omp, anglii, tperii, DopplerF*Pi, oman +delta_oman,
                            sv,
                            1, 1) ;


            rp[0] = sv[0] ; rp[1] = sv[1] ; rp[2] = sv[2] ;
            rpt[0] = sv[3] ; rpt[1] = sv[4] ; rpt[2] = sv[5] ;

            // Initial orbital elements to state vector for outer binary
            if (Mo > zero) {
                if (integrator_type == 1 or integrator_type==2)
                    orbel2statevect_1pn(treference , eo,DopplerF* aB, omB, anglio, tperio,DopplerF* Po, oman, Mpi, Mo,
                                sv,
                                1, 1) ;
                 else
                    orbel2statevect(treference , eo,DopplerF* aB, omB, anglio, tperio,DopplerF* Po, oman,
                                sv,
                                1, 1) ;



                rBi[0] = sv[0] ; rBi[1] = sv[1] ; rBi[2] = sv[2] ;
                rBit[0] = sv[3] ; rBit[1] = sv[4] ; rBit[2] = sv[5] ;

                // Changement d'origine de rp vers le centre de masse du système interne
                if (integrator_type == 1  or integrator_type==2) {    // Respect the 1PN conserved center of mass and momentum set to zero


                    ri = - Mp / Mi * rp ;
                    rit = - Mp / Mi * rpt ;
                    rip = norm3d<value_type>(ri - rp) ;
                    nrit2 = pow( rit[0], 2) + pow( rit[1], 2) + pow( rit[2], 2) ;
                    nrpt2 = pow( rpt[0], 2) + pow( rpt[1], 2) + pow( rpt[2], 2) ;
                    nip = (rp - ri ) / rip ;

                    rit = rit - un/(deux * pow( clight, 2 ) * Mi) * ( Mp * rpt * nrpt2 + Mi * rit * nrit2 -
                                                    GMsol * Gg[0][1] * Mi * Mp / rip * ( rit + rpt + dotprod3d<value_type>(rit + rpt, nip) * nip) ) ;
                    // Go to the observer's frame
                    rpt = rpt + rBit - un/(deux* pow( clight, 2) ) * ( deux * dotprod3d<value_type>(rpt, rBit) - GMsol * Gg[0][1] * Mi / rip * dotprod3d<value_type>( rBit, nip ) * nip ) ;
                    rit = rit + rBit - un/(deux* pow( clight, 2) ) * ( deux * dotprod3d<value_type>(rit, rBit) - GMsol * Gg[0][1] * Mp / rip * dotprod3d<value_type>( rBit, nip ) * nip ) ;

                    ri = ri + rBi ;
                    rp = rp + rBi ;

                    // Adjust the state vector of the third body to respect the nullity of the total momentum and center of mass
                    ro = -rBi * Mpi/Mo ;
                    rot = -rBit * Mpi/Mo ;
                    rpo = norm3d<value_type>(ro - rp) ;
                    rio = norm3d<value_type>(ro - ri) ;
                    nrit2 = pow( rit[0], 2) + pow( rit[1], 2) + pow( rit[2], 2) ;
                    nrpt2 = pow( rpt[0], 2) + pow( rpt[1], 2) + pow( rpt[2], 2) ;
                    nrot2 = pow( rot[0], 2) + pow( rot[1], 2) + pow( rot[2], 2) ;
                    nip = (rp - ri ) / rip ;
                    nio = (ro - ri ) / rio ;
                    npo = (ro - rp ) / rpo ;

                    M1PN = ( Mpi ) * ( un +
                                            ( Mp * nrpt2 + Mi * nrit2 - GMsol * Gg[0][1] * Mi * Mp / rip ) / (deux * Mpi * pow(clight, 2 ) ) ) ;

                    ri = un / Mi * (rBi * M1PN - Mp * rp - un / (deux * clight2) * ( Mp * nrpt2 * rp + Mi * nrit2 * ri - GMsol* Gg[0][1] * Mp * Mi / rip * ( rp + ri ) ) ) ;

                    // Part of the impulsion depending only on the inner binary
                    Ppi = rpt * Mp + rit * Mi + un/(deux* clight2 ) * ( Mp * rpt * nrpt2 + Mi * rit * nrit2 -
                                                    GMsol * Gg[0][1] * Mi * Mp / rip * ( rit + rpt + dotprod3d<value_type>(rit + rpt, nip) * nip) ) ;

                    rot = - un/Mo * ( Ppi + un/(deux * clight2 ) * ( Mo * nrot2 * rot -
                                                            Mp * GMsol * Gg[0][2] * Mo / rpo * ( rpt + rot ) - Mi * Gg[1][2] * GMsol * Mo / rio * ( rit + rot ) -
                                                            GMsol * Gg[0][2] * Mp * Mo / rpo * dotprod3d<value_type>(rpt + rot, npo) * npo -
                                                            GMsol * Gg[1][2] * Mi * Mo / rio * dotprod3d<value_type>(rit + rot, nio) * nio ) ) ;

                    // Part of the " Mass * center of mass " depending only on the inner binary
                    MXip = Mp * rp + Mi * ri + un / (deux * clight2) * (Mp * nrpt2 * rp + Mi * nrit2 * rit - GMsol * Gg[0][1] * Mi * Mp / rip * ( ri + rp ) ) ;

                    ro = - un / Mo * ( MXip + un/ (deux * clight2) * ( Mo * nrot2 * ro  - GMsol * Gg[0][2] * Mp * Mo / rpo * ( rp + ro ) - GMsol * Gg[1][2] * Mi * Mo / rio * ( ri + ro ) )) ;


                }
                else {
                    rp = rp + rBi ;
                    rpt = rpt + rBit ;
                    ro = -rBi * Mpi/Mo ;
                    rot = -rBit * Mpi/Mo ;
                    ri = -(rp - rBi) * Mp / Mi + rBi ;
                    rit = -(rpt - rBit) * Mp / Mi + rBit ;
                }
            }
            else { // 2-body case
                if (integrator_type == 1 ) {
                    // In the inner binary frame
                    rBi = zero;
                    rBit = zero;
                    ro = zero;
                    rot=zero;

                    ri = - Mp / Mi * rp ;
                    rit = - Mp / Mi * rpt ;
                    rip = norm3d<value_type>(ri - rp) ;
                    nrit2 = pow( rit[0], 2) + pow( rit[1], 2) + pow( rit[2], 2) ;
                    nrpt2 = pow( rpt[0], 2) + pow( rpt[1], 2) + pow( rpt[2], 2) ; //np.sum(rpt**2)
                    nip = (rp - ri ) / rip ;



                    rit = rit - un/(deux * pow( clight, 2 ) * Mi) * ( Mp * rpt * nrpt2 + Mi * rit * nrit2 -
                                                    GMsol * Gg[0][1] * Mi * Mp / rip * ( rit + rpt + dotprod3d<value_type>(rit + rpt, nip) * nip) ) ;

                    // Adjust the state vector of the third body to respect the nullity of the total momentum and center of mass
                    nrit2 = pow( rit[0], 2) + pow( rit[1], 2) + pow( rit[2], 2) ;
                    nrpt2 = pow( rpt[0], 2) + pow( rpt[1], 2) + pow( rpt[2], 2) ;
                    nrot2 = pow( rot[0], 2) + pow( rot[1], 2) + pow( rot[2], 2) ;
                    nip = (rp - ri ) / rip ;


                    M1PN = ( Mpi ) * ( un +
                                            ( Mp * nrpt2 + Mi * nrit2 - GMsol * Gg[0][1] * Mi * Mp / rip ) / (deux * Mpi * pow(clight, 2 ) ) ) ;

                    ri = un / Mi * ( - Mp * rp - un / (deux * clight2) * ( Mp * nrpt2 * rp + Mi * nrit2 * ri - GMsol * Gg[0][1] * Mp * Mi / rip * ( rp + ri ) ) ) ;

                    // Part of the impulsion depending only on the inner binary
//                     Ppi = rpt * Mp + rit * Mi + un/(deux* clight2 ) * ( Mp * rpt * nrpt2 + Mi * rit * nrit2 -
//                                                     GMsol* Gg[0][1] * Mi * Mp / rip * ( rit + rpt + dotprod3d<value_type>(rit + rpt, nip) * nip) ) ;
//
//                     // Part of the " Mass * center of mass " depending only on the inner binary
//                     MXip = Mp * rp + Mi * ri + un / (deux * clight2) * (Mp * nrpt2 * rp + Mi * nrit2 * ri - GMsol* Gg[0][1] * Mi * Mp / rip * ( ri + rp ) ) ;



////         Uncomment the following lines to check that momentum and center of mass are zero
// //                     cout << "\n Test pos and momentum \n" ; // ! Test !
// //                     Print_table(MXip/ Mpi);
// //                     Print_table(Ppi / Mpi);
                } else {
                    rBi = zero ;
                    rBit = zero ;
                    // Changement d'origine de rp vers le centre de masse du système interne
                    rp = rp + rBi ;
                    rpt = rpt + rBit ;
                    ro = rBi ;
                    rot = rBit ;
                    ri = -(rp - rBi) * Mp / Mi + rBi    ;
                    rit = -(rpt - rBit) * Mp / Mi + rBit ;
                }
            }

    // Rotation to put everything in the same frame as the solar system in tempo i.e. with the pulsar oriented in direction gven by (RA,DEC)
    if (geometric == true )
    {
        Rotate_PSB_to_SSB(rp, RA, DEC) ;
        Rotate_PSB_to_SSB(rpt, RA, DEC) ;
        Rotate_PSB_to_SSB(ri, RA, DEC) ;
        Rotate_PSB_to_SSB(rit, RA, DEC) ;
        Rotate_PSB_to_SSB(ro, RA, DEC) ;
        Rotate_PSB_to_SSB(rot, RA, DEC) ;
    }


  // Set some inner variables
            if (Mo <= zero ) aB = zero;


    return ;
}





void Parametres::Set_parameter_relativeshift(int paramnumber, const double newvalue)
{
    Set_parameters(paramnumber, parameters_ini[paramnumber] + Parameter_scale(paramnumber) * static_cast<value_type>( newvalue ) );
    return;
}


void Parametres::Set_fitted_parameter_relativeshifts(vector<double> parameter_shifts)
{   // parameter_shifts contains as many parameters as fitted_parameters.size()
    int p =0;
    value_type param = 0.;
    motion_changed = false;
    for (int i = 0 ; i < fitted_parameters.size() ;  i++)
    {
        p = fitted_parameters[i];
        // Add parameter here : in the below if statement, all the parameters which change implies recomputing the orbits must be in the "if", otherwise in the "else".
        if  ( (p >= absolute_parameter_map[2] && p <= absolute_parameter_map[18]) || p >= absolute_parameter_map[20] && p <= absolute_parameter_map[24] || p == absolute_parameter_map[35] ||  p == absolute_parameter_map[37])  {
            param = Parameters(p);
            Set_parameters(p, parameters_ini[p] + Parameter_scale(p) * static_cast<value_type>(parameter_shifts[i]) );
            if (Parameters(p) != param ) motion_changed = true ;
        }
        else
        {
            Set_parameters(p, parameters_ini[p] + Parameter_scale(p) * static_cast<value_type>(parameter_shifts[i]) );
        }
    }
    return;
}

void Parametres::Set_fitted_parameter_relativeshifts(double * parameter_shifts)
{
  vector<double> paramshifts(parameter_shifts, parameter_shifts + fitted_parameters.size());
  Set_fitted_parameter_relativeshifts(paramshifts);
}


void Parametres::Set_parameters_relativeshift(double * parameter_shifts)
{
    value_type param = 0.;
    motion_changed = false;
    for (int i = 0 ; i < nfitparams ; i++)
    {
        // Add parameter here : in the below if statement, all the parameters which change implies recomputing the orbits must be in the "if", otherwise in the "else".
        if  (  (i >= absolute_parameter_map[2] && i <= absolute_parameter_map[18]) || i >= absolute_parameter_map[20] && i <= absolute_parameter_map[24] || i == absolute_parameter_map[35]  ||  i == absolute_parameter_map[37])  {
            param = Parameters(i);
            Set_parameter_relativeshift(i, parameter_shifts[i]);
            if (Parameters(i) != param ) motion_changed = true ;
        }
        else {
            Set_parameter_relativeshift(i, parameter_shifts[i]);
        }
    }
    return;
}

void Parametres::Set_parameters_relativeshift(vector<double>  parameter_shifts)
{
    value_type param = 0.;
    motion_changed = false;
    for (int i = 0 ; i < nfitparams ; i++)
    {
        // Add parameter here : in the below if statement, all the parameters which change implies recomputing the orbits must be in the "if", otherwise in the "else".
        if  ( (i >= absolute_parameter_map[2] && i <= absolute_parameter_map[18]) || i >= absolute_parameter_map[20] && i <= absolute_parameter_map[24] || i == absolute_parameter_map[35]  ||  i == absolute_parameter_map[37])  {
            param = Parameters(i);
            Set_parameter_relativeshift(i, parameter_shifts[i]);
            if (Parameters(i) != param ) motion_changed = true ;
        }
        else {
            Set_parameter_relativeshift(i, parameter_shifts[i]);
        };
    }
    return;
}



void Parametres::Convert(int target_pset, int param_number,  value_type & converted_value)
{
  // Run Compute_state_vectors before use !
    int abs_param_number, index;
    if (target_pset == 5 and parameter_set == 4)
    {
      ParamList2AbsParam(param_number, abs_param_number, index);
      if (abs_param_number == 1)
      {
        // printf("prout\n");
        value_type muperp = sqrt(RA1 * RA1 + DEC1 * DEC1) * radmasdeg / yrsec;
        value_type mupara = distance1 * radmasdeg / yrsec;
        // printf("muperp %.Le  mupara %.Le", muperp, mupara);
        converted_value = f1 -   f* distance * lightyrmeter * muperp * muperp *(1 - muperp * mupara)/clight * daysec; //  there's a mistake here. See pset 6 below for the correct expression
      }
      else
      {
        converted_value = Parameters(param_number);
      }
    }
    else if (target_pset == 6 and parameter_set == 5)
    {
      value_type vp2, vb2;
      value_type Uo, Ui;
      ParamList2AbsParam(param_number, abs_param_number, index);
      if (abs_param_number == 0)
      {
        vp2 = deuxpi * ap / (Pi *daysec) / clight;
        vp2 *= vp2;
        vb2 = deuxpi * aB / (Po*daysec)  / clight;
        vb2 *= vb2;
        Uo = GMsol * Mo / (clight2 * aB *(1 + (Mp + Mi) / Mo));
        Ui = GMsol * Mi / (clight2 * ap *(1 + Mp / Mi));
        value_type muperp = sqrt(RA1 * RA1 + DEC1 * DEC1) * radmasdeg / yrsec; // in rad/sec
        value_type mupara = distance1 * radmasdeg / yrsec;
        value_type DT = (treference - posepoch) * daysec; // in sec
        converted_value = true_spinfreq * ( 1 - ( 0.5*(vp2 + vb2) + Ui + Uo) - distance * lightyrmeter * muperp * muperp * DT * (1 - 1.5*DT * mupara)/clight ); // day^-1
      }
      else if (abs_param_number == 1)
      {
        value_type muperp = sqrt(RA1 * RA1 + DEC1 * DEC1) * radmasdeg / yrsec; // in rad/sec
        value_type mupara = distance1 * radmasdeg / yrsec;
        value_type DT = (treference - posepoch) * daysec; // in sec
        converted_value = true_spinfreq1 -   true_spinfreq * distance * lightyrmeter * muperp * muperp *(1 - 3*DT * mupara)/clight * daysec; // day^-2
      }
      else
      {
        converted_value = Parameters(param_number);
      }
    }
    else
    {
      printf("\n Error : Parameter conversion from %i to %i not implemented !\n", parameter_set,target_pset);
    }
}

void Parametres::Convert_in_place(int target_pset)
{
  // This bit is really not optimal
   valarray<value_type>  rp(3);
   valarray<value_type>  ri(3);
   valarray<value_type>  ro(3);
   valarray<value_type>  rpt(3);
   valarray<value_type>  rit(3);
   valarray<value_type>  rot(3);

   Compute_state_vectors(rp, rpt, ri, rit, ro, rot);
   // end of non optimal bit
   int abs_param_number, index;
  value_type converted_value;
  if (target_pset == 5 and parameter_set == 4 or target_pset == 6 and parameter_set == 5)
  {
    for (int i = 0 ; i < nfitparams ; i ++)
    {
      Convert(target_pset, i, converted_value);
      ParamList2AbsParam(i, abs_param_number, index);
      // printf("p %i  abs %i  %.15Le  %.15Le \n", i, abs_param_number, Parameters(i), converted_value);
      Set_parameters(i, converted_value);


    }
    parameter_set = target_pset;
    Set_reference_to_current_parameters();
    Compute_state_vectors(rp, rpt, ri, rit, ro, rot);
  }
  else
  {
    printf("\n Error : Parameter conversion from %i to %i not implemented !\n", parameter_set,target_pset);
  }
}

void Parametres::Convert_relative_shifts(int target_pset, double * parameter_shifts, double * converted_parameter_shifts)
{
  // This bit is really not optimal
   valarray<value_type>  rp(3);
   valarray<value_type>  ri(3);
   valarray<value_type>  ro(3);
   valarray<value_type>  rpt(3);
   valarray<value_type>  rit(3);
   valarray<value_type>  rot(3);

   Compute_state_vectors(rp, rpt, ri, rit, ro, rot);
   // end of non optimal bit

  value_type converted_value;
  if (target_pset == 5 and parameter_set == 4)
  {
    for (int i = 0 ; i < fitted_parameters.size() ; i++) converted_parameter_shifts[i] = parameter_shifts[i];
    // printf("prit\n");
    int fittedindex = Get_fitted_parameter_index(1);
    int paramnumber = absolute_parameter_map[1];
    value_type refvalue;

    if (fittedindex >= 0)
    {
      Reset_to_initial_parameters();
      Compute_state_vectors(rp, rpt, ri, rit, ro, rot);
      Convert(target_pset, paramnumber,  refvalue);

      Set_fitted_parameter_relativeshifts(parameter_shifts);
      Compute_state_vectors(rp, rpt, ri, rit, ro, rot);
      Convert(target_pset, paramnumber,  converted_value);
      converted_parameter_shifts[fittedindex] = (converted_value - refvalue)/Parameter_scale(paramnumber);
   }
  }

  if (target_pset == 6 and parameter_set == 5)
  {
    for (int i = 0 ; i < fitted_parameters.size() ; i++) converted_parameter_shifts[i] = parameter_shifts[i];
    // printf("prit\n");
// ------------------------------------ For f
    int fittedindex = Get_fitted_parameter_index(0); // f
    int paramnumber = absolute_parameter_map[0];     // f
    value_type refvalue;

    if (fittedindex >= 0)
    {
      Reset_to_initial_parameters();
      Compute_state_vectors(rp, rpt, ri, rit, ro, rot);
      Convert(target_pset, paramnumber,  refvalue);

      Set_fitted_parameter_relativeshifts(parameter_shifts);
      Compute_state_vectors(rp, rpt, ri, rit, ro, rot);
      Convert(target_pset, paramnumber,  converted_value);
      converted_parameter_shifts[fittedindex] = (converted_value - refvalue)/Parameter_scale(paramnumber);
   }
// ------------------For f1
    fittedindex = Get_fitted_parameter_index(1); // f1
    paramnumber = absolute_parameter_map[1];     // f1

    if (fittedindex >= 0)
    {
     Reset_to_initial_parameters();
     Compute_state_vectors(rp, rpt, ri, rit, ro, rot);
     Convert(target_pset, paramnumber,  refvalue);

     Set_fitted_parameter_relativeshifts(parameter_shifts);
     Compute_state_vectors(rp, rpt, ri, rit, ro, rot);
     Convert(target_pset, paramnumber,  converted_value);
     converted_parameter_shifts[fittedindex] = (converted_value - refvalue)/Parameter_scale(paramnumber);
    }
  }
}
