/* This code implements a timing model and fitting procedures aimed at studiyng th triple system J0337+1715 (Ransom et al. 2013)
 *
 * Written by Guillaume Voisin 2017 , LUTh, Observatoire de Paris, PSL Research University (guillaume.voisin@obspm.fr astro.guillaume.voisin@google.com)
 *
 */

#include "Constants.h"
#include <cmath>
#include "Utilities.h"
#include <valarray>
#include <cstdlib>
#include "Orbital_elements.h"
#include "Spline.h"
#include "Delay_brut.h"
#include "IO.h"
#include "Fittriple.h"
#include "Parameters.h"

using namespace std ;





double Fittriple::Compute_lnposterior(int fractional) {
    /*
     * Compute the logarithm of the posterior probability ( at a factor ) .
     * If fractional is not 0 considers that the phase residuals are the fractional parts of the phases.
//      * If fractional is 0 the  phase residuals are the difference between the phase and the turn numbers in "turns".
    */

    value_type pRA = previous_RA; // save values before they are changed by Initialize. See use below .
    value_type pDEC = previous_DEC;

    Initialize() ;


    long int i,j =0;
    value_type errtoe = pow(dix, -14);
    value_type npulsdir = 0.;
    value_type lnposterior = zero ;
    value_type * delay ;
    value_type * delay_geom ;
    value_type delay0;
    value_type maxdelay = zero;
    value_type delaymaxtemp = delaymax;//parameters.Pi * 16;
    long int ntisaround = 30 + 2*max(floor( 0.012  / dt_interp ),floor(delaymaxtemp / dt_interp )); //2* (floor(parameters.interp_margin * parameters.interpsteps_per_period_i) +  floor(delaymaxtemp / dt_interp ) ) ; // Number of interpolation steps to take around each toa to compute geometric delays. must be even.
    long int firsttis = 0L;
  // printf("\n\n ntiaroung * dtinterp : %.5Le \n\n", ntisaround * dt_interp);

    value_type pospsr[3];
    value_type velpsr[3];

    delay = (value_type*) malloc( sizeof(value_type) * ninterp );
    delay_geom = (value_type*) malloc( sizeof(value_type) * ntisaround );



//         value_type propermotion[3];
//         propermotion[0] = radmasdeg * ( parameters.RA1 * (-sin(parameters.RA)) + parameters.DEC1*(- cos(parameters.RA) *sin(parameters.DEC)) );// convert mas per year to rad per year
//         propermotion[1] = radmasdeg * ( parameters.RA1 * (cos(parameters.RA)) + parameters.DEC1*(- sin(parameters.RA) *sin(parameters.DEC)) );
//         propermotion[2] = radmasdeg * (  parameters.DEC1*( cos(parameters.DEC)) );
//         Rotate_SSB_to_PSB(propermotion, parameters.RA,parameters.DEC) ;
//         printf("\n check pmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm : %.10Le %.10Le %.10Le \n\n", propermotion[0]/radmasdeg,propermotion[1]/radmasdeg,propermotion[2]/radmasdeg);
//         propermotion[0] = parameters.RA1 * radmasdeg;// convert mas per year to rad per year
//         propermotion[1] = parameters.DEC1 * radmasdeg;
//         propermotion[2] = parameters.distance1 * radmasdeg;

  // Recover proper motion and position from tempo
    for (i = 0; i < 3 ; i ++)
        {
            pospsr[i] = static_cast<value_type>(tempo2_psr[0].posPulsar[i]);
            velpsr[i] = static_cast<value_type>(tempo2_psr[0].velPulsar[i]) / static_cast<value_type>(100); // convertion from rad/century to rad/year.
        }



    if ( motion_changed == true)   // Reintegrate equations of motion only if necessary
    {
        Integrate_Allways() ;

            for (i = 0; i < ninterp ; ++i) {

                sp[i][0] = states[i][0] * length ;
                sp[i][1] = states[i][1] * length ;
                sp[i][2] = states[i][2] * length ;
                sp[i][3] = states[i][9] * length / timescale ;
                sp[i][4] = states[i][10] * length / timescale ;
                sp[i][5] = states[i][11] * length / timescale ;

                si[i][0] = states[i][3] * length ;
                si[i][1] = states[i][4] * length ;
                si[i][2] = states[i][5] * length ;
                si[i][3] = states[i][12] * length / timescale ;
                si[i][4] = states[i][13] * length / timescale ;
                si[i][5] = states[i][14] * length / timescale ;

                so[i][0] = states[i][6] * length ;
                so[i][1] = states[i][7] * length ;
                so[i][2] = states[i][8] * length ;
                so[i][3] = states[i][15] * length / timescale ;
                so[i][4] = states[i][16] * length / timescale ;
                so[i][5] = states[i][17] * length / timescale ;

            }
    }

// *** Uncomment the following and adjust the variables to test the numerical accuracy by integrating from a different reference time using an initial state vector found using a previous integration
//     printf("\n\n state vec at 100 000 : tinterp [100000] = %.19Le \n", tinterp[100000]);
//     for (i=0 ; i < 18 ; i++) printf("x0[%i] = %.19Le ;\n", i, states[100000][i]);

// end of test



    if (motion_changed == false && (pRA != parameters.RA || pDEC != parameters.DEC))
    {
            for (i = 0; i < ninterp ; ++i) {            // In RA or DEC changed, rotate back and forth the vectors without need for recomputation.
                // This could be otpimezed with only one rotation !
                Rotate_SSB_to_PSB(sp[i], pRA, pDEC);
                Rotate_PSB_to_SSB(sp[i], parameters.RA, parameters.DEC);
                Rotate_SSB_to_PSB(sp[i]+3, pRA, pDEC);
                Rotate_PSB_to_SSB(sp[i]+3, parameters.RA, parameters.DEC);

                Rotate_SSB_to_PSB(si[i], pRA, pDEC);
                Rotate_PSB_to_SSB(si[i], parameters.RA, parameters.DEC);
                Rotate_SSB_to_PSB(si[i]+3, pRA, pDEC);
                Rotate_PSB_to_SSB(si[i]+3, parameters.RA, parameters.DEC);

                Rotate_SSB_to_PSB(so[i], pRA, pDEC);
                Rotate_PSB_to_SSB(so[i], parameters.RA, parameters.DEC);
                Rotate_SSB_to_PSB(so[i]+3, pRA, pDEC);
                Rotate_PSB_to_SSB(so[i]+3, parameters.RA, parameters.DEC);
            }
    }



    // Compute Shapiro and aberration delays interpolation
         Delays_Brut_nogeometric(tinterp, parameters.treference,
                 ninterp, treference_in_interp,
                 sp, si, so, pospsr,
                 int_M0, int_M1, int_M2, parameters.f,
                 false, parameters.shapiro, parameters.aberration,
                 delay,  parameters.truefreq, freqshift, NULL
                ) ;

         // Uncomment to test the presence of NaN in the shapiro and aberration delays
//           for (i = 0; i < ninterp ; i ++) // !  Test !
//           {
//               if ( isnan(delay[i]) )
//               {
//                   cout << "In Compute_lnposterior : isnan " << i << endl ;
//                   break;
//               }
//           };

         Spline delays_interpolation( tinterp, delay, ninterp );



   // Compute Einstein delay interpolation
         Delays_Brut_nogeometric(tinterp, parameters.treference,
                 ninterp, treference_in_interp,
                 sp, si, so, pospsr,
                 int_M0, int_M1, int_M2, parameters.f,
                 parameters.einstein, false, false,
                 delay,  parameters.truefreq, freqshift, NULL
                ) ;

         Spline delay_einstein_i( tinterp, delay, ninterp);

  // Initialize Geometric delay interpolation
         Spline delay_geom_i (ntisaround);


  // Diagnostics
         if (get_global_interpolated_delays_flag == true)
         {
             for (i=0; i < diag_interpolated_delays_n ; i++)
             {
                 diag_einstein_interp[i] = static_cast<double>( delay_einstein_i(static_cast<value_type>( diag_interpolated_delays_times[i]), 0, ninterp) );
                 diag_shapiro_aberration_interp[i] = static_cast<double>( delays_interpolation(static_cast<value_type>(diag_interpolated_delays_times[i]) , 0, ninterp) );
             }
         }

         // Computation of margins around the interpolation node. This could be optimized (delaymax can become large because of proper motion and einstein delay, see def in Fittriple-init.cpp)
        long int marginmin = static_cast<long int>(max(floor( 0.012  / dt_interp ), floor((delaymaxtemp ) / dt_interp)) ) +2L ;// + 200L ; // We assume that the delays will never be greater than 0.1 days
        const long int marginsup = static_cast<long int>(floor( 0.012  / dt_interp ) ) + 2L; // Take into account the fact tinterp are bats which vary mostly from the roemer delay of the earth (0.012 ~ 10 ligth min)
        value_type ta, Te0, Te1 = zero;
        value_type test = 0.;



               test = 0. ; // ! test ! , supprimer la variable test dans delays à terme


   // Inversion of the timing formula for each toa

        for (i=0 ; i < ntoas ; ++i ){

            ta = toas[i] * parameters.DopplerF;

            firsttis = toa_in_interp[i] - ntisaround / 2 ;

            if ( tinterp[firsttis] > ta or tinterp[firsttis + ntisaround ] < ta ) printf("\n\n ******* Error !! %li %li %.19Le %.19Le \n\n " , firsttis, ntisaround, tinterp[firsttis], ta);

//             if (i == 1000) {
//                 test = un;
//                 printf(" dtpm tempo %.15e \n", tempo2_psr[0].grrrr_dtpm * static_cast<double>( pow(dix,6) ) );
//                 printf("ntis, %li %.5Le \n", ntisaround, toas[i]);
//              }
//             else
//                 test = 0.;

             Delays_Brut_geometric_local(tinterp + firsttis, toas[i], ntisaround,
                 sp + firsttis, si + firsttis, so + firsttis, pospsr, velpsr, parameters.posepoch, obs_ssb_BAT[i],
                 parameters.distance, parameters.distance1,
                 delay_geom, parameters.truefreq, parameters.kopeikin, parameters.shklovskii, test
                )  ;

            delay_geom_i.ReSpline( tinterp + firsttis, delay_geom ) ;


            Te0 = ta ;

            delay0 = delays_interpolation( Te0 , (toa_in_interp[i] - marginmin),
                                           toa_in_interp[i] + marginsup) ;
            delay0 += delay_geom_i(Te0, ntisaround/2 - marginmin,
                                            ntisaround/2 + marginmin) ;

            Te1 = ta - delays_interpolation( ta - delay0,
                                             toa_in_interp[i] - marginmin, toa_in_interp[i] + marginsup ) ;
            Te1 -= delay_geom_i( ta - delay0,
                                              ntisaround/2 - marginmin, ntisaround/2 + marginmin ) ;

            j = 0 ;
            while ( abs(Te1 - Te0 ) > errtoe and j < 100) {
                ++j;
                Te0 = Te1 ;

                delay0 = delays_interpolation( Te0 , toa_in_interp[i] - marginmin,
                                            toa_in_interp[i] + marginsup ) ;
                delay0 += delay_geom_i(Te0, ntisaround/2 - marginmin,
                                            ntisaround/2 + marginmin) ;

                Te1 = ta - delays_interpolation( ta - delay0,
                                             toa_in_interp[i] - marginmin, toa_in_interp[i] + marginsup ) ;
                Te1 -= delay_geom_i( ta - delay0,
                                              ntisaround/2 - marginmin, ntisaround/2 + marginmin ) ;

            }

            if (j == 100 ) {
                cout << " Iteration did not converge in _Update_delays_ ! " << endl;
                cout << " ninterp, ta, Te1, delays_interpolation( ta ): " << ninterp << ", " <<
                                                                       ta << ", " <<
                                                                       Te1 << ", " <<
                                                                       delays_interpolation( ta ,  toa_in_interp[i] - marginmin,
                                            toa_in_interp[i] + marginsup ) << endl;
            }


            toes[i] = Te1 - delay_einstein_i( Te1, toa_in_interp[i] - marginmin, toa_in_interp[i] + marginsup ) ;

            if (abs(ta - toes[i] ) > maxdelay ) maxdelay = huit *abs(ta - Te1 ); // reevaluate interpolation margins if necessary.

             if (getdelaysflag >  0) // extract delays for diagnostics
             {
                 geomdelay[i] =  static_cast<double>(delay_geom_i( Te1,
                                               ntisaround/2 - marginmin, ntisaround/2 + marginmin ) ) ;
                nogeomdelay[i] = static_cast<double>(delays_interpolation( Te1, toa_in_interp[i] - marginmin,
                                            toa_in_interp[i] + marginsup ) );
                einsteindelay[i] = static_cast<double>(delay_einstein_i( toes[i] , toa_in_interp[i] - marginmin,
                                            toa_in_interp[i] + marginsup ) );
             }
        }


  // Compute the log of the posterior probability function
        //value_type spinPeriodmicrosec =  daysec * pow(dix, 6) / spinfreq ; // spin period in microseconds
        value_type mean = zero;
        value_type phase = zero;
        value_type weightsum = zero;
        value_type phase0 = toes[0] - parameters.treference ;
        phase0 = spinfreq /parameters.DopplerF * phase0 + undemi * spinfreq1/parameters.DopplerF*parameters.DopplerF * pow( phase0, 2 ) + parameters.dphase0;
        if (fractional == 0)
        {
            for (i = 0; i < ntoas ; ++i ) {
                phase = toes[i] - parameters.treference ;
                phase = spinfreq/parameters.DopplerF * phase + undemi * spinfreq1 /pow(parameters.DopplerF,2) * pow( phase, 2 ) ; // phase
                residuals[i] =  phase - phase0 - static_cast<value_type>( turns[i] );
                residuals[i] *= spinPeriodmicrosec ; // residuals in microseconds
                mean += residuals[i] ;
            }
        }
        else
        {
           phase0 = phase0 - dix - undemi ; // dix pour éviter que phase - phase0 ne soit négatif, un demi pour avoir la bonne partie entière (pas celle du tour d'avant)
           for (i = 0; i < ntoas ; ++i ) {
                phase = toes[i] - parameters.treference ;
                phase = spinfreq /parameters.DopplerF * phase + undemi * spinfreq1 /pow(parameters.DopplerF,2) * pow( phase, 2 ) ;
                residuals[i] =  (phase - phase0) - floor( phase - phase0 ) - undemi    ;
                residuals[i] *= spinPeriodmicrosec ;
                mean += residuals[i] ;
            }
        }

        mean /= ntoas;
        // Compute the chi2
        for (i = 0; i < ntoas ; ++i ) {
            lnposterior += pow(  ( residuals[i] - mean ) / errors[i], 2 );
        }
        // Compute the log of the posterior probability density up to a constant and divided by ntoas
        lnposterior = -( 0.5*lnposterior / (parameters.efac* parameters.efac *ntoas) + log(parameters.efac) );

        // To prevent fits from going to negative quadrupole[0]
//         if (parameters.quadrupole.size() >0 and parameters.quadrupole[0] < 0.) lnposterior -= exp(-parameters.quadrupole[0]*5000.);
//         lnposterior /= ntoas ; //  - Quasi-reduced chi2


        free(delay);
        free(delay_geom);


        int p = 0;
        double pshift = 0.;
        if (tracker == true)
        {
            callnumber++;
            printf("Call %i : \n", callnumber);
            for (int i=0 ; i < parameters.fitted_parameters.size() ; i++ ) {
                p = parameters.fitted_parameters[i];
                pshift = abs(parameters.Parameters(p) - parameters.parameters_ini[p]) / parameters.Parameter_scale(p) ;
                printf(" %i:%.4f ", p, pshift);
            }
            printf("\n Log posterior probability  = %.15Le \n\n", lnposterior );
        }


        return double(lnposterior);
}
