"""Apply native low-density material support to the actual coupled owner."""
from pathlib import Path
from types import FunctionType,MethodType
import json,sys,time,signal
import numpy as np
import native_tail_supported_temperature as support
import def_native_updated_gr_return as previous
import def_native_cold_coupling as cold

OUT=support.OUT;BANK=support.BANK;EV=support.EV;GR=support.GR
write,read,sha=support.write,support.read,support.sha
C=previous.C;flow=previous.flow;physical=previous.physical
BaseEOS=cold.prior.optical.ex.EOS;BaseSpectrum=cold.prior.optical.Spectrum


class EOS(BaseEOS):
    def __init__(self,old):
        self.__dict__.update(old.__dict__);self.original=old
        self.low=object.__new__(BaseEOS);fn=BaseEOS.__init__
        FunctionType(fn.__code__,dict(fn.__globals__,OUT=BANK))(self.low)
        self.floor=self.low.floor

    def evaluate(self,rho,lt):
        low=rho<self.original.floor;y=np.broadcast_to(self.y,rho.shape);result=np.zeros((7,len(rho)))
        for mask,model in [(low,self.low),(~low,self.original)]:
            if mask.any():model.y=y[mask];result[:,mask]=model.evaluate(rho[mask],lt[mask])
        return tuple(result)

    def reactions(self,*_):raise AssertionError('Use actual coupled photons')


class Spectrum(BaseSpectrum):
    def __init__(self,old):
        self.__dict__.update(old.__dict__);self.original=old
        self.low=object.__new__(BaseSpectrum);self.low.__dict__.update(old.__dict__)
        c=self.low;c.d=d=dict(np.load(BANK/'spectrum-bank.npz'));c.f=[];c.rev=[]
        for k,y in enumerate(self.ys):
            T=np.exp(d['lt'])[None,:,None];lf=d['log_fraction'][k]
            pref=lf+(self.binding[0]-self.binding)[None,None,:]/(cold.prior.optical.ex.K*T)
            reverse=lf+np.log(y/(1-y))+d['affinity'][k,:,:,None]-self.binding[None,None,:]/(cold.prior.optical.ex.K*T)
            c.f.append([cold.prior.optical.RectBivariateSpline(d['x'],d['lt'],pref[:,:,j]) for j in range(10)])
            c.rev.append([cold.prior.optical.RectBivariateSpline(d['x'],d['lt'],reverse[:,:,j]) for j in range(10)])

    def levels(self,rho,lt,y):
        low=rho<self.rho0*np.exp(self.low.d['x'][-1]);f=np.zeros((len(rho),10));r=np.zeros_like(f)
        for mask,model in [(low,self.low),(~low,self.original)]:
            if mask.any():f[mask],r[mask]=model.levels(rho[mask],lt[mask],y[mask])
        return f,r


capture_run=FunctionType(previous.capture_run.__code__,dict(previous.capture_run.__globals__,OUT=EV),
    argdefs=previous.capture_run.__defaults__)
capture_moment=FunctionType(previous.Capture.moment.__code__,dict(previous.Capture.moment.__globals__,BG=EV),
    closure=previous.Capture.moment.__closure__)


class Capture(previous.Capture):
    def __init__(self):
        super().__init__();self.flow.eos=EOS(self.flow.eos);self.spectrum=Spectrum(self.spectrum);self.tail=[]
        fn=self.flow.primitive.__func__
        self.flow.primitive=MethodType(FunctionType(fn.__code__,dict(fn.__globals__,OUT=EV),argdefs=fn.__defaults__,closure=fn.__closure__),self.flow)

    def run(self,steps,count=None,resume=False):
        self.steps=steps;self.port_file=EV/f'accepted-ports-{steps}.npz'
        self.angular=list(np.load(self.port_file)['angular_luminosity']) if resume else []
        if resume:self.tail=list(read(EV/f'tail-{steps}.json')['rows'])
        try:
            result=capture_run(self,steps,count,resume);result['cost']=self.cost.copy()
            if result['complete']:self.export()
            return result
        finally:write(EV/f'tail-{steps}.json',dict(classification='Counterexample candidate',rows=self.tail))

    def moment(self,U,I,xb,u,theta,eta):
        value=capture_moment(self,U,I,xb,u,theta,eta)
        f=self.flow;m=self.m;seed=f.seed.copy();oldy=np.copy(f.eos.y)
        try:
            rho,v,lt,y=f.primitive(U);p=f.eos(rho,lt)[0];mask=(rho>=f.eos.floor)&(rho<f.eos.original.floor)
            self.tail.append(dict(step=len(self.times),cells=int(mask.sum()),
                mass_g=float(np.sum(U[0,mask]*m.vol[mask])*self.gas_scale/C**2),
                Killing_energy_erg=float(np.sum((U[2,mask]+m.a0*f.eos.cx*U[0,mask])*m.vol[mask])*self.gas_scale),
                pressure_volume_erg=float(np.sum(p[mask]*m.vol[mask])*self.gas_scale),
                maximum_speed_c=float(np.max(abs(v[mask]),initial=0)),
                minimum_temperature_K=float(np.min(np.exp(lt[mask]),initial=np.inf)) if mask.any() else None))
        finally:f.seed=seed;f.eos.y=oldy
        return value

    def export(self):
        ks=range(0,self.steps+1,self.steps//16);states=[dict(np.load(EV/f'state-{self.steps}-{k}.npz')) for k in ks]
        np.savez_compressed(EV/f'coupled-{self.steps}.npz',snapshot_t=np.linspace(0,flow.old.END,17),
            **{'snapshot_'+key:np.array([r[key] for r in states]) for key in states[0]})
        current=np.load(EV/f'source-{self.steps}.npz');mu=self.mu[self.mu>0];w=self.w[self.mu>0]
        energy=flow.old.END/self.steps*np.cumsum(np.asarray(self.angular)@(2*w*mu))
        reference=current['outer_cumulative_energy_erg'][1:]
        err=float(np.max(abs(energy-reference))/max(abs(reference[-1]),1.));assert err<1e-12
        d=dict(current);selected=np.arange(0,self.steps+1,self.steps//16)
        for key in d:
            if key=='t' or key in physical.capture.KEYS+['metric_stress_erg','inner_cumulative_energy_erg','outer_cumulative_energy_erg']:d[key]=d[key][selected]
        np.savez_compressed(GR/f'source-{self.steps}.npz',**d)
        write(EV/f'capture-{self.steps}.json',dict(classification='Counterexample candidate',passed=True,
            canonical_states=17,accepted_angular_port_relative=err,changed_physics=True,identical_old_path_replay=False))


def prepare():
    assert read(BANK/'result.json')['passed'] and not (OUT/'coupling-plan.json').exists()
    paths=[Path(__file__),BANK/'repaired-bank.npz',BANK/'spectrum-bank.npz',OUT/'reallocated-bank-plan.json',
        Path(previous.__file__),Path(physical.__file__),Path(cold.__file__)]
    write(OUT/'coupling-plan.json',dict(classification='Counterexample candidate',
        claim='Apply the retained native tail to the unchanged actual paired photon/material SSP evolution; record nonzero retained pressure/motion, remaining deletion, and complete source histories.',
        clocks=[64,128],horizon_seconds=flow.old.END,controls_seconds=60,controls_native_calls=220,
        pilot_seconds=70,production_seconds=650,GR_seconds=10,
        controls='Withheld native constitutive and integrated spectral values, two sampled native derivative comparisons, old-support bitwise reuse and the seam. No uniform EOS or derivative certificate is inferred.',
        controls_states=[[-23.7,90.,2e-14],[-22.7,310.,1e-10],[-21.,1900.,1e-8],[-19.2,11200.,.0003],[-18.2,18200.,.0007]],
        gates=read(OUT/'plan.json')['gates'],
        stop='Stop on unsupported actual conserved state; retain its U and root failure. No cold clamp or further floor reduction. Preserve old trajectory and all failed precursor probes.',
        bindings={(p.relative_to(Path.cwd()) if p.is_absolute() else p).as_posix():sha(p) for p in paths}))


def controls():
    assert not (OUT/'coupling-controls.json').exists();start=time.monotonic();support.owner.deadline(start,60)
    plan=read(OUT/'coupling-plan.json');n=cold.logarithmic_native(220);n.prefix=dict(n.prefix)
    original=cold.ColdEOS();oldspec=cold.ColdSpectrum();e=EOS(original);s=Spectrum(oldspec)
    d=np.load(cold.prior.optical.photons.OUT/'bank-16-8.npz');a=d['face_a'][-1];E=d['Einf']/a;num=d['num']/a**3
    rows=[];failure=None
    try:
        for x,T,y in plan['controls_states']:
            t=np.log(T);z=n.state(x,t,y);e.y=np.array([y]);p,u,g,_,_,cv,_=e.evaluate(np.array([np.exp(x)]),np.array([t]))
            ce=max(abs(p[0]*e.rho0*C**2/z['raw'][1]-1),abs(u[0]*C**2/z['raw'][2]-1))
            ab=np.zeros_like(E);em=np.zeros_like(E)
            for j in range(10):
                sigma=s.cross(E,j+1);ab+=np.exp(np.log(y)+z['log_fraction'][j])*sigma;good=sigma>0
                em[good]+=np.exp(np.log(y)+z['log_fraction'][j]+z['affinity']-E[good]/(cold.prior.optical.ex.K*T))*sigma[good]
            aa,ee=s.coefficients(np.array([e.rho0*np.exp(x)]),np.array([t]),np.array([y]),E[None,:]);errors=[]
            for Trad in [13400,20000,80000]:
                occ=1/np.expm1(E/(cold.prior.optical.ex.K*Trad))
                for true,est,field in [(ab,aa[0],occ),(em,ee[0],occ),(em,ee[0],np.ones_like(E))]:
                    for factor in [num,num*E]:
                        weight=factor*field;errors.append(float(np.sum(abs(est-true)*weight)/max(float(true@weight),1e-280)))
            derivative=None
            if x in [-22.7,-19.2]:
                h=1e-4;ar=(n.state(x+h,t,y)['raw']-n.state(x-h,t,y)['raw'])/(2*h)
                at=(n.state(x,t+h,y)['raw']-n.state(x,t-h,y)['raw'])/(2*h);raw=z['raw']
                gamma=ar[1]/raw[1]+at[1]/raw[1]*(raw[1]/raw[0]-ar[2])/at[2]
                derivative=float(max(abs(g[0]/gamma-1),abs(cv[0]*C**2/at[2]-1)))
            rows.append(dict(x=x,T=T,y=y,constitutive=float(ce),spectrum=max(errors),derivative=derivative))
        rho=np.exp(np.array([-17.,-6.,-.1]));lt=np.log([180.,1900.,13400.]);yy=np.array([1e-10,1e-8,.0003]);original.y=yy;e.y=yy
        assert all(np.array_equal(a,b) for a,b in zip(e.evaluate(rho,lt),original.evaluate(rho,lt)))
        assert all(np.array_equal(a,b) for a,b in zip(s.levels(rho*e.rho0,lt,yy),oldspec.levels(rho*e.rho0,lt,yy)))
        rr=np.exp(np.array([-18.-1e-8,-18.]));seam=[]
        for T in [90.,310.,1900.,18200.]:
            e.y=np.full(2,1e-7);v=e.evaluate(rr,np.full(2,np.log(T)))
            seam.append(float(max(abs(v[0][0]/v[0][1]-1),abs(v[1][0]/v[1][1]-1),abs(v[2][0]/v[2][1]-1),abs(v[5][0]/v[5][1]-1))))
        assert max(max(r['constitutive'],r['spectrum'],r['derivative'] or 0) for r in rows)<.002
        assert max(seam)<.002
        support.owner.deadline(start,60)
    except Exception as exc:failure=repr(exc)
    result=dict(classification='Counterexample candidate',passed=failure is None,failure=failure,checks=rows,
        native_calls=n.ion.calls+n.variant_initial_calls,seconds=time.monotonic()-start,
        old_support_bitwise=failure is None,seam_relative=seam if 'seam' in locals() else None,uniform_derivative_certificate=False)
    write(OUT/'coupling-controls.json',result);signal.setitimer(signal.ITIMER_REAL,0.);print(json.dumps(result),flush=True)
    assert result['passed']


def pilot():
    assert read(OUT/'coupling-controls.json')['passed'] and not (OUT/'evolution-pilot.json').exists()
    start=time.monotonic();support.owner.deadline(start,70);rows=[]
    try:
        for n in [64,128]:
            row=Capture().run(n,4);row['new_steps']=4;rows.append(row);assert row['passed']
        state=max(r['cost']['state_write']/max(r['cost']['state_count'],1) for r in rows);parts=[]
        for r in rows:
            c=r['cost'];remaining=r['steps']-r['completed'];fixed=max(r['seconds']-c['physics']-c['state_write']-c['port_write'],0.)
            parts.append(dict(setup=c['setup'],steps=(c['physics']+c['port_write'])/4*remaining,
                states=state*int(np.ceil(remaining/(r['steps']//16))),checkpoints=fixed*(int(np.ceil(remaining/16))+1)))
        estimate=sum(sum(p.values()) for p in parts)+30;upper=1.5*max(estimate,353.30)+20;support.owner.deadline(start,70)
        result=dict(classification='Counterexample candidate',paths=rows,cost_parts=parts,forecast_seconds=estimate,upper_seconds=upper,
            eligible=upper<650,seconds=time.monotonic()-start)
        write(OUT/'evolution-pilot.json',result);print(json.dumps(result),flush=True)
        if result['eligible']:write(OUT/'execution-plan.json',dict(eligible=True,hard_seconds=650,source_sha256=sha(__file__),upper_seconds=upper))
    except Exception as exc:write(OUT/'pilot-failure.json',dict(classification='Counterexample candidate',error=repr(exc),paths=rows,seconds=time.monotonic()-start));raise
    finally:signal.setitimer(signal.ITIMER_REAL,0.)


def production():
    assert not (EV/'result.json').exists();plan=read(OUT/'execution-plan.json');assert plan['eligible'] and sha(__file__)==plan['source_sha256']
    start=time.monotonic();support.owner.deadline(start,650);rows=[]
    try:
        for n in [64,128]:
            row=Capture().run(n,resume=True);rows.append(row);assert row['passed'];support.owner.deadline(start,650)
        result=dict(classification='Counterexample candidate',passed=True,paths=rows,seconds=time.monotonic()-start,
            actual_native_low_density_material_applied=True,nonlinear_GR_closed=False,final_charge_solved=False)
        write(EV/'result.json',result);print(json.dumps(result),flush=True)
    except Exception as exc:write(EV/'failure.json',dict(classification='Counterexample candidate',error=repr(exc),paths=rows,seconds=time.monotonic()-start));raise
    finally:signal.setitimer(signal.ITIMER_REAL,0.)


if __name__=='__main__':globals()[sys.argv[1]]()
