Static response and dynamical identifiability in free-fall tests: finite-order boundaries and a pulsar-triple application
Juneyoung Kim, manuscript of 28 September 2026.

Compile main.tex with latexmk -pdf main.tex (pdfLaTeX and BibTeX) or tectonic main.tex.
The bibliography (references.bib), the generated main.bbl and the four figures are included.
main.tex is generated from manuscript.md in https://github.com/lpaiu-cs/self-mass-unobservability (paper/build_manuscript.py);
data, code and SHA-256 manifests are in that repository, as stated in the Data and code availability section.
