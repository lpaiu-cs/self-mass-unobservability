Identifying a relaxing internal state in free-fall timing: finite-frequency boundaries and an application to PSR J0337+1715
Juneyoung Kim, manuscript of 28 September 2026.

Compile main.tex with latexmk -pdf main.tex (pdfLaTeX and BibTeX) or tectonic main.tex.
The bibliography (references.bib), the generated main.bbl and the figure are included.
The Supplemental Material is submitted separately as a PDF (free-fall-identifiability-supplement.pdf).
main.tex is generated from manuscript.md in https://github.com/lpaiu-cs/self-mass-unobservability (paper/build_manuscript.py);
data, code and SHA-256 manifests are in that repository, as stated in the Data and code availability section.
