# Supplementary Code

Description: Exact projected-separation controls, frozen comparator records and compact inference replay; no timing engine, large runtime arrays or new astrophysical validation.

Companion: Finite-frequency identifiability of relaxation responses in free-fall timing (30 September 2026).

Requirements: Python 3.11+, NumPy and SymPy. Run from the extracted archive root:

    python verification/projected_identifiability.py
    python verification/replay_public_inference.py
    python symbolic/state_identifiability.py

The first command reports 15 exact controls, including coefficient distance 117/1000, erased information 0 and attenuated information 117*epsilon**2/1000. These are constructed dimensionless examples (Proven).

The second command reports the frozen threshold 12.8241766 (to the displayed precision), omnibus statistic about 16.3525 and six empty physical sections (Imported from prior work). It checks source hashes and rebuilds the physical columns. It is conditional on the exported coefficients, precision and threshold. It does not certify derivatives, repeat the noise calibration, fit a nonlinear timing model or produce an empirical SEP bound.

The third command reports 14 exact identities for positive moments, close poles, invisible filters and equilibrium/dynamics ambiguity. It rewrites only its derived analytic JSON in outputs/research-completion/.

outputs/research-completion/comparator-audit.json supplies every retained-information case behind main Table 2. For a comparator, take the minimum relative_information across its stored rows. Unit carrier amplitudes, three phase sets and three fixed covariance amplitudes are part of this archived calculation. Degree-five floating-point remnants are not positive information; the exact interpolation identity fixes zero.

Additional source files are included to satisfy the replay's provenance hash checks. They are not instructions to launch the omitted runtime or rerun the original calibration. Large binary arrays are not included. See the paper and Supplementary Information for remaining numerical and physical limitations.
